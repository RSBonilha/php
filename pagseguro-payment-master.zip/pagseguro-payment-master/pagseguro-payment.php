<?php
/**
 * Plugin Name:          PagSeguro for WooCommerce
 * Description:          PagSeguro for WooCommerce.
 * Author:               Jonathan Delgado
 * Version:              1.1.0
 * Text Domain:          pagseguro-payment
 * Domain Path:          /languages
 * WC requires at least: 3.0.0
 * WC tested up to:      3.4.0
 * Copyright:            © 2019 PagSeguro
 */

defined( 'ABSPATH' ) || exit;

// Plugin constants.
define( 'PAGSEGURO_VERSION', '1.1.0' );
define( 'PAGSEGURO_DOMAIN', 'pagseguro-payment' );
define( 'PAGSEGURO_BASE_DIR', __FILE__ );

if ( ! class_exists( 'WC_Pagseguro_Payment' ) ) {
    include_once dirname( __FILE__ ) . '/classes/pagseguro-payment-base.php';
    add_action( 'plugins_loaded', array( 'WC_Pagseguro_Payment', 'init' ) );
    add_action( 'woocommerce_before_checkout_form', array( 'WC_Pagseguro_Payment', 'reset_session' ) );
    add_action( 'woocommerce_api_wc_gateway_pagseguro_ipn', array('WC_Pagseguro_Payment_Gateway', 'ipn_pagseguro'));
    add_action( 'wp_ajax_consultpagseguro', array('WC_Pagseguro_Payment_Gateway', 'consultTransaction'));
}