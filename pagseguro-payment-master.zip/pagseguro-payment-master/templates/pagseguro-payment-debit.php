<?php

if (!defined('ABSPATH')) {
    exit;
}
?>
<script src="<?php echo plugin_dir_url(__DIR__)."js/masks.js"; ?>"></script>
<style>
    /*Estilo para options de transferência*/
    .bank-option-box{
       display: flex;
        flex-direction: column;
        align-items: center;
        /*justify-content: center;*/
        width: auto !important;
        padding: 5px;
        font-size: 12px;
    }
    .ul-bank-box{
        clear: both;
        display:flex;
        flex-direction: row;
        margin:0 !important;
        padding: none;
        justify-content: center !important;
    }
</style>
<script>
var pagseguro_submit = false;
var debug_js_debit = "<?php echo $debug_js; ?>";

jQuery( document ).ready(function() {
    session_id = "<?php echo $session_id; ?>";
    if(debug_js_debit) {
        console.log(session_id);
    }
    if(session_id == 0) {
        console.log('Não foi possível obter a session id do PagSeguro. Verifique suas configurações.');
    }
    PagSeguroDirectPayment.setSessionId(session_id);
    PagSeguroDirectPayment.getPaymentMethods({
        amount: <?php echo $total ?>,
        success: function(response) {
            if(debug_js_debit) {
                console.log('success');
            }
            jQuery.each(response.paymentMethods.ONLINE_DEBIT.options, function(index, option) {
                if(option.status == 'AVAILABLE') {
                    renderMethod('debit', option);
                    jQuery( ".ps_transparent_debit_type:first" ).click();
                }
                else {
                    if(debug_js_debit) {
                        console.log(option);
                    }
                }
            });
        },
        error: function(response) {
            if(debug_js_debit) {
                console.log('erro');
            }
        },
        complete: function(response) {
            if(debug_js_debit) {
                console.log(response);
            }
        }
    });
    getSenderHash();
});

jQuery( 'form.checkout' ).on( 'checkout_place_order_pagseguro-payment-debit', function(e) {
    return pagSeguroFormValidator('eft');
});

jQuery( 'form#order_review' ).submit( function(e) {
    return pagSeguroFormValidator();
});
</script>
<fieldset id="ps-transparent-payment-fieldset" class="ps-transparent-payment-fieldset ">
    <input id="ps_transparent_sender_hash" type="hidden" name="ps_transparent_sender_hash" value=""/>
    <input type="hidden" name="ps-transparent-payment-radio" value="eft"/>
    <div class="ps-transparent-payment-form ps-transparent-payment-form-debit" id="ps-transparent-payment-form-debit">
        <p class="form-row">
            <label for="ps_transparent_debit_cpf"><?php _e('CPF', PAGSEGURO_DOMAIN);?> <abbr class="required" title="Informe o CPF">*</abbr></label>
            <input type="text" name="ps_transparent_debit_cpf" id="ps_transparent_debit_cpf" onkeyup="ps_mask_cpf(this.value,'ps_transparent_debit_cpf');"  class="box-fill" style="font-size: 1.5em; padding: 8px;" />
        </p>
        <div class="form-row">
            <label><?php _e('Telefone', PAGSEGURO_DOMAIN);?>&nbsp;<abbr class="required">*</abbr></label>
            <p class="form-row">
                <input type="text" name="ps_transparent_debit_phone" id="ps_transparent_debit_phone" onkeyup="ps_mask_phone(this.value,'ps_transparent_debit_phone');"  class="box-fill" style="font-size: 1.5em; padding: 8px;" />
            </p>
        </div>
            <div class="form-row">
                <center>
                    <ul id="ps_transparent_debit_flags" class="ul-bank-box"  >
                    </ul>
                </center>
            </div>
    </div>
</fieldset>