<?php

if (!defined('ABSPATH')) {
    exit;
}

?>

<script src="<?php echo plugin_dir_url(__DIR__)."js/masks.js"; ?>"></script>
<script>
var pagseguro_submit = false;
function renderMethod(type, option) {
    var path = "<?php echo $static_path; ?>";
    var name = option.displayName;
    var code = option.name.toLowerCase();
    var image = path + option.images.MEDIUM.path;

    if(type == 'billet') {
        jQuery('#ps_transparent_billet_ico').attr('src', image);
        jQuery('#ps_transparent_billet_ico').show();
        jQuery('.ps-transparent-payment-li-billet').show();
    } else if(type == 'debit') {
        if(!jQuery('#ps_transparent_debit_type_'+code).length) {
            li = document.createElement("li");
            img = document.createElement("img");
            span = document.createElement("span");
            radio = document.createElement("input");
            li.className = 'ps_transparent_debit_li bank-option-box';
            radio.type = 'radio';
            radio.id = 'ps_transparent_debit_type_'+code;
            radio.name = 'ps_transparent_debit_type';
            radio.className = 'ps_transparent_debit_type';
            radio.value = code;
            img.src = image;
            img.alt = name;
            img.title = name;
            span.innerText = name;
            li.append(radio);
            li.append(img);
            li.append(span);


            jQuery('#ps_transparent_debit_flags').append(li);
            jQuery('.ps-transparent-payment-li-debit').show();
        }
    }
    else {
        if(!jQuery('#ps_transparent_credit_brand_'+code).length) {
            li = document.createElement("li");
            li.id = 'ps_transparent_credit_brand_'+code;
            li.setAttribute('data-image-src', image);
            jQuery('#ps_transparent_card_flags').append(li);
            jQuery('.ps-transparent-payment-li-card').show();
        }
    }
}

jQuery( 'body' ).on( 'click', '#ps-transparent-payment-radio-card', function() {
    var radio_option = document.getElementById('ps-transparent-payment-radio');
    var radio_card = document.getElementById('ps-transparent-payment-radio-card');
    var radio_billet = document.getElementById('ps-transparent-payment-radio-billet');
    var radio_debit = document.getElementById('ps-transparent-payment-radio-debit');
    jQuery( '.ps-transparent-payment-form' ).hide();
    jQuery( '.ps-transparent-payment-form-card' ).show();
    radio_card.className = "active-tabButton";
    if(radio_billet) {
        radio_billet.className = "tabButton";
    }
    if(radio_debit) {
        radio_debit.className = "tabButton";
    }
    radio_option.value = "creditCard";
    getSenderHash();
});
jQuery( 'body' ).on( 'click', '#ps-transparent-payment-radio-billet', function() {
    var radio_option = document.getElementById('ps-transparent-payment-radio');
    var radio_card = document.getElementById('ps-transparent-payment-radio-card');
    var radio_billet = document.getElementById('ps-transparent-payment-radio-billet');
    var radio_debit = document.getElementById('ps-transparent-payment-radio-debit');
    jQuery( '.ps-transparent-payment-form' ).hide();
    jQuery( '.ps-transparent-payment-form-billet' ).show();
    radio_billet.className = "active-tabButton";
    if(radio_card) {
        radio_card.className = "tabButton";
    }
    if(radio_debit) {
        radio_debit.className = "tabButton";
    }
    radio_option.value = "boleto";
    getSenderHash();
});
jQuery( 'body' ).on( 'click', '#ps-transparent-payment-radio-debit', function() {
    var radio_option = document.getElementById('ps-transparent-payment-radio');
    var radio_card = document.getElementById('ps-transparent-payment-radio-card');
    var radio_billet = document.getElementById('ps-transparent-payment-radio-billet');
    var radio_debit = document.getElementById('ps-transparent-payment-radio-debit');
    jQuery( '.ps-transparent-payment-form' ).hide();
    jQuery( '.ps-transparent-payment-form-debit' ).show();
    jQuery( ".ps_transparent_debit_type:first" ).click();
    radio_debit.className = "active-tabButton";
    if(radio_card) {
        radio_card.className = "tabButton";
    }
    if(radio_billet) {
        radio_billet.className = "tabButton";
    }
    radio_option.value = "eft";
    getSenderHash();
});

function ps_mask_cpf(v, fieldName)
{
    var masked_cpf = maskCpf(v);
    jQuery('#'+fieldName).val(masked_cpf);
}

function ps_mask_date(v, fieldName)
{
    var masked_date = maskDate(v);
    jQuery('#'+fieldName).val(masked_date);
}

function ps_mask_expiry(v, fieldName)
{
    var masked_expiry = maskExpiry(v);
    jQuery('#'+fieldName).val(masked_expiry);
}

function ps_mask_phone(v, fieldName)
{
    var masked_phone = maskPhone(v);
    jQuery('#'+fieldName).val(masked_phone);
}

function pagSeguroFormValidator() {
    if ( window.pagseguro_submit ) {
        window.pagseguro_submit = false;

        return true;
    }

    if ( ! jQuery( '#payment_method_pagseguro-payment' ).is( ':checked' ) ) {
        return true;
    }

    var form = jQuery( 'form.checkout, form#order_review' ),
        error           = false,
        wrapper         = '',
        errorHtml       = '',
        type            = jQuery( '#ps-transparent-payment-radio', form).val(),
        brand           = jQuery( '#ps_transparent_card_type', form).val(),
        name            = jQuery( '#ps_transparent_name', form).val(),
        cpf             = jQuery( '#ps_transparent_cpf', form).val().replace( /[^\d]/g, '' ),
        birthdate       = jQuery( '#ps_transparent_birthdate', form).val(),
        phone           = jQuery( '#ps_transparent_phone', form).val().replace( /[^\d]/g, '' ),
        cardNumber      = jQuery( '#ps_transparent_card_num', form ).val().replace( /[^\d]/g, '' ),
        cvv             = jQuery( '#ps_transparent_card_cvv', form ).val(),
        expirationMonth = jQuery( '#ps_transparent_card_expiry', form ).val().replace( /[^\d]/g, '' ).substr( 0, 2 ),
        expirationYear  = jQuery( '#ps_transparent_card_expiry', form ).val().replace( /[^\d]/g, '' ).substr( 2 ),
        installments    = jQuery( '#ps_transparent_installments', form ),

        billet_cpf      = jQuery( '#ps_transparent_billet_cpf', form).val().replace( /[^\d]/g, '' ),
        billet_phone    = jQuery( '#ps_transparent_billet_phone', form).val().replace( /[^\d]/g, '' ),

        debit_cpf       = jQuery( '#ps_transparent_debit_cpf', form).val().replace( /[^\d]/g, '' ),
        debit_phone     = jQuery( '#ps_transparent_debit_phone', form).val().replace( /[^\d]/g, '' ),

        today           = new Date();

    errorHtml += '<ul>';

    if(type === 'creditCard') {
        wrapper = jQuery( '#ps-transparent-payment-form-card' );
        if ( typeof brand === 'undefined' || 'error' === brand ) {
            errorHtml += '<li>' + '<?php echo $errors['invalid_card'] ?>' + '</li>';
            error = true;
        }

        if ( name.trim().indexOf(' ') == -1 || name.trim().length < 1  ) {
            errorHtml += '<li>' + '<?php echo $errors['invalid_name'] ?>' + '</li>';
            error = true;
        }

        if (!isCpf(cpf)) {
            errorHtml += '<li>' + '<?php echo $errors['invalid_cpf'] ?>' + '</li>';
            error = true;
        }

        parts = birthdate.split("/");
        date = new Date(Number(parts[2]), Number(parts[1]) - 1, Number(parts[0]));
        if ( !birthdate.match(/^(0[1-9]|[12][0-9]|3[01])[\- \/.](?:(0[1-9]|1[012])[\- \/.](19|20)[0-9]{2})$/) || today <= date) {
            errorHtml += '<li>' + '<?php echo $errors['invalid_birthdate'] ?>' + '</li>';
            error = true;
        }

        if ( !phone.match(/^((1[1-9])|([2-9][0-9]))(([0-9]{4}[0-9]{4})|(9[0-9]{3}[0-9]{5}))$/) ) {
            errorHtml += '<li>' + '<?php echo $errors['invalid_phone'] ?>' + '</li>';
            error = true;
        }

        if( !PagSeguroValidateLuhn(cardNumber) || cardNumber.length < 13 ) {
            errorHtml += '<li>' + '<?php echo $errors['invalid_card'] ?>' + '</li>';
            error = true;
        }

        if ( 2 !== expirationMonth.length || 4 !== expirationYear.length ) {
            errorHtml += '<li>' + '<?php echo $errors['invalid_expiry'] ?>' + '</li>';
            error = true;
        }

        if ( ( 2 === expirationMonth.length && 4 === expirationYear.length ) && ( expirationMonth > 12 || expirationYear <= ( today.getFullYear() - 1 ) || expirationYear >= ( today.getFullYear() + 20 ) || ( expirationMonth < ( today.getMonth() + 2 ) && expirationYear.toString() === today.getFullYear().toString() ) ) ) {
            errorHtml += '<li>' + '<?php echo $errors['expired_card'] ?>' + '</li>';
            error = true;
        }

        if ( ( cvv.length != jQuery( '#ps_transparent_card_cvv', form ).attr('maxlength') ) ) {
            errorHtml += '<li>' + '<?php echo $errors['invalid_cvv'] ?>' + '</li>';
            error = true;
        }

        if ( '' == installments.val() ) {
            errorHtml += '<li>' + '<?php echo $errors['invalid_installment'] ?>' + '</li>';
            error = true;
        }
    }
    else if(type === 'boleto') {
        wrapper = jQuery( '#ps-transparent-payment-form-billet' );
        if (!isCpf(billet_cpf)) {
            errorHtml += '<li>' + '<?php echo $errors['invalid_cpf'] ?>' + '</li>';
            error = true;
        }
        if ( !billet_phone.match(/^((1[1-9])|([2-9][0-9]))(([0-9]{4}[0-9]{4})|(9[0-9]{3}[0-9]{5}))$/) ) {
            errorHtml += '<li>' + '<?php echo $errors['invalid_phone'] ?>' + '</li>';
            error = true;
        }
    }
    else {
        wrapper = jQuery( '#ps-transparent-payment-form-debit' );
        if (!isCpf(debit_cpf)) {
            errorHtml += '<li>' + '<?php echo $errors['invalid_cpf'] ?>' + '</li>';
            error = true;
        }
        if ( !debit_phone.match(/^((1[1-9])|([2-9][0-9]))(([0-9]{4}[0-9]{4})|(9[0-9]{3}[0-9]{5}))$/) ) {
            errorHtml += '<li>' + '<?php echo $errors['invalid_phone'] ?>' + '</li>';
            error = true;
        }
    }

    errorHtml += '</ul>';

    if ( ! error ) {
        //corrigir loop
        window.pagseguro_submit = true;
        //form.submit();
        if(type === 'creditCard') {
            var idToken = jQuery('#ps_transparent_card_token');
            getCardToken(cardNumber,expirationMonth,expirationYear,brand,cvv,idToken,form,true);
        }
        else {
            return true;
        }
        return false;
    // Display the error messages.
    } else {
        PagSeguroError( errorHtml, wrapper );
    }

    return false;
}

function PagSeguroError( error, wrapper ) {
    jQuery( '.woocommerce-error', wrapper ).remove();
    wrapper.prepend( '<div class="woocommerce-error" style="margin-bottom: 0.5em !important;">' + error + '</div>' );
}

function PagSeguroValidateLuhn(s) {
    var w = s.replace(/\D/g, ""); //remove all non-digit characters

    j = w.length / 2;
    k = Math.floor(j);
    m = Math.ceil(j) - k;
    c = 0;
    for (i=0; i<k; i++) {
        a = w.charAt(i*2+m) * 2;
        c += a > 9 ? Math.floor(a/10 + a%10) : a;
    }
    for (i=0; i<k+m; i++) c += w.charAt(i*2+1-m) * 1;
    return (c%10 == 0);
}

jQuery( document ).ready(function() {
    jQuery( ".ps-transparent-payment-li" ).hide();
    jQuery( ".ps-transparent-payment-radio:first" ).click();
    session_id = "<?php echo $session_id; ?>";
    //console.log(session_id);
    if(session_id == 0) {
        console.log('Não foi possível obter a session id do PagSeguro. Verifique suas configurações.');
    }
    PagSeguroDirectPayment.setSessionId(session_id);
    PagSeguroDirectPayment.getPaymentMethods({
        amount: <?php echo $total ?>,
        success: function(response) {
            //console.log('success');
            jQuery.each(response.paymentMethods.BOLETO.options, function(index, option) {
                if(option.status == 'AVAILABLE') {
                    renderMethod('billet', option);
                }
                else {
                    //console.log(option);
                }
            });
            jQuery.each(response.paymentMethods.ONLINE_DEBIT.options, function(index, option) {
                if(option.status == 'AVAILABLE') {
                    renderMethod('debit', option);
                }
                else {
                    //console.log(option);
                }
            });
            jQuery.each(response.paymentMethods.CREDIT_CARD.options, function(index, option) {
                if(option.status == 'AVAILABLE') {
                    renderMethod('credit', option);
                }
                else {
                    //console.log(option);
                }
            });
        },
        error: function(response) {
            console.log('erro');
            // Callback para chamadas que falharam.
        },
        complete: function(response) {
            //console.log(response);
        }
    });
    jQuery('#ps_transparent_card_cvv').keyup(function(){validaPagSeguro()});
    jQuery('#ps_transparent_card_num').keyup(function(){validaPagSeguro()});
    jQuery('#ps_transparent_card_expiry').keyup(function(){validaPagSeguro()});
    //jQuery('#ps_transparent_card_venc_month').change(function(){validaPagSeguro()});
    //jQuery('#ps_transparent_card_venc_year').change(function(){validaPagSeguro()});
    var cc_num = document.querySelector('#ps_transparent_card_num');
    if(cc_num) {
        cc_num.onkeyup = function (e) {
            if (this.value == this.lastValue) return;
            var caretPosition = this.selectionStart;
            var sanitizedValue = this.value.replace(/[^0-9]/gi, '');
            var parts = [];

            for (var i = 0, len = sanitizedValue.length; i < len; i += 4) {
                parts.push(sanitizedValue.substring(i, i + 4));
            }

            for (var i = caretPosition - 1; i >= 0; i--) {
                var c = this.value[i];
                if (c < '0' || c > '9') {
                    caretPosition--;
                }
            }
            caretPosition += Math.floor(caretPosition / 4);

            this.value = this.lastValue = parts.join(' ');
            this.selectionStart = this.selectionEnd = caretPosition;
        }
        jQuery('#ps_transparent_card_num').focus();
    }
});

jQuery( 'body' ).on( 'focusout', '#ps_transparent_card_num', function() {
    var bin = jQuery( this ).val().replace( /[^\d]/g, '' ).substr( 0, 6 ),
        installments = jQuery( 'body #ps_transparent_installments' );

    if ( 6 === bin.length ) {
        PagSeguroDirectPayment.getBrand({
            cardBin: bin,
            success: function( data ) {
                if(data.brand.name != jQuery( 'body #ps_transparent_card_type' ).val() || !installments.val()) {
                    // Reset the installments.
                    installments.empty();
                    installments.attr( 'disabled', 'disabled' );

                    updateInstallments(data.brand.name);
                    jQuery( '#ps_transparent_cc_type_icon' ).attr('src',jQuery('#ps_transparent_credit_brand_'+data.brand.name).attr('data-image-src'));
                    jQuery( 'body #ps_transparent_card_type' ).val(data.brand.name);
                    if(data.brand.name == 'amex') {
                        jQuery("#ps_transparent_card_cvv").attr('maxlength','4');
                    }
                    else {
                        jQuery("#ps_transparent_card_cvv").attr('maxlength','3');
                    }
                }
            },
            error: function() {
                //$( 'body' ).trigger( 'card_type', 'error' );
                //pagSeguroSetCreditCardBrand( 'error' );
            },
            complete: function() {
                // Reset the installments.
            }
        });
    }
});
function checkCVV(bandeira) {
    "use strict";
    var cvvField = jQuery("#ps_transparent_card_cvv");
    if (bandeira && bandeira != 'undefined') {
        var brand = bandeira.toLowerCase();
    }else{
        var brand = jQuery('#ps_transparent_card_type').val().toLowerCase();
    }
    if (cvvField.val()) {
        if (brand == 'amex' && cvvField.val().length != 4 || brand != 'amex' && cvvField.val().length != 3) {
            cvvField.parent().parent().addClass('form-error');
            console.log('CVV inválido. '+ brand +' com '+ cvvField.val().length +' caracteres.');
            return false;
        }else{
            cvvField.parent().parent().removeClass('form-error').addClass('form-ok');
            return true;
        }
    }
}
// Get the installments.
function updateInstallments(brand) {
    console.log('updateInstallments');
    if ( 'error' !== brand ) {
        PagSeguroDirectPayment.getInstallments({
            amount: <?php echo $total ?>,
            brand: brand,
            maxInstallmentNoInterest:  <?php echo $credit_interest_free; ?>,
            success: function( data ) {
                var installments = jQuery( '#ps_transparent_installments' );
                var maxInstallments = <?php echo $credit_max_installment; ?>;

                if ( false === data.error ) {
                    installments.empty();
                    installments.removeAttr( 'disabled' );
                    var valorParcela;

                    jQuery.each( data.installments[brand], function( index, installment ) {
                        console.log(installment);
                        if(installment.quantity == 1) {
                            valorParcela = installment.installmentAmount;
                        }
                        if(!maxInstallments || installment.quantity <= maxInstallments) {
                            installments.append( pagSeguroGetInstallmentOption( installment ) );
                        }
                    });
                    jQuery( '#ps_transparent_installment_value' ).val(valorParcela);
                } else {
                    console.log(data.error);
                }
            },
            error: function() {
                //pagSeguroAddErrorMessage( errors.invalid_card );
            }
        });
    } else {
        //pagSeguroAddErrorMessage( errors.invalid_card );
    }
}

function pagSeguroGetInstallmentOption( installment ) {
    return '<option value="' + installment.quantity + '" data-installment-value="' + installment.installmentAmount + '">' + pagSeguroGetPriceText( installment ) + '</option>';
}

function pagSeguroGetPriceText( installment ) {
    var interest = 1;
    var installmentParsed = 'R$ ' + parseFloat( installment.installmentAmount, 10 ).toFixed( 2 ).replace( '.', ',' ).toString();
    var totalParsed = 'R$ ' + parseFloat( installment.totalAmount, 10 ).toFixed( 2 ).replace( '.', ',' ).toString();
    var interestFree = ( true === installment.interestFree ) ? ' = ' + totalParsed + ' sem juros': '';
    var interestText = interestFree ? interestFree : ' = ' + totalParsed;

    return installment.quantity + 'x de ' + installmentParsed + interestText;
}

function getSenderHash() {
    PagSeguroDirectPayment.onSenderHashReady(function(response){
        jQuery( '#ps_transparent_sender_hash' ).val(response.senderHash);
    });
}

function getCardToken(number, month, year, type, cvv, idToken, form, submit) {
    PagSeguroDirectPayment.createCardToken({
        cardNumber: number,
        brand: type,
        cvv: cvv,
        expirationMonth: month,
        expirationYear: year,
        success: function(callback) {
            idToken.val(callback.card.token);
            getSenderHash();
            console.log(callback);
            if(submit) {
                form.submit();
            }
        },
        error: function(callback) {
            reload = false;
            if(undefined != callback.errors["30400"]) {
                error = 'Dados do cartão inválidos.';
            } else if (undefined != callback.errors["10001"]) {
                error = 'Tamanho do cartão inválido.';
            } else if (undefined != callback.errors["10006"]) {
                error = 'Tamanho do CVV inválido.';
            } else if (undefined != callback.errors["30405"]) {
                error = 'Data de validade incorreta.';
            } else if (undefined != callback.errors["30403"]) {
                error = 'Sessão inválida, a página será atualizada.';
                reload = true;
            } else if (undefined != callback.errors["30404"]) {
                error = 'Sessão inválida, a página será atualizada.';
                reload = true;
            } else {
                error = 'Verifique os dados do cartão digitado.';
            }
            console.error('Falha ao obter o token do cartao.');
            console.warn(error);
            console.log(callback.errors);
            if(reload) {
                location.reload();
            }
        },
        complete: function(callback) {

        },
    });
}

function callPagSeguro() {
    var cid = jQuery('#ps_transparent_card_cvv').val();
    var number = jQuery('#ps_transparent_card_num').val().replace(/\D/g, '');
    var month = jQuery( '#ps_transparent_card_expiry').val().replace( /[^\d]/g, '' ).substr( 0, 2 );
    var year  = jQuery( '#ps_transparent_card_expiry').val().replace( /[^\d]/g, '' ).substr( 2 );
    var type = jQuery('#ps_transparent_card_type').val();
    var idToken = jQuery('#ps_transparent_card_token');
    getCardToken(number,month,year,type,cid,idToken,null,false);
}

function checkLength(obj, size) {
    return (obj && obj.length > size);
}

function validaPagSeguro() {
    var cid = jQuery('#ps_transparent_card_cvv').val();
    var number = jQuery('#ps_transparent_card_num').val().replace(/\D/g, '');
    var month = jQuery( '#ps_transparent_card_expiry').val().replace( /[^\d]/g, '' ).substr( 0, 2 );
    var year  = jQuery( '#ps_transparent_card_expiry').val().replace( /[^\d]/g, '' ).substr( 2 );
    var type = jQuery('#ps_transparent_card_type').val();
    if(checkLength(cid,2) && checkLength(number,10) && checkLength(month,0) && checkLength(year,0) && checkLength(cid,2)){
        callPagSeguro();
    }
}

function toggleAddressBox(change)
{
    if(change)
    {
        jQuery('#confirm-address-box').show();
        jQuery('#confirm-address-box').val(false);
    } else {
        jQuery('#confirm-address-box').hide();
        jQuery('#confirm-address-box').val(true);
    }

}

function toggleVerso(action) {
    "use strict";
    if (action === 'add') {
        jQuery('#card_container').addClass('verso');
    }else{
        jQuery('#card_container').removeClass('verso');
    }
}

function sendToCard(str, classe) {
    "use strict";
    if(classe === 'card-expiry-month' && str.length == 1) {
        str = '0'+str;
    }
    if (str.length > 1) {
        jQuery('#card_container .' + classe).html(str);
        if(classe === 'card-number') {
            var txt = jQuery('#number_card').html();
            txt = txt.replace(/\D/g, '');
            jQuery('#number_card').html(txt.replace(/(.{4})/g, '$1 '));
        }
    }
}

jQuery(document).on('change', '#ps_transparent_installments', function(event) {
    jQuery( '#ps_transparent_installment_value' ).val(jQuery(this).find(':selected').attr('data-installment-value'));
});

jQuery( 'form.checkout' ).on( 'checkout_place_order_pagseguro-payment', function(e) {
    return pagSeguroFormValidator();
});

jQuery( 'form#order_review' ).submit( function(e) {
    return pagSeguroFormValidator();
});

</script>

<style type="text/css">
    ps-transparent-payment-form { display: none; }
    /*Para a logo do pagseguro*/
.ps-logo-box {
    width: 100%;
    height:auto;
    align-items: center;
    justify-content: center;
    flex:1;
    flex-direction: column;
    margin-bottom: 10px;
}
.ps-logo-img{
    float:none !important;
}

/*Estilos para o esquema de tabs*/

    .tabButton {
       border-top-left-radius: 5px !important;
       border-top-right-radius: 5px !important;
       border-bottom: 1px solid #e8e8e8;
       background-color: white !important;
       outline: none !important;
       font-weight: 500 !important;
    }

    .tabButton:hover {
       border: 1px solid #bdc3c7 !important;
         border-bottom: 1px solid transparent !important;

    }


    .tabButton:focus {
        border: 1px solid #bdc3c7;
        border-bottom: 1px solid transparent;

    }
    .active-tabButton {
        border-top-left-radius: 5px !important;
        border-top-right-radius: 5px !important;
        border: 1px solid #bdc3c7 !important;
        border-bottom: 1px solid transparent !important;
        background-color: white !important;
        outline: none !important;
        font-weight: bold !important;
    }
     .tabButton:active {
        border: 1px solid #bdc3c7;
        border-bottom: 1px solid transparent;
    }
    .tabsContainer {
        font-size: 10px !important;
        margin-bottom: -1px;
    }

    .billet-img {
        max-height: none !important;
        align-self: center !important;
    }

    input[type="button"] {
     font-family: "Font Awesome 5 Free","Source Sans Pro",HelveticaNeue-Light,"Helvetica Neue Light","Helvetica Neue",Helvetica,Arial,"Lucida Grande",sans-serif;
    }



    .method-box {
        border: 1px solid #bdc3c7 !important;
        border-radius: 5px !important;
        padding: 10px;
        border-top-left-radius: 0px !important;

    }
  @media only screen and (max-width: 853px)
  {
  .tabsContainer {
        font-size: 8px !important;
        margin-bottom: -1px;
    }
  }

    @media only screen and (max-width: 764px)
    {
        .active-tabButton {
        border: 1px solid #bdc3c7 !important;
        border-radius: 5px !important;
        background-color: white !important;
        outline: none !important;
        width: 100%;
       font-weight: bold !important;
    }
     .tabButton {
       background-color: white !important;
       outline: none !important;
       width: 100%;
       border-radius: 5px !important;
       font-weight: 500 !important;
    }
     .tabsContainer {
        font-size: 10px !important;
        margin-bottom: 5px;
    }

    /*Box do método*/
     .method-box {
        border: 1px solid #bdc3c7 !important;
        border-radius: 5px !important;
        padding: 10px;
        }
    }

    /*Estilo para options de transferência*/
    .bank-option-box{
       display: flex;
        flex-direction: column;
        align-items: center;
        /*justify-content: center;*/
        width: auto !important;
        padding: 5px;
        font-size: 12px;
    }
    .ul-bank-box{
        clear: both;
        display:flex;
        flex-direction: row;
        margin:0 !important;
        padding: none;
        justify-content: center !important;
    }

/*Cartão de Crédito*/
#card_wrapper {
    width: 300px;
    max-width: 100%;
    height: 192px;
    max-height: 194px;
    text-align: center;
    margin: 30px auto;
    position: relative;
    overflow: hidden;
    z-index: 100;
}

#card_wrapper #card_container {
    background-image: url('<?php echo plugin_dir_url(__DIR__).'img/credit-card.png'; ?>');  /*../img/credit-card.png*/
    background-repeat: no-repeat;
    background-size: contain;
    background-position: center top;
    -webkit-perspective: 1000;
    -moz-perspective: 1000;
    -o-perspective: 1000;
    perspective: 1000;
    height: 390px;
    z-index: 50;
}

#card_wrapper #card_container>div.card-number {
    position: absolute;
    z-index: 150;
    top: 100px;
    left: 30px;
    color: #fff;
    text-shadow: 1px 1px 1px #333;
    font-size: 20px;
    font-weight: bold;
    font-family: 'Anonymous Pro';
}

#card_wrapper #card_container>div.card-name {
    position: absolute;
    z-index: 150;
    top: 160px;
    left: 15px;
    color: #fff;
    text-shadow: 1px 1px 1px #333;
    text-transform: uppercase;
    font-size: 14px;
    letter-spacing: 1px;
    font-family: 'Anonymous Pro';
    font-weight: bold;
}

#card_wrapper #card_container>div.card-expiry {
    position: absolute;
    z-index: 150;
    top: 136px;
    left: 160px;
    color: #fff;
    text-shadow: 1px 1px 1px #333;
    font-family: 'Anonymous Pro';
    font-size: 14px;
}

#card_wrapper #card_container>div.card-brand {
    position: absolute;
    z-index: 150;
    top: 156px;
    right: 6px;
    display: block;
    width: 60px;
    max-width: 60px;
    height: 40px;
    max-height: 40px;
    overflow: hidden;
}

#card_wrapper #card_container>span.card-cvv {
    position: absolute;
    display: none;
    z-index: 150;
    top: 97px;
    right: 52px;
    color: #333;
}

#card_wrapper #card_container.verso {
    background-position: center -195px;
}

#card_wrapper #card_container.verso>div {
    display: none;
}

#card_wrapper #card_container.verso>span.card-cvv {
    display: block;
}

.flipper {
    -webkit-transition: 0.6s;
    -webkit-transform-style: preserve-3d;
    -moz-transition: 0.6s;
    -moz-transform-style: preserve-3d;
    -o-transition: 0.6s;
    -o-transform-style: preserve-3d;
    transition: 0.6s;
    transform-style: preserve-3d;
    position: relative;
}

#order-confirmation #logo-pagseguro {}

#pagseguro-container .nofloat {
    float: none !important;
    display: inline-block;
    margin: 0 auto;
}

#pagseguro-container .nofloat-block {
    float: none !important;
    display: block;
    margin: 10px auto;
}

#pagseguro-container .clearfix {
    clear: both;
}

#pagseguro-container .cart_navigation button {
    float: right;
}


</style>

<fieldset id="ps-transparent-payment-fieldset" class="ps-transparent-payment-fieldset ">
    <div class="tabsContainer">

    <?php if ($credit == 'yes'): ?>
        <input type ="button" class="ps-transparent-payment-radio tabButton"   onclick=""  id="ps-transparent-payment-radio-card" value="&#xf09d;  CARTÃO"></input>
    <?php endif;?>

    <?php if ($billet == 'yes'): ?>
        <input type ="button" class="ps-transparent-payment-radio tabButton"  onclick="" id="ps-transparent-payment-radio-billet" value="&#xf02a;  BOLETO"/>
    <?php endif;?>

    <?php if ($debit == 'yes'): ?>
        <input type ="button" class="ps-transparent-payment-radio tabButton"  onclick="" id="ps-transparent-payment-radio-debit" value="&#xf362; TRANSFERÊNCIA"/>
    <?php endif;?>
</div>
<input id="ps-transparent-payment-radio" type="hidden" name="ps-transparent-payment-radio" value=""/>
<input id="ps_transparent_sender_hash" type="hidden" name="ps_transparent_sender_hash" value=""/>

    <div class="method-box">
<?php if ($credit == 'yes'): ?>
    <div class="ps-transparent-payment-form ps-transparent-payment-form-card" id="ps-transparent-payment-form-card">
        <div id="card_show" class="col-xs-12 col-sm-6 pull-right nopadding-left" align="center">
                <div id="card_wrapper" class="nofloat">
                    <div id="card_container">
                        <div id="number_card" class="card-number anonymous">••••&nbsp; ••••&nbsp; ••••&nbsp; ••••</div>
                        <div class="card-name">TITULAR DO CARTÃO</div>
                        <div class="card-expiry"><span class="card-expiry-month">• •</span> / <span class="card-expiry-year">• •</span></div>
                        <div class="card-brand"></div>
                        <span class="card-cvv">•••</span>
                    </div>
                </div>
            </div>
        <ul id="ps_transparent_card_flags" class="ps-transparent-payment-group" style="clear: both;">
        </ul>
        <input id="ps_transparent_card_type" type="hidden" name="ps_transparent_card_type" value=""/>
        <input id="ps_transparent_card_token" type="hidden" name="ps_transparent_card_token" value=""/>
        <input id="ps_transparent_installment_value" type="hidden" name="ps_transparent_installment_value" value=""/>
        <br/>
          <p class="form-row">
            <label for="ps_transparent_name"><?php _e('Titular do Cartão', PAGSEGURO_DOMAIN);?>&nbsp;<abbr class="required" title="Digite exatamente o nome escrito na frente do cartão">*</abbr></label>
            <input type="text" name="ps_transparent_name" id="ps_transparent_name" class="input-text" autocomplete="off" style="font-size: 1.5em; padding: 8px;" onblur="sendToCard(this.value, 'card-name');" />
        </p>
          <p class="form-row">
            <label for="ps_transparent_cpf"><?php _e('CPF do portador do cartão', PAGSEGURO_DOMAIN);?> <abbr class="required" title="Digite o CPF do portador do Cartão">*</abbr></label>
            <input type="text" name="ps_transparent_cpf" id="ps_transparent_cpf" onkeyup="ps_mask_cpf(this.value,'ps_transparent_cpf');"  maxlength="14" class="input-text" style="font-size: 1.5em; padding: 8px;" />
        </p>
          <p class="form-row">
            <label for="ps_transparent_birthdate"><?php _e('Data de Nascimento', PAGSEGURO_DOMAIN);?> <abbr class="required" title="Digite a Data de Nascimento">*</abbr></label>
            <input type="text" name="ps_transparent_birthdate" id="ps_transparent_birthdate"  onkeyup="ps_mask_date(this.value,'ps_transparent_birthdate');" class="input-text" style="font-size: 1.5em; padding: 8px;" />
        </p>
        <p class="form-row">
            <label for="ps_transparent_phone"><?php _e('Telefone de Contato', PAGSEGURO_DOMAIN);?>&nbsp;<abbr class="required" title="Digite um telefone para contato">*</abbr></label>
            <input type="text" name="ps_transparent_phone" onkeyup="ps_mask_phone(this.value,'ps_transparent_phone');" id="ps_transparent_phone" class="input-text" autocomplete="off" style="font-size: 1.5em; padding: 8px;" />
        </p>

        <p class="form-row">
            <label for="ps_transparent_card_num"><?php _e('Número do Cartão', PAGSEGURO_DOMAIN);?>&nbsp;<abbr class="required" title="Digite o número do cartão">*</abbr></label>
            <input type="text" name="ps_transparent_card_num" id="ps_transparent_card_num" maxlength="19" class="input-text" autocomplete="off" placeholder="&bull;&bull;&bull;&bull; &bull;&bull;&bull;&bull; &bull;&bull;&bull;&bull; &bull;&bull;&bull;&bull;" style="font-size: 1.5em; padding: 8px; width:85%; "   onblur="sendToCard(this.value, 'card-number');" />
            <span style="padding-right:3px; padding-top: 3px; display:inline-block;">
               <img id="ps_transparent_cc_type_icon" src="" style="width:50px;"></img>
            </span>
        </p>

        <p class="form-row form-row-first">
            <label for="ps_transparent_card_expiry"><?php _e( 'Expiry (MM/YYYY)', PAGSEGURO_DOMAIN ); ?> <span class="required">*</span></label>
            <input id="ps_transparent_card_expiry" name="ps_transparent_card_expiry" class="input-text wc-credit-card-form-card-expiry" type="tel" autocomplete="off" placeholder="MM / YYYY" onchange="sendToCard(this.value, 'card-expiry');" onkeyup="ps_mask_expiry(this.value,'ps_transparent_card_expiry');" style="font-size: 1.5em; padding: 8px;" />
        </p>
        <p class="form-row form-row-last">
            <label for="ps_transparent_card_cvv"><?php _e('CVV', PAGSEGURO_DOMAIN);?> <abbr class="required" title="Digite o código de segurança do Cartão">*</abbr></label>
            <input id="ps_transparent_card_cvv" maxlength="4" onfocus="toggleVerso('add');" onblur="checkCVV();toggleVerso('remove');" name="ps_transparent_card_cvv" class="input-text wc-credit-card-form-card-cvc" type="tel" autocomplete="off" placeholder="••••" style="font-size: 1.5em; padding: 8px;" />
        </p>

        <div class="clear"></div>
        <p class="form-row">
            <label for="ps_transparent_installments"><?php _e('Installments Number:', PAGSEGURO_DOMAIN);?> <abbr class="required" title="Selecione o número de parcelas">*</abbr></label>
            <select name="ps_transparent_installments" id="ps_transparent_installments" class="select_field box-fill" style="font-size: 1.5em; padding: 8px;" >
                <option value="">-- informe o n&uacute;mero do cart&atilde;o --</option>
            </select>
        </p>

    </div>


  <?php endif;?>
<?php if ($debit == 'yes'): ?>
    <div class="ps-transparent-payment-form ps-transparent-payment-form-debit" id="ps-transparent-payment-form-debit">
        <p class="form-row">
            <label for="ps_transparent_debit_cpf"><?php _e('CPF', PAGSEGURO_DOMAIN);?> <abbr class="required" title="Informe o CPF">*</abbr></label>
            <input type="text" name="ps_transparent_debit_cpf" id="ps_transparent_debit_cpf" onkeyup="ps_mask_cpf(this.value,'ps_transparent_debit_cpf');"  class="box-fill" style="font-size: 1.5em; padding: 8px;" />
        </p>
        <div class="form-row">
            <label><?php _e('Telefone', PAGSEGURO_DOMAIN);?>&nbsp;<abbr class="required">*</abbr></label>
            <p class="form-row">
                <input type="text" name="ps_transparent_debit_phone" id="ps_transparent_debit_phone" onkeyup="ps_mask_phone(this.value,'ps_transparent_debit_phone');"  class="box-fill" style="font-size: 1.5em; padding: 8px;" />
            </p>
        </div>
          <div class="form-row">
            <center>
        <ul id="ps_transparent_debit_flags" class="ul-bank-box"  >
        </ul>
    </center>
    </div>

    </div>
  <?php endif;?>
<?php if ($billet == 'yes'): ?>
    <div class="ps-transparent-payment-form ps-transparent-payment-form-billet" id="ps-transparent-payment-form-billet">
        <ul id="ps_transparent_billet_flags" class="ps-transparent-payment-group" style="clear: both;">
        </ul>
        <div  style="margin-bottom: 10px">
            <center>
                <img title="Boleto Bancário" class="billet-img" align="middle" style="float:none;margin: 0 auto; " src="<?php echo plugins_url( 'img/boleto.png', PAGSEGURO_BASE_DIR ); ?>" alt="Boleto Bancário" >
            </center>
        </div>

           <p class="form-row">
            <label for="ps_transparent_billet_cpf"><?php _e('CPF', PAGSEGURO_DOMAIN);?> <abbr class="required" title="Digite o CPF">*</abbr></label>
            <input type="text" name="ps_transparent_billet_cpf" id="ps_transparent_billet_cpf" maxlength="14"  onkeyup="ps_mask_cpf(this.value,'ps_transparent_billet_cpf');" class="input-text" style="font-size: 1.5em; padding: 8px;" />
        </p>
        <p class="form-row">
            <label for="ps_transparent_billet_phone"><?php _e('Telefone de Contato', PAGSEGURO_DOMAIN);?>&nbsp;<abbr class="required" title="Digite um telefone para contato">*</abbr></label>
            <input type="text" name="ps_transparent_billet_phone" id="ps_transparent_billet_phone" onkeyup="ps_mask_phone(this.value,'ps_transparent_billet_phone');" class="input-text" autocomplete="off" style="font-size: 1.5em; padding: 8px;" />
        </p>
        <p><?php echo $billet_message; ?></p>
        <?php if ($billet_extrafee_message == 'yes'): ?>
            <p id="ps_transparent_billet_tax">Tarifa de boleto = <strong>R$ 1,00</strong>
                <span>Tarifa aplicada para cobrir os custos de gestão de risco do meio de pagamento.</span>
            </p>
        <?php endif;?>
    </div>
</div>
<?php endif;?>
</fieldset>