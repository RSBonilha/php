<?php

if (!defined('ABSPATH')) {
    exit;
}

?>

<h4><?php _e('Payment Details', PAGSEGURO_DOMAIN);?></h4>
<div class="payment">
    <p>
        <strong><?php _e('Method:', PAGSEGURO_DOMAIN);?></strong>
        <?php echo '<span>'.$metodo.'</span>'; ?><br>
        <strong><?php _e('Transaction ID:', PAGSEGURO_DOMAIN);?></strong><br>
        <?php echo '<span style="word-wrap:break-word;">'.$t_id.'</span>'; ?><br>
        <strong><?php _e('PagSeguro Status:', PAGSEGURO_DOMAIN);?></strong>
        <?php echo '<span id="status">'.$status.'</span>'; ?><br>
        <strong><?php _e('Transaction Message:', PAGSEGURO_DOMAIN);?></strong>
        <?php echo '<span id="t_msg">'.$t_msg.'</span>'; ?><br>
        <?php if ($parcelas): ?>
            <strong><?php _e('Installments:', PAGSEGURO_DOMAIN);?></strong>
            <?php echo '<span>'.$parcelas.'</span>'; ?><br>
        <?php endif;?>
        <?php if ($bandeira): ?>
            <strong><?php _e('Card Brand:', PAGSEGURO_DOMAIN);?></strong>
            <?php echo '<span>'.$bandeira.'</span>'; ?><br>
        <?php endif;?>
        <input type="button" id="consult_transaction" value="<?php _e('Consulta', PAGSEGURO_DOMAIN)?>" class="button button-primary" style="margin-top:10px;"/>
        <script type="text/javascript">
            jQuery(document).ready(function() {
                jQuery('#consult_transaction').on('click', consultTransaction);
            });
            function consultTransaction(){
                jQuery('#consult_transaction').val('<?php _e('Consultando...', PAGSEGURO_DOMAIN)?>');
                jQuery('#consult_transaction').removeClass('button-primary');
                jQuery('#consult_transaction').attr('disabled', 'disabled');
                jQuery.ajax({
                   method: 'POST',
                   url: ajaxurl,
                   data :{
                       action: 'consultpagseguro',
                       order: '<?php echo $order_id; ?>',
                       transid: '<?php echo $t_id; ?>'
                   },
                   success: function(response){
                       //response = JSON.parse(response);
                       //jQuery('#t_msg').html(response.mensagem);
                       jQuery('#consult_transaction').val('<?php _e('Consultado', PAGSEGURO_DOMAIN)?>');
                       jQuery('#consult_transaction').removeClass('button-primary');
                       jQuery('#consult_transaction').attr('disabled', 'disabled');
                       location.reload();
                   }
               });
            }
        </script>
        <?php $allowedStatuses = array('1'); ?>
        <?php if ($billet_url && $metodo == 'boleto' && in_array($status, $allowedStatuses)): ?>
            <a id="billet_url" target="_blank" href="<?php echo $billet_url; ?>" class="button button-primary" style="margin-top:10px;"><?php _e('Imprimir Boleto', PAGSEGURO_DOMAIN)?></a>
        <?php elseif ($billet_url && $metodo == 'eft' && in_array($status, $allowedStatuses)): ?>
            <!--a id="billet_url" target="_blank" href="<?php echo $billet_url; ?>" class="button button-primary" style="margin-top:10px;"><?php _e('Transferência Bancária', PAGSEGURO_DOMAIN)?></a-->
        <?php endif;?>
    </p>
</div>