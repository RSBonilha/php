<?php

if (!defined('ABSPATH')) {
    exit;
}
?>
<script src="<?php echo plugin_dir_url(__DIR__)."js/masks.js"; ?>"></script>
<style>
    .billet-img {
        max-height: none !important;
        align-self: center !important;
    }
</style>

<script>
var pagseguro_submit = false;
var debug_js_billet = "<?php echo $debug_js; ?>";

jQuery( document ).ready(function() {
    session_id = "<?php echo $session_id; ?>";
    if(debug_js_billet) {
        console.log(session_id);
    }
    if(session_id == 0) {
        console.log('Não foi possível obter a session id do PagSeguro. Verifique suas configurações.');
    }
    PagSeguroDirectPayment.setSessionId(session_id);
    PagSeguroDirectPayment.getPaymentMethods({
        amount: <?php echo $total ?>,
        success: function(response) {
            if(debug_js_billet) {
                console.log('success');
            }
            jQuery.each(response.paymentMethods.BOLETO.options, function(index, option) {
                if(option.status == 'AVAILABLE') {
                    renderMethod('billet', option);
                }
                else {
                    if(debug_js_billet) {
                        console.log(option);
                    }
                }
            });
        },
        error: function(response) {
            if(debug_js_billet) {
                console.log('erro');
            }
        },
        complete: function(response) {
            if(debug_js_billet) {
                console.log(response);
            }
        }
    });
    getSenderHash();
});

jQuery( 'form.checkout' ).on( 'checkout_place_order_pagseguro-payment-billet', function(e) {
    return pagSeguroFormValidator('boleto');
});

jQuery( 'form#order_review' ).submit( function(e) {
    return pagSeguroFormValidator();
});
</script>

<fieldset id="ps-transparent-payment-fieldset" class="ps-transparent-payment-fieldset ">
    <input id="ps_transparent_sender_hash" type="hidden" name="ps_transparent_sender_hash" value=""/>
    <input type="hidden" name="ps-transparent-payment-radio" value="boleto"/>
    <div class="ps-transparent-payment-form ps-transparent-payment-form-billet" id="ps-transparent-payment-form-billet">
        <ul id="ps_transparent_billet_flags" class="ps-transparent-payment-group" style="clear: both;">
        </ul>
        <div  style="margin-bottom: 10px">
            <center>
                <img title="Boleto Bancário" class="billet-img" align="middle" style="float:none;margin: 0 auto; " src="<?php echo plugins_url( 'img/boleto.png', PAGSEGURO_BASE_DIR ); ?>" alt="Boleto Bancário" >
            </center>
        </div>

           <p class="form-row">
            <label for="ps_transparent_billet_cpf"><?php _e('CPF', PAGSEGURO_DOMAIN);?> <abbr class="required" title="Digite o CPF">*</abbr></label>
            <input type="text" name="ps_transparent_billet_cpf" id="ps_transparent_billet_cpf" maxlength="14"  onkeyup="ps_mask_cpf(this.value,'ps_transparent_billet_cpf');" class="input-text" style="font-size: 1.5em; padding: 8px;" />
        </p>
        <p class="form-row">
            <label for="ps_transparent_billet_phone"><?php _e('Telefone de Contato', PAGSEGURO_DOMAIN);?>&nbsp;<abbr class="required" title="Digite um telefone para contato">*</abbr></label>
            <input type="text" name="ps_transparent_billet_phone" id="ps_transparent_billet_phone" onkeyup="ps_mask_phone(this.value,'ps_transparent_billet_phone');" class="input-text" autocomplete="off" style="font-size: 1.5em; padding: 8px;" />
        </p>
        <p><?php echo $billet_message; ?></p>
        <?php if ($billet_extrafee_message == 'yes'): ?>
            <p id="ps_transparent_billet_tax">Tarifa de boleto = <strong>R$ 1,00</strong>
                <span>Tarifa aplicada para cobrir os custos de gestão de risco do meio de pagamento.</span>
            </p>
        <?php endif;?>
    </div>
</fieldset>