<?php

if (!defined('ABSPATH')) {
    exit;
}
?>
<script src="<?php echo plugin_dir_url(__DIR__)."js/masks.js"; ?>"></script>
<style>
/*Cartão de Crédito*/
#card_wrapper {
    width: 300px;
    max-width: 100%;
    height: 192px;
    max-height: 194px;
    text-align: center;
    margin: 30px auto;
    position: relative;
    overflow: hidden;
    z-index: 100;
}

#card_wrapper #card_container {
    background-image: url('<?php echo plugin_dir_url(__DIR__).'img/credit-card.png'; ?>');  /*../img/credit-card.png*/
    background-repeat: no-repeat;
    background-size: contain;
    background-position: center top;
    -webkit-perspective: 1000;
    -moz-perspective: 1000;
    -o-perspective: 1000;
    perspective: 1000;
    height: 390px;
    z-index: 50;
}

#card_wrapper #card_container>div.card-number {
    position: absolute;
    z-index: 150;
    top: 100px;
    left: 30px;
    color: #fff;
    text-shadow: 1px 1px 1px #333;
    font-size: 20px;
    font-weight: bold;
    font-family: 'Anonymous Pro';
}

#card_wrapper #card_container>div.card-name {
    position: absolute;
    z-index: 150;
    top: 160px;
    left: 15px;
    color: #fff;
    text-shadow: 1px 1px 1px #333;
    text-transform: uppercase;
    font-size: 14px;
    letter-spacing: 1px;
    font-family: 'Anonymous Pro';
    font-weight: bold;
}

#card_wrapper #card_container>div.card-expiry {
    position: absolute;
    z-index: 150;
    top: 136px;
    left: 160px;
    color: #fff;
    text-shadow: 1px 1px 1px #333;
    font-family: 'Anonymous Pro';
    font-size: 14px;
}

#card_wrapper #card_container>div.card-brand {
    position: absolute;
    z-index: 150;
    top: 156px;
    right: 6px;
    display: block;
    width: 60px;
    max-width: 60px;
    height: 40px;
    max-height: 40px;
    overflow: hidden;
}

#card_wrapper #card_container>span.card-cvv {
    position: absolute;
    display: none;
    z-index: 150;
    top: 97px;
    right: 52px;
    color: #333;
}

#card_wrapper #card_container.verso {
    background-position: center -195px;
}

#card_wrapper #card_container.verso>div {
    display: none;
}

#card_wrapper #card_container.verso>span.card-cvv {
    display: block;
}

.flipper {
    -webkit-transition: 0.6s;
    -webkit-transform-style: preserve-3d;
    -moz-transition: 0.6s;
    -moz-transform-style: preserve-3d;
    -o-transition: 0.6s;
    -o-transform-style: preserve-3d;
    transition: 0.6s;
    transform-style: preserve-3d;
    position: relative;
}
</style>

<script>
var pagseguro_submit = false;
var debug_js_credit = "<?php echo $debug_js; ?>";

jQuery( document ).ready(function() {
    session_id = "<?php echo $session_id; ?>";
    if(debug_js_credit) {
        console.log(session_id);
    }
    if(session_id == 0) {
        console.log('Não foi possível obter a session id do PagSeguro. Verifique suas configurações.');
    }
    PagSeguroDirectPayment.setSessionId(session_id);
    PagSeguroDirectPayment.getPaymentMethods({
        amount: <?php echo $total ?>,
        success: function(response) {
            if(debug_js_credit) {
                console.log('success');
            }
            jQuery.each(response.paymentMethods.CREDIT_CARD.options, function(index, option) {
                if(option.status == 'AVAILABLE') {
                    renderMethod('credit', option);
                }
                else {
                    if(debug_js_credit) {
                        console.log(option);
                    }
                }
            });
        },
        error: function(response) {
            if(debug_js_credit) {
                console.log('erro');
            }
        },
        complete: function(response) {
            if(debug_js_credit) {
                console.log(response);
            }
        }
    });
    jQuery('#ps_transparent_card_cvv').keyup(function(){validaPagSeguro()});
    jQuery('#ps_transparent_card_num').keyup(function(){validaPagSeguro()});
    jQuery('#ps_transparent_card_expiry').keyup(function(){validaPagSeguro()});
    //jQuery('#ps_transparent_card_venc_month').change(function(){validaPagSeguro()});
    //jQuery('#ps_transparent_card_venc_year').change(function(){validaPagSeguro()});
    var cc_num = document.querySelector('#ps_transparent_card_num');
    if(cc_num) {
        cc_num.onkeyup = function (e) {
            if (this.value == this.lastValue) return;
            var caretPosition = this.selectionStart;
            var sanitizedValue = this.value.replace(/[^0-9]/gi, '');
            var parts = [];

            for (var i = 0, len = sanitizedValue.length; i < len; i += 4) {
                parts.push(sanitizedValue.substring(i, i + 4));
            }

            for (var i = caretPosition - 1; i >= 0; i--) {
                var c = this.value[i];
                if (c < '0' || c > '9') {
                    caretPosition--;
                }
            }
            caretPosition += Math.floor(caretPosition / 4);

            this.value = this.lastValue = parts.join(' ');
            this.selectionStart = this.selectionEnd = caretPosition;
        }
        jQuery('#ps_transparent_card_num').focus();
    }
    getSenderHash();
});

jQuery( 'form.checkout' ).on( 'checkout_place_order_pagseguro-payment-credit', function(e) {
    return pagSeguroFormValidator('creditCard');
});

jQuery( 'form#order_review' ).submit( function(e) {
    return pagSeguroFormValidator();
});

</script>

<fieldset id="ps-transparent-payment-fieldset" class="ps-transparent-payment-fieldset ">
    <input id="ps_transparent_sender_hash" type="hidden" name="ps_transparent_sender_hash" value=""/>
    <div class="ps-transparent-payment-form ps-transparent-payment-form-card" id="ps-transparent-payment-form-card">
        <div id="card_show" class="col-xs-12 col-sm-6 pull-right nopadding-left" align="center">
                <div id="card_wrapper" class="nofloat">
                    <div id="card_container">
                        <div id="number_card" class="card-number anonymous">••••&nbsp; ••••&nbsp; ••••&nbsp; ••••</div>
                        <div class="card-name">TITULAR DO CARTÃO</div>
                        <div class="card-expiry"><span class="card-expiry-month">• •</span> / <span class="card-expiry-year">• •</span></div>
                        <div class="card-brand"></div>
                        <span class="card-cvv">•••</span>
                    </div>
                </div>
            </div>
        <ul id="ps_transparent_card_flags" class="ps-transparent-payment-group" style="clear: both;">
        </ul>
        <input type="hidden" name="ps-transparent-payment-radio" value="creditCard"/>
        <input id="ps_transparent_card_type" type="hidden" name="ps_transparent_card_type" value=""/>
        <input id="ps_transparent_card_token" type="hidden" name="ps_transparent_card_token" value=""/>
        <input id="ps_transparent_installment_value" type="hidden" name="ps_transparent_installment_value" value=""/>
        <br/>
          <p class="form-row">
            <label for="ps_transparent_name"><?php _e('Titular do Cartão', PAGSEGURO_DOMAIN);?>&nbsp;<abbr class="required" title="Digite exatamente o nome escrito na frente do cartão">*</abbr></label>
            <input type="text" name="ps_transparent_name" id="ps_transparent_name" class="input-text" autocomplete="off" style="font-size: 1.5em; padding: 8px;" onblur="sendToCard(this.value, 'card-name');" />
        </p>
          <p class="form-row">
            <label for="ps_transparent_cpf"><?php _e('CPF do portador do cartão', PAGSEGURO_DOMAIN);?> <abbr class="required" title="Digite o CPF do portador do Cartão">*</abbr></label>
            <input type="text" name="ps_transparent_cpf" id="ps_transparent_cpf" onkeyup="ps_mask_cpf(this.value,'ps_transparent_cpf');"  maxlength="14" class="input-text" style="font-size: 1.5em; padding: 8px;" />
        </p>
          <p class="form-row">
            <label for="ps_transparent_birthdate"><?php _e('Data de Nascimento', PAGSEGURO_DOMAIN);?> <abbr class="required" title="Digite a Data de Nascimento">*</abbr></label>
            <input type="text" name="ps_transparent_birthdate" id="ps_transparent_birthdate"  onkeyup="ps_mask_date(this.value,'ps_transparent_birthdate');" class="input-text" style="font-size: 1.5em; padding: 8px;" />
        </p>
        <p class="form-row">
            <label for="ps_transparent_phone"><?php _e('Telefone de Contato', PAGSEGURO_DOMAIN);?>&nbsp;<abbr class="required" title="Digite um telefone para contato">*</abbr></label>
            <input type="text" name="ps_transparent_phone" onkeyup="ps_mask_phone(this.value,'ps_transparent_phone');" id="ps_transparent_phone" class="input-text" autocomplete="off" style="font-size: 1.5em; padding: 8px;" />
        </p>

        <p class="form-row">
            <label for="ps_transparent_card_num"><?php _e('Número do Cartão', PAGSEGURO_DOMAIN);?>&nbsp;<abbr class="required" title="Digite o número do cartão">*</abbr></label>
            <input type="text" name="ps_transparent_card_num" id="ps_transparent_card_num" maxlength="19" class="input-text" autocomplete="off" placeholder="&bull;&bull;&bull;&bull; &bull;&bull;&bull;&bull; &bull;&bull;&bull;&bull; &bull;&bull;&bull;&bull;" style="font-size: 1.5em; padding: 8px; width:85%; "   onblur="sendToCard(this.value, 'card-number');" />
            <span style="padding-right:3px; padding-top: 3px; display:inline-block;">
               <img id="ps_transparent_cc_type_icon" src="" style="width:50px;"></img>
            </span>
        </p>

        <p class="form-row form-row-first">
            <label for="ps_transparent_card_expiry"><?php _e( 'Expiry (MM/YYYY)', PAGSEGURO_DOMAIN ); ?> <span class="required">*</span></label>
            <input id="ps_transparent_card_expiry" name="ps_transparent_card_expiry" class="input-text wc-credit-card-form-card-expiry" type="tel" autocomplete="off" placeholder="MM / YYYY" onchange="sendToCard(this.value, 'card-expiry');" onkeyup="ps_mask_expiry(this.value,'ps_transparent_card_expiry');" style="font-size: 1.5em; padding: 8px;" />
        </p>
        <p class="form-row form-row-last">
            <label for="ps_transparent_card_cvv"><?php _e('CVV', PAGSEGURO_DOMAIN);?> <abbr class="required" title="Digite o código de segurança do Cartão">*</abbr></label>
            <input id="ps_transparent_card_cvv" maxlength="4" onfocus="toggleVerso('add');" onblur="checkCVV();toggleVerso('remove');" name="ps_transparent_card_cvv" class="input-text wc-credit-card-form-card-cvc" type="tel" autocomplete="off" placeholder="••••" style="font-size: 1.5em; padding: 8px;" />
        </p>

        <div class="clear"></div>
        <p class="form-row">
            <label for="ps_transparent_installments"><?php _e('Installments Number:', PAGSEGURO_DOMAIN);?> <abbr class="required" title="Selecione o número de parcelas">*</abbr></label>
            <select name="ps_transparent_installments" id="ps_transparent_installments" class="select_field box-fill" style="font-size: 1.5em; padding: 8px;" >
                <option value="">-- informe o n&uacute;mero do cart&atilde;o --</option>
            </select>
        </p>

    </div>
</fieldset>
