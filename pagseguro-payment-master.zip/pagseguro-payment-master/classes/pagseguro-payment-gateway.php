<?php

if (!defined('ABSPATH')) {
    exit;
}

class WC_Pagseguro_Payment_Gateway extends WC_Payment_Gateway
{

    public function __construct()
    {
        $this->id = 'pagseguro-payment';
        //$this->icon               = apply_filters( 'woocommerce_pagseguro_icon', plugins_url( 'assets/images/pagseguro.png', plugin_dir_path( __FILE__ ) ) );
        //$this->icon = apply_filters('woocommerce_pagseguro_payment_icon', plugins_url('img/logo_pagseguro.png', PAGSEGURO_BASE_DIR));
        $this->method_title = __('PagSeguro Payment', PAGSEGURO_DOMAIN);
        $this->method_description = __('Accept payments via PagSeguro.', PAGSEGURO_DOMAIN);
        $this->has_fields = true;
        //$this->order_button_text = __('Proceed to payment', PAGSEGURO_DOMAIN);

        $this->init_form_fields();
        $this->init_settings();

        // Define user set variables.
        $this->title = $this->get_option('title');
        $this->description = $this->get_option('description');

        $this->email = $this->get_option('email');
        $this->token = $this->get_option('token');
        $this->sandbox_email = $this->get_option('sandbox_email');
        $this->sandbox_token = $this->get_option('sandbox_token');

        $this->pagseguro_environment = $this->get_option('pagseguro_environment', 'sandbox');
        $this->mode = $this->get_option('pagseguro_mode', 'transparent');
        $this->redirect_message = $this->get_option('redirect_message');

        $this->credit = $this->get_option('credit', 'yes');
        $this->debit = $this->get_option('debit', 'yes');
        $this->billet = $this->get_option('billet', 'yes');
        $this->billet_message = $this->get_option('billet_message');
        $this->billet_extrafee_message = $this->get_option('billet_extrafee_message', 'yes');
        $this->credit_max_installment = $this->get_option('maximum_installment', 6);
        $this->credit_interest_free = $this->get_option('interest_free_installment', 6);
        $this->billet_discount = $this->get_option('billet_discount', 'none');
        $this->billet_discount_amount = $this->get_option('billet_discount_amount', 0);

        $this->debug = $this->get_option('debug');
        $this->analysisStatuses = array('1', '2');
        $this->approvedStatuses = array('3', '4');
        $this->reprovedStatuses = array('5', '6', '7', '8');
        $this->supports = array('products', 'refunds');
        $this->method = null;

        $this->context = array('source' => $this->id);
        if (function_exists('wc_get_logger')) {
            $this->log = wc_get_logger();
        } else {
            $this->log = new WC_Logger();
        }

        // Main actions.
        //add_action('woocommerce_api_wc_pagseguro_gateway', array($this, 'ipn_handler'));
        //add_action('valid_pagseguro_ipn_request', array($this, 'update_order_status'));
        add_action('woocommerce_update_options_payment_gateways_'.$this->id, array($this, 'process_admin_options'));
        add_action('woocommerce_admin_order_data_after_shipping_address', array($this, 'order_info'));
        //add_action('woocommerce_receipt_'.$this->id, array($this, 'receipt_page'));

        // Transparent checkout actions.
        //if ($this->mode == 'transparent') {
            //add_action('woocommerce_thankyou_'.$this->id, array($this, 'order_received'));
            //add_action('woocommerce_order_details_after_order_table', array($this, 'pending_payment_message'), 5);
            //add_action('woocommerce_email_after_order_table', array($this, 'email_instructions'), 10, 3);
            //add_action('wp_enqueue_scripts', array($this, 'checkout_scripts'));
        //}
    }

    public function init_form_fields()
    {
        $statuses = array('' => '-- Selecione um status --');
        $statuses = array_merge($statuses, wc_get_order_statuses());
        $url = get_site_url().'/wc-api/wc_gateway_callback/';
        $this->form_fields = array(
            'enabled'                   => array(
                'title'    => __('Enable / Disable', PAGSEGURO_DOMAIN),
                'type'     => 'checkbox',
                'label'    => __('Enable PagSeguro Payment', PAGSEGURO_DOMAIN),
                'desc_tip' => false,
                'default'  => 'yes',
            ),
            'title'                     => array(
                'title'       => __('Method Title', PAGSEGURO_DOMAIN),
                'type'        => 'text',
                'description' => __('This controls the title that users will see during checkout.', PAGSEGURO_DOMAIN),
                'default'     => __('PagSeguro', PAGSEGURO_DOMAIN),
                'desc_tip'    => true,
            ),

            'pagseguro_mode'            => array(
                'title'       => __('Integration type', PAGSEGURO_DOMAIN),
                'type'        => 'select',
                'description' => __('Choose how the customer will interact with the PagSeguro. Redirect (Client goes to PagSeguro page) or Transparent Checkout', PAGSEGURO_DOMAIN),
                'desc_tip'    => true,
                'default'     => 'transparent',
                'class'       => 'wc-enhanced-select',
                'options'     => array(
                    'redirect'    => __('Redirect', PAGSEGURO_DOMAIN),
                    'transparent' => __('Transparent Checkout', PAGSEGURO_DOMAIN),
                ),
            ),

            'pagseguro_environment'     => array(
                'title'    => __('PagSeguro Environment', PAGSEGURO_DOMAIN),
                'type'     => 'select',
                'desc_tip' => true,
                'default'  => 'production',
                'label'    => __('Choose Environment for PagSeguro Integration', PAGSEGURO_DOMAIN),
                'options'  => array(
                    'sandbox'    => __('Sandbox', PAGSEGURO_DOMAIN),
                    'production' => __('Production', PAGSEGURO_DOMAIN),
                ),
            ),
            'email'                     => array(
                'title'       => __('PagSeguro Email', PAGSEGURO_DOMAIN),
                'type'        => 'text',
                'description' => __('PagSeguro Email Address', PAGSEGURO_DOMAIN),
                'default'     => '',
                'desc_tip'    => false,
            ),
            'token'                     => array(
                'title'       => __('PagSeguro Token', PAGSEGURO_DOMAIN),
                'type'        => 'text',
                'description' => __('PagSeguro Token', PAGSEGURO_DOMAIN),
                'default'     => '',
                'desc_tip'    => false,
            ),

            'sandbox_email'             => array(
                'title'       => __('PagSeguro Sandbox Email', PAGSEGURO_DOMAIN),
                'type'        => 'text',
                'description' => __('PagSeguro Sandbox Email Address', PAGSEGURO_DOMAIN),
                'default'     => '',
                'desc_tip'    => false,
            ),
            'sandbox_token'             => array(
                'title'       => __('PagSeguro Sandbox Token', PAGSEGURO_DOMAIN),
                'type'        => 'text',
                'description' => __('PagSeguro Sandbox Token', PAGSEGURO_DOMAIN),
                'default'     => '',
                'desc_tip'    => false,
            ),

            'redirect_message'          => array(
                'title'       => __('Redirect Message', PAGSEGURO_DOMAIN),
                'type'        => 'text',
                'description' => __('Message showed to client on checkout', PAGSEGURO_DOMAIN),
                'default'     => __('Confirm your order to be redirected to the payment page.'),
                'desc_tip'    => false,
            ),

            'transparent_checkout'      => array(
                'title'       => __('Transparent Checkout Options', PAGSEGURO_DOMAIN),
                'type'        => 'title',
                'description' => '',
            ),
            'credit'                    => array(
                'title'   => __('Credit Card', PAGSEGURO_DOMAIN),
                'type'    => 'checkbox',
                'label'   => __('Enable Credit Card for Transparente Checkout', PAGSEGURO_DOMAIN),
                'default' => 'yes',
            ),
            'debit'                     => array(
                'title'   => __('Debit', PAGSEGURO_DOMAIN),
                'type'    => 'checkbox',
                'label'   => __('Enable Debit for Transparente Checkout', PAGSEGURO_DOMAIN),
                'default' => 'yes',
            ),
            'billet'                    => array(
                'title'   => __('Billet', PAGSEGURO_DOMAIN),
                'type'    => 'checkbox',
                'label'   => __('Enable Billet for Transparente Checkout', PAGSEGURO_DOMAIN),
                'default' => 'yes',
            ),

            'credit_card_block'         => array(
                'title'       => __('Credit Card Options', PAGSEGURO_DOMAIN),
                'type'        => 'title',
                'description' => '',
            ),
            'maximum_installment'       => array(
                'title'       => __('Installment Within', PAGSEGURO_DOMAIN),
                'type'        => 'select',
                'description' => __('Maximum number of installments for orders in your store.', PAGSEGURO_DOMAIN),
                'desc_tip'    => true,
                'class'       => 'wc-enhanced-select',
                'default'     => '6',
                'options'     => array(
                    '1'  => '1x',
                    '2'  => '2x',
                    '3'  => '3x',
                    '4'  => '4x',
                    '5'  => '5x',
                    '6'  => '6x',
                    '7'  => '7x',
                    '8'  => '8x',
                    '9'  => '9x',
                    '10' => '10x',
                    '11' => '11x',
                    '12' => '12x',
                ),
            ),
            'interest_free_installment' => array(
                'title'       => __('Interest-Free Installment', PAGSEGURO_DOMAIN),
                'type'        => 'select',
                'description' => __('Number of interest-free installments', PAGSEGURO_DOMAIN),
                'desc_tip'    => true,
                'class'       => 'wc-enhanced-select',
                'default'     => '6',
                'options'     => array(
                    '1'  => '1x',
                    '2'  => '2x',
                    '3'  => '3x',
                    '4'  => '4x',
                    '5'  => '5x',
                    '6'  => '6x',
                    '7'  => '7x',
                    '8'  => '8x',
                    '9'  => '9x',
                    '10' => '10x',
                    '11' => '11x',
                    '12' => '12x',
                ),
            ),

            'billet_block'              => array(
                'title'       => __('Billet Options', PAGSEGURO_DOMAIN),
                'type'        => 'title',
                'description' => '',
            ),
            'billet_extrafee_message'   => array(
                'title'   => __('Billet Tax Message', PAGSEGURO_DOMAIN),
                'type'    => 'checkbox',
                'label'   => __('Display a message alerting the customer that will be charged R$ 1,00 for payment by Billet', PAGSEGURO_DOMAIN),
                'default' => 'yes',
            ),
            'billet_message'            => array(
                'title'       => __('Billet Checkout Message', PAGSEGURO_DOMAIN),
                'type'        => 'text',
                'description' => __('This controls the message that users will see before print the billet.', PAGSEGURO_DOMAIN),
                'default'     => __('Após a confirmação do pedido, lembre-se de quitar o boleto o mais rápido possível.', PAGSEGURO_DOMAIN),
            ),
            'billet_discount'           => array(
                'title'    => __('Billet Discount Type', PAGSEGURO_DOMAIN),
                'type'     => 'select',
                'desc_tip' => true,
                'default'  => 'none',
                'label'    => __('Choose between no discount, fixed amount and percentage discount', PAGSEGURO_DOMAIN),
                'options'  => array(
                    'none'    => __('None', PAGSEGURO_DOMAIN),
                    'fixed'   => __('Fixed Amount', PAGSEGURO_DOMAIN),
                    'percent' => __('Percentage (%)', PAGSEGURO_DOMAIN),
                ),
            ),
            'billet_discount_amount'    => array(
                'title'    => __('Billet Discount Amount', PAGSEGURO_DOMAIN),
                'type'     => 'text',
                'desc_tip' => true,
                'default'  => 0,
                'label'    => __('Inform the desired amount of discount', PAGSEGURO_DOMAIN),
            ),

            'extra_options'             => array(
                'title'       => __('Extra Options', PAGSEGURO_DOMAIN),
                'type'        => 'title',
                'description' => '',
            ),
            'debug'                     => array(
                'title'       => __('Enable Module Logs', PAGSEGURO_DOMAIN),
                'label'       => __('Enable', PAGSEGURO_DOMAIN),
                'type'        => 'checkbox',
                'desc_tip'    => false,
                'default'     => 'no',
                'description' => sprintf(__('Acesso aos logs do módulo: %s', PAGSEGURO_DOMAIN), $this->link_log()),
            ),
            'debug_js'                  => array(
                'title'    => __('Enable JavaScript Debug', PAGSEGURO_DOMAIN),
                'label'    => __('Enable only if PagSeguro support asks for', PAGSEGURO_DOMAIN),
                'type'     => 'checkbox',
                'desc_tip' => false,
                'default'  => 'no',
            ),
            'status_iniciado'           => array(
                'title'       => __('Status Iniciado', PAGSEGURO_DOMAIN),
                'type'        => 'select',
                'desc_tip'    => true,
                'description' => __('O pedido mudará automaticamente para este status em caso de aprovação no PagSeguro', PAGSEGURO_DOMAIN),
                'default'     => '',
                'options'     => $statuses,
            ),
            'status_aprovado'           => array(
                'title'       => __('Status Aprovado', PAGSEGURO_DOMAIN),
                'type'        => 'select',
                'desc_tip'    => true,
                'description' => __('O pedido mudará automaticamente para este status em caso de aprovação no PagSeguro', PAGSEGURO_DOMAIN),
                'default'     => '',
                'options'     => $statuses,
            ),
            'status_cancelado'          => array(
                'title'       => __('Status Cancelado', PAGSEGURO_DOMAIN),
                'type'        => 'select',
                'desc_tip'    => true,
                'description' => __('O pedido mudará automaticamente para este status quando a transação for cancelada no PagSeguro', PAGSEGURO_DOMAIN),
                'default'     => '',
                'options'     => $statuses,
            ),
            'status_aguardando'         => array(
                'title'       => __('Status Aguardando', PAGSEGURO_DOMAIN),
                'type'        => 'select',
                'desc_tip'    => true,
                'description' => __('O pedido mudará automaticamente para este status quando a transação estiver no status aguardando no PagSeguro', PAGSEGURO_DOMAIN),
                'default'     => '',
                'options'     => $statuses,
            ),
        );
    }

    /**
     * Display pending payment message in order details.
     *
     * @param  int $order_id Order id.
     *
     * @return string        Message HTML.
     */
    public static function pending_payment_message($order_id)
    {
        $order = new WC_Order($order_id);
        $order_id = is_callable(array($order, 'get_id')) ? $order->get_id() : $order->id;
        $method = is_callable(array($order, 'get_payment_method')) ? $order->get_payment_method() : $order->payment_method;
        $urlBoleto = get_post_meta($order_id, '_ps_billet_url', true);
        $status = get_post_meta($order_id, '_ps_status', true);
        $allowedStatuses = array('1');
        if (!empty($urlBoleto) && $method == PAGSEGURO_DOMAIN && in_array($status, $allowedStatuses)) {
            if ('boleto' == get_post_meta($order_id, '_ps_method', true)) {
                $textoBotao = __('Imprimir Boleto');
                $mensagem = __('Clique no link ao lado para imprimir o boleto.');
            } else {
                $textoBotao = __('Transferência Bancária');
                $mensagem = __('Clique no link ao lado para ir para a tela do banco.');
                //não exibir botão EFT na página
                $urlBoleto = '';
            }
            if (!empty($urlBoleto)) {
                $html = '<div class="woocommerce-info">';
                $html .= sprintf('<a class="button" href="%s" target="_blank" style="display: block !important; visibility: visible !important;">%s</a>', esc_url($urlBoleto), $textoBotao.' &rarr;');
                $html .= $mensagem.'<br />';
                $html .= '</div>';
                echo $html;
            }
        }
    }

    public function order_received($order_id)
    {
        $order = new WC_Order($order_id);
        $method = is_callable(array($order, 'get_payment_method')) ? $order->get_payment_method() : $order->payment_method;
        $additional = '';
        if ($method == $this->id) {
            $urlBoleto = get_post_meta($order_id, '_ps_billet_url', true);
            $email = method_exists($order, 'get_billing_email') ? $order->get_billing_email() : $order->billing_email;
            $msg = sprintf(__('Você receberá um e-mail em %s com todos os detalhes do pedido.', PAGSEGURO_DOMAIN), $email);
            $mensagem = '';
            $class = 'woocommerce-info';
            if ('boleto' == get_post_meta($order_id, '_ps_method', true)) {
                $mensagem .= __('Pending Payment.', PAGSEGURO_DOMAIN)." $msg <br />";
                $mensagem .= "Não esqueça de pagar seu boleto o mais rápido possível. <br />";
                $mensagem .= "Seu pedido só será processado após a confirmação do pagamento.";
            } elseif ('eft' == get_post_meta($order_id, '_ps_method', true)) {
                $mensagem .= __('Pending Payment.', PAGSEGURO_DOMAIN)." $msg <br />";
                $mensagem .= "Não esqueça de efetivar a transferência o mais rápido possível. <br />";
                $mensagem .= "Seu pedido só será processado após a confirmação do pagamento.";

                $textoBotao = __('Transferência Bancária');
                $mensagemBotao = __('Clique no link ao lado para ir para a tela do banco.');
                $additional = '<div class="woocommerce-info">';
                $additional .= sprintf('<a class="button" href="%s" target="_blank" style="display: block !important; visibility: visible !important;">%s</a>', esc_url($urlBoleto), $textoBotao.' &rarr;');
                $additional .= $mensagemBotao.'<br />';
                $additional .= '</div>';
            } else {
                $status = get_post_meta($order_id, '_ps_status', true);
                if (in_array($status, $this->approvedStatuses)) {
                    $mensagem .= __('Approved Payment.', PAGSEGURO_DOMAIN)." $msg <br />";
                    $class = 'woocommerce-message';
                } elseif (in_array($status, $this->analysisStatuses) || !in_array($status, $this->reprovedStatuses)) {
                    //timeout ou análise
                    $mensagem .= "Estamos aguardando a confirmação de pagamento e em breve sua compra será efetivada. <br />";
                    $mensagem .= "Assim que isso ocorrer, você será notificado por e-mail.";
                } else {
                    //reprovado / erro
                    $class = 'woocommerce-error';
                    $mensagem .= __('Not Authorised Payment.', PAGSEGURO_DOMAIN)." <br />";
                    $mensagem .= "Algum dado pode estar incorreto ou ocorreu algum problema com a operadora. <br />";
                    $mensagem .= "Por favor, revise seus dados de pagamento e tente novamente.";
                }
            }
            if (!empty($mensagem)) {
                $html = '<div class="'.$class.'">';
                $html .= $mensagem.'<br />';
                $html .= '</div>';
                echo $html;
            }
            if (!empty($additional)) {
                echo $additional;
            }
        }
    }

    public function is_available()
    {
        return false;
    }

    public function admin_options()
    {
        wp_enqueue_script('pagseguro-config', plugins_url('js/config.js', plugin_dir_path(__FILE__)), array('jquery'), PAGSEGURO_VERSION, true);

        parent::admin_options();
    }

    public function get_email()
    {
        return $this->is_sandbox() ? $this->method->sandbox_email : $this->method->email;
    }

    public function get_token()
    {
        return $this->is_sandbox() ? $this->method->sandbox_token : $this->method->token;
    }

    public function is_sandbox()
    {
        return $this->method->pagseguro_environment == 'sandbox';
    }

    public function is_production()
    {
        return $this->method->pagseguro_environment == 'production';
    }

    public function is_transparent()
    {
        return true;
    }

    public function getSessionId()
    {
        if(WC()->session) {
            $session_id = WC()->session->get('pagseguro_payment_session_id');
            if (empty($session_id)) {
                $this->writeLog("getSessionId()", false, 'info');
                try {
                    $param = "?email={$this->get_email()}&token={$this->get_token()}";
                    if ($this->is_transparent()) {
                        $url = "https://ws.sandbox.pagseguro.uol.com.br/v2/sessions$param";
                        $environment = 'sandbox';
                        if ($this->is_production()) {
                            $url = "https://ws.pagseguro.uol.com.br/v2/sessions$param";
                            $environment = 'production';
                        }
                        $args = array();
                        $result = wp_remote_post($url, $args);
                        if (is_wp_error($result)) {
                            $this->writeLog('Erro WP_Error: '.$result->get_error_message(), false, 'error');
                            $this->writeLog("Erro ao obter SessionID, verifique as credenciais", false, 'error');
                            $session_id = '';
                        } else {
                            if ($result) {
                                $xml = simplexml_load_string($result['body'], 'SimpleXMLElement', LIBXML_NOERROR);
                                $json = json_decode(json_encode($xml), true);
                                $id = array_shift($json);
                                $session_id = $id;
                                $this->writeLog('SessionID: '.$session_id, false, 'info');
                                WC()->session->set('pagseguro_payment_session_id', $id);
                            } else {
                                $this->writeLog("Erro ao obter SessionID, verifique as credenciais", false, 'error');
                                $session_id = '';
                            }
                        }
                    }
                } catch (Exception $e) {
                    $this->writeLog("Exception getSessionId()", false, 'error');
                    $this->writeLog($e->getMessage(), false, 'error');
                    $session_id = '';
                }
            }
            return $session_id;
        }
        return false;
    }

    public function domain()
    {
        return 'pagseguro.uol.com.br';
    }

    public function static_path()
    {
        return 'https://stc.'.($this->is_sandbox() ? 'sandbox.' : '').$this->domain();
    }

    public function ws_path()
    {
        return 'https://ws.'.($this->is_sandbox() ? 'sandbox.' : '').$this->domain();
    }

    public function consult_transaction_url($transaction_code)
    {
        if (!empty($transaction_code)) {
            return $this->ws_path().'/v3/transactions/'.$transaction_code;
        } else {
            return $this->ws_path().'/v2/transactions';
        }
    }

    public function notification_url($notification_code)
    {
        return $this->ws_path().'/v3/transactions/notifications/'.$notification_code;
    }

    public function payment_fields()
    {
        if ($this->is_transparent()) {
            $total = $this->get_order_total();

            $params = array(
                'credit'                  => $this->credit,
                'debit'                   => $this->debit,
                'billet'                  => $this->billet,
                'billet_message'          => $this->billet_message,
                'billet_extrafee_message' => $this->billet_extrafee_message,
                'credit_max_installment'  => $this->credit_max_installment,
                'credit_interest_free'    => $this->credit_interest_free,
                'session_id'              => $this->getSessionId(),
                'static_path'             => 'https://stc.pagseguro.uol.com.br',
                'total'                   => $total,
                'ano'                     => date('Y'),
                'errors'                  => array(
                    'invalid_card'        => __('Invalid credit card number.', PAGSEGURO_DOMAIN),
                    'invalid_cvv'         => __('Invalid CVV.', PAGSEGURO_DOMAIN),
                    'invalid_name'        => __('Invalid name.', PAGSEGURO_DOMAIN),
                    'invalid_expiry'      => __('Invalid expiry date.', PAGSEGURO_DOMAIN),
                    'expired_card'        => __('Expired card.', PAGSEGURO_DOMAIN),
                    'invalid_cpf'         => __('Invalid CPF.', PAGSEGURO_DOMAIN),
                    'invalid_birthdate'   => __('Invalid birthdate.', PAGSEGURO_DOMAIN),
                    'invalid_phone'       => __('Invalid phone.', PAGSEGURO_DOMAIN),
                    'invalid_installment' => __('Please choose an installment option.', PAGSEGURO_DOMAIN),
                ),
            );
            wc_get_template(
                'pagseguro-payment-transparent.php', $params, '', WC_Pagseguro_Payment::get_template_dir()
            );
        } else {
            echo $this->redirect_message;
        }
    }

    public function format_woo_version($version)
    {
        $aux = explode('.',$version);
        $formatted = $aux[0].'.'.(array_key_exists(1, $aux) ? $aux[1] : 0);
        return $formatted;
    }

    public function getPagSeguroMessage($status)
    {
        switch ($status) {
            case '1':
                $message = 'Aguardando Pagamento';
                break;
            case '2':
                $message = 'Em Análise';
                break;
            case '3':
                $message = 'Paga';
                break;
            case '4':
                $message = 'Disponível';
                break;
            case '5':
                $message = 'Em Disputa';
                break;
            case '6':
                $message = 'Devolvida';
                break;
            case '7':
                $message = 'Cancelada';
                break;
            case '8':
                $message = 'Chargeback Debitado';
                break;
            case '9':
                $message = 'Em Contestação';
                break;
            default:
                $message = 'Erro ao obter o status';
                break;
        }
        return $message;
    }

    public function updateOrderStatus($order, $status, $type = '')
    {
        $order_id = method_exists($order, 'get_id') ? $order->get_id() : $order->id;
        $mensagem = '';
        $status_iniciado = $this->get_option('status_iniciado');
        $status_aprovado = $this->get_option('status_aprovado');
        $status_cancelado = $this->get_option('status_cancelado');
        $status_aguardando = $this->get_option('status_aguardando');
        $this->writeLog("updateOrderStatus()", false, 'info');
        $this->writeLog("OrderID: ".$order_id, false, 'info');
        $this->writeLog("Status PagSeguro: ".$status, false, 'info');

        switch ($status) {
            case '1':
                //Aguardando Pagamento
                $mensagem = 'Aguardando pagamento: o comprador iniciou a transação, mas até o momento o PagSeguro não recebeu nenhuma informação sobre o pagamento.';
                $this->mudaStatus($order, $status_iniciado, __('PagSeguro: The buyer initiated the transaction, but so far the PagSeguro not received any payment information.', PAGSEGURO_DOMAIN));
                break;
            case '2':
                //Em Análise
                $mensagem = 'Em análise: o comprador optou por pagar com um cartão de crédito e o PagSeguro está analisando o risco da transação.';
                $this->mudaStatus($order, $status_aguardando, __('PagSeguro: Payment under review.', PAGSEGURO_DOMAIN));
                break;
            case '3':
                //Paga
                $mensagem = 'Paga: a transação foi paga pelo comprador e o PagSeguro já recebeu uma confirmação da instituição financeira responsável pelo processamento.';
                $this->mudaStatus($order, $status_aprovado, __('PagSeguro: Payment approved.', PAGSEGURO_DOMAIN));
                break;
            case '4':
                //Disponível
                $mensagem = 'Disponível: a transação foi paga e chegou ao final de seu prazo de liberação sem ter sido retornada e sem que haja nenhuma disputa aberta.';
                $this->mudaStatus($order, $status_aprovado, __('PagSeguro: Payment completed and credited to your account.', PAGSEGURO_DOMAIN));
                break;
            case '5':
                //Em Disputa
                $mensagem = 'Em disputa: o comprador, dentro do prazo de liberação da transação, abriu uma disputa.';
                $this->mudaStatus($order, $status_cancelado, __('PagSeguro: Payment came into dispute.', PAGSEGURO_DOMAIN));
                break;
            case '6':
                //Devolvida
                $mensagem = 'Devolvida: o valor da transação foi devolvido para o comprador.';
                $this->mudaStatus($order, $status_cancelado, __('PagSeguro: Payment refunded.', PAGSEGURO_DOMAIN));
                break;
            case '7':
                //Cancelada
                $mensagem = 'Retentativa: a transação ia ser cancelada (status 7), mas a opção de retentativa estava ativada. O pedido será cancelado posteriormente caso o cliente não use o link de retentativa no prazo estabelecido.';
                $this->mudaStatus($order, $status_cancelado, __('PagSeguro: Payment canceled.', PAGSEGURO_DOMAIN));
                break;
            case '8':
                //Chargeback Debitado
                $mensagem = 'Debitado: o valor do chargeback foi debitado da sua conta.';
                $this->mudaStatus($order, $status_cancelado, __('PagSeguro: Payment refunded.', PAGSEGURO_DOMAIN));
                break;
            case '9':
                //Em Contestação
                $mensagem = 'Em contestação: o titular do cartão contestou a transação.';
                $this->mudaStatus($order, $status_cancelado, __('PagSeguro: Payment refunded.', PAGSEGURO_DOMAIN));
                break;
            default:
                break;
        }
        if (!empty($mensagem)) {
            $mensagem = !empty($type) ? '['.strtoupper($type).'] '.$mensagem : $mensagem;
            $this->writeLog("Mensagem: ".$mensagem, false, 'info');
            $order->add_order_note($mensagem);
        }
    }

    public function reduceStock($order_id)
    {
        if (function_exists('wc_reduce_stock_levels')) {
            wc_reduce_stock_levels($order_id);
        }
    }

    public function increaseStock($order_id)
    {
        if (function_exists('wc_increase_stock_levels')) {
            wc_increase_stock_levels($order_id);
        }
    }

    public static function mudaStatus($order, $status, $mensagem)
    {
        if (!empty($status)) {
            $order->update_status($status, $mensagem.' - ');
        }
    }

    public function validate_fields()
    {
        return true;
    }

    public function direct_script()
    {
        return $this->static_path().'/pagseguro/api/v2/checkout/pagseguro.directpayment.js';
    }

    public function checkout_scripts()
    {
        if (is_checkout() && $this->is_available()) {
            $functionsjs = $this->method->debug_js == 'yes' ? '/js/pagseguro-functions-debug.js' : '/js/pagseguro-functions.js';

            wp_enqueue_script('pagseguro-directpayment-js', $this->direct_script(), array(), null, true);
            wp_enqueue_script('pagseguro-cpfcnpj-js', plugins_url('js/cpf_cnpj.js', plugin_dir_path(__FILE__)), array(), null, true);
            wp_enqueue_script('pagseguro-functions', plugins_url( $functionsjs, plugin_dir_path( __FILE__ ) ), array( 'jquery', 'pagseguro-directpayment-js' ), PAGSEGURO_VERSION, true );

            $total = $this->get_order_total();
            wp_localize_script(
                'pagseguro-functions',
                'pagseguro_payment_card_params',
                array(
                    'credit_max_installment' => $this->method->credit_max_installment,
                    'credit_interest_free' => $this->method->credit_interest_free,
                    'total' => $total,
                    'invalid_card'        => __('Invalid credit card number.', PAGSEGURO_DOMAIN),
                    'invalid_cvv'         => __('Invalid CVV.', PAGSEGURO_DOMAIN),
                    'invalid_name'        => __('Invalid name.', PAGSEGURO_DOMAIN),
                    'invalid_expiry'      => __('Invalid expiry date.', PAGSEGURO_DOMAIN),
                    'expired_card'        => __('Expired card.', PAGSEGURO_DOMAIN),
                    'invalid_cpf'         => __('Invalid CPF.', PAGSEGURO_DOMAIN),
                    'invalid_birthdate'   => __('Invalid birthdate.', PAGSEGURO_DOMAIN),
                    'invalid_phone'       => __('Invalid phone.', PAGSEGURO_DOMAIN),
                    'invalid_installment' => __('Please choose an installment option.', PAGSEGURO_DOMAIN),
                )
            );
        }
    }

    public function process_payment($order_id)
    {
        $this->writeLog('----- INÍCIO DO PAGAMENTO -----', false, 'info');
        global $woocommerce;
        global $wp_version;
        $order = new WC_Order($order_id);
        $erro = false;
        $total = (float) $order->get_total();
        $method = $_POST['ps-transparent-payment-radio'];

        if ($method == 'creditCard') {
            $cc_token = (isset($_POST['ps_transparent_card_token'])) ? $_POST['ps_transparent_card_token'] : '';
            $cc_numero = (isset($_POST['ps_transparent_card_num'])) ? $_POST['ps_transparent_card_num'] : '';
            $cc_numero = preg_replace('/\s+/', '', $cc_numero);
            $cc_nome = (isset($_POST['ps_transparent_name'])) ? $_POST['ps_transparent_name'] : '';
            $cc_cvv = (isset($_POST['ps_transparent_card_cvv'])) ? $_POST['ps_transparent_card_cvv'] : '';
            $cc_vencto = (isset($_POST['ps_transparent_card_expiry'])) ? $_POST['ps_transparent_card_expiry'] : '';
            $cc_val_mes = substr($cc_vencto, 0, 2);
            $cc_val_ano = substr($cc_vencto, -4, 4);
            $cc_bandeira = (isset($_POST['ps_transparent_card_type'])) ? $_POST['ps_transparent_card_type'] : '';
            $cc_parcelas = (isset($_POST['ps_transparent_installments'])) ? $_POST['ps_transparent_installments'] : 0;
            $cc_cpf = (isset($_POST['ps_transparent_cpf'])) ? $_POST['ps_transparent_cpf'] : '';
            $cc_cpf = preg_replace('/\D/', '', $cc_cpf);
            $maxparcelas = $this->credit_max_installment;
            $bin = substr($cc_numero, 0, 6);
            $last4 = substr($cc_numero, -4, 4);

            if ($this->cartaoValido($cc_numero) && !empty($cc_nome) && strlen($cc_cvv) > 2 && strlen($cc_numero) > 12 && $this->venctoOK($cc_val_mes, $cc_val_ano)) {
                $erro = false;
            } else {
                $erro = true;
                $additional = '';
                $extra = '';
                if (empty($cc_numero)) {
                    $error_message = __(' Preencha o número do cartão.', PAGSEGURO_DOMAIN);
                    $additional = 'O cliente não digitou o número do cartão';
                    wc_add_notice(__('Pagamento não autorizado:', PAGSEGURO_DOMAIN).$error_message, 'error');
                } elseif (strlen($cc_numero) < 13 || !$this->cartaoValido($cc_numero)) {
                    $error_message = __(' Invalid credit card. Please verify and try again.', PAGSEGURO_DOMAIN);
                    $additional = 'Número do cartão inválido (Luhn) ou menor que o permitido (13 dígitos)';
                    $extra = sprintf("(%d-****-%d)", $bin, $last4);
                    wc_add_notice(__('Pagamento não autorizado:', PAGSEGURO_DOMAIN).$error_message, 'error');
                } elseif (empty($cc_nome)) {
                    $error_message = __(' Preencha o nome do cartão!', PAGSEGURO_DOMAIN);
                    $additional = 'O nome do cartão não foi preenchido';
                    wc_add_notice(__('Pagamento não autorizado:', PAGSEGURO_DOMAIN).$error_message, 'error');
                } elseif (strlen($cc_cvv) < 3) {
                    $error_message = __(' Preencha o CVV do cartão corretamente!', PAGSEGURO_DOMAIN);
                    $additional = 'CVV inválido ou não preenchido';
                    wc_add_notice(__('Pagamento não autorizado:', PAGSEGURO_DOMAIN).$error_message, 'error');
                } elseif (!$this->venctoOK($cc_val_mes, $cc_val_ano)) {
                    $error_message = __(' Cartão expirado! Verifique a data de vencimento informada', PAGSEGURO_DOMAIN);
                    $additional = 'Cartão expirado';
                    $extra = sprintf("(%d/%d)", $cc_val_mes, $cc_val_ano);
                    wc_add_notice(__('Pagamento não autorizado:', PAGSEGURO_DOMAIN).$error_message, 'error');
                } else {
                    $error_message = __(' This card isn\'t accepted. Please choose another one!', PAGSEGURO_DOMAIN);
                    $additional = "Cartão de crédito não aceito ($cc_metodo)";
                    $extra = sprintf("(%d-****-%d)", $bin, $last4);
                    wc_add_notice(__('Pagamento não autorizado:', PAGSEGURO_DOMAIN).$error_message, 'error');
                }
                update_post_meta($order_id, '_transaction_message', "Cartão inválido. Pagamento não enviado ao gateway.");
                $errocompleto = sprintf("Erro: %s - Detalhes do erro: %s %s", $error_message, $additional, $extra);
                $order->add_order_note("Cartão inválido. Pagamento não enviado ao gateway.");
                $order->add_order_note($errocompleto);
                $this->writeLog('Cartão inválido. Pagamento não enviado ao gateway.', false, 'error');
                $this->writeLog($errocompleto, false, 'error');
            }
        } elseif ($method == 'eft') {
            $debit_type = (isset($_POST['ps_transparent_debit_type'])) ? $_POST['ps_transparent_debit_type'] : '';
            $extra = '';
            if (empty($debit_type)) {
                $erro = true;
                $error_message = __(' Selecione o banco.', PAGSEGURO_DOMAIN);
                $additional = 'O cliente não selecionou o banco no checkout';
                wc_add_notice(__('Pagamento não autorizado:', PAGSEGURO_DOMAIN).$error_message, 'error');
                $errocompleto = sprintf("Erro: %s - Detalhes do erro: %s", $error_message, $additional);
                $order->add_order_note($errocompleto);
                update_post_meta($order_id, '_transaction_message', $errocompleto);
            }
        } else {
            //boleto

        }
        if (!$erro) {
            $payload = $this->get_pagseguro_payload($order, $method);
            $url = $this->ws_path()."/v2/transactions?email={$this->get_email()}&token={$this->get_token()}";
            $headers = array(
                'Content-Type' => 'application/x-www-form-urlencoded',
            );

            $majorminor = $this->format_woo_version(WC_VERSION);
            $headers['cms-description'] = 'woocommerce-oficial-v.'.$majorminor;
            $headers['module-description'] = 'WordPress v.'.$wp_version.'-WooCommerce v.'.WC_VERSION;
            $headers['module-version'] = PAGSEGURO_VERSION;

            foreach ($payload as $key => $value) {
                $fixedPayload[$key] = $this->retiracento($value);
            }
            $args = array(
                'body'    => $fixedPayload,
                'timeout' => 60,
                'headers' => $headers,
                'cookies' => array(),
            );
            $this->writeLog(wc_print_r($fixedPayload, true), false, 'info');
            $result = wp_remote_post($url, $args);

            $rawXml = $result['body'];
            $responseCode = $result['response']['code'];

            $this->writeLog('Response Code: '.$responseCode, false, 'info');
            $this->writeLog($rawXml, false, 'info');

            $timeoutCodes = array(408, 504, 524, 598);
            $xml = simplexml_load_string($rawXml, 'SimpleXMLElement', LIBXML_NOWARNING);
            if ($responseCode == 200) {
                //OK
                $status = $xml->status;
                $tid = $xml->code;
                update_post_meta($order_id, '_ps_method', (string) $method);
                update_post_meta($order_id, '_ps_status', (string) $status);
                update_post_meta($order_id, '_ps_tid', (string) $tid);
                $transactionString = "Pagamento enviado ao PagSeguro: ($status) ".$this->getPagSeguroMessage($status)." - TID: $tid";
                if ($method != 'creditCard') {
                    //recuperar link
                    $link = $xml->paymentLink;
                    update_post_meta($order_id, '_ps_billet_url', (string) $link);
                    $transactionString .= " - Link de pagamento: $link";
                } else {
                    $qty = $payload['installmentQuantity'];
                    $value = $payload['installmentValue'];
                    $installmentInfo = $qty.'x de R$ '.$value.' = R$ '.$value * $qty;
                    update_post_meta($order_id, '_ps_card_type', (string) $cc_bandeira);
                    update_post_meta($order_id, '_ps_card_bin', (string) $bin);
                    update_post_meta($order_id, '_ps_card_end', (string) $last4);
                    update_post_meta($order_id, '_ps_card_masked', (string) $bin.'******'.$last4);
                    update_post_meta($order_id, '_ps_card_exp_month', (string) $cc_val_mes);
                    update_post_meta($order_id, '_ps_card_exp_year', (string) $cc_val_ano);
                    update_post_meta($order_id, '_ps_card_name', (string) $cc_nome);
                    update_post_meta($order_id, '_ps_card_cpf', (string) $cc_cpf);
                    update_post_meta($order_id, '_ps_installment', (string) $installmentInfo);
                }

                $order->add_order_note($transactionString);
                $this->updateOrderStatus($order, $status);
                $this->writeLog($transactionString, false, 'error');
                //iniciado (1)
                //em análise (4)
                //capturado (8)
                //cancelado (3)
                if (in_array($status, $this->reprovedStatuses)) {
                    $error_message = 'Favor entrar em contato com o Banco emissor do seu cartão de crédito';
                    wc_add_notice(__('Pagamento não autorizado: ', PAGSEGURO_DOMAIN).$error_message, 'error');
                    $order->update_status('failed', $error_message);
                    $this->writeLog('Pagamento não autorizado: '.$error_message, false, 'error');
                }
            } elseif ($responseCode == 401) {
                //erro autenticação
                $erro = true;
                wc_add_notice(__('Erro no pagamento, entre em contato com o lojista.', 'error'));
                $error_message = "($responseCode) Erro de autenticação com o PagSeguro, confira suas credenciais.";
                $additional = 'Ambiente selecionado: '.strtoupper($this->pagseguro_environment);
                $errocompleto = sprintf("Erro: %s - Detalhes do erro: %s", $error_message, $additional);
                $order->add_order_note($errocompleto);
                $this->writeLog($errocompleto, false, 'error');
            } elseif (in_array($responseCode, $timeoutCodes)) {
                $status = 1;
                $transactionString = __('Ocorreu um timeout na transação. Aguardar retorno PagSeguro.', PAGSEGURO_DOMAIN);

                $order->add_order_note($transactionString);
                $order->add_order_note($rawXml);
                $this->updateOrderStatus($order, $status);
                $this->writeLog($transactionString, false, 'error');
            } else {
                //erro nos dados
                $erro = true;
                $errorCode = $xml->error->code;
                $errorMessage = $xml->error->message;
                if (!empty($errorCode)) {
                    $errorString = __('Pagamento não autorizado: ', PAGSEGURO_DOMAIN)."($errorCode) ".$errorMessage;
                    wc_add_notice($errorString, 'error');
                } else {
                    $errorString = "Ocorreu um erro na comunicação com o PagSeguro: ($responseCode) $rawXml";
                }
                $order->add_order_note($errorString);
                $this->writeLog($errorString, false, 'error');
            }
        }
        if (!$erro) {
            $order->set_total($total);
            $woocommerce->cart->empty_cart();
            return array(
                'result'   => 'success',
                'redirect' => $this->get_return_url($order),
            );
        } else {
            return array(
                'result'   => 'fail',
                'redirect' => '',
            );
        }
        $this->writeLog('----- FIM DO PAGAMENTO -----', false, 'info');
    }

    public function validate_payload($payload, $order)
    {
        $notAuthorised = __('Pagamento não autorizado:', PAGSEGURO_DOMAIN);

        //billing
        if(empty($payload['billingAddressStreet'])) {
            $error_message = __(' Preencha o Endereço de cobrança.', PAGSEGURO_DOMAIN);
            wc_add_notice($notAuthorised.$error_message, 'error');
        }
        elseif(strlen($payload['billingAddressStreet']) > 80) {
            $error_message = __(' Tamanho máximo do endereço de cobrança excedido, limite: 80 caracteres.', PAGSEGURO_DOMAIN);
            wc_add_notice($notAuthorised.$error_message, 'error');
        }

        if(strlen($payload['billingAddressNumber']) < 1) {
            $error_message = __(' Preencha o Número do endereço de cobrança.', PAGSEGURO_DOMAIN);
            wc_add_notice($notAuthorised.$error_message, 'error');
        }
        elseif(strlen($payload['billingAddressNumber']) > 20) {
            $error_message = __(' Tamanho máximo do número do endereço de cobrança excedido, limite: 20 caracteres.', PAGSEGURO_DOMAIN);
            wc_add_notice($notAuthorised.$error_message, 'error');
        }

        if(empty($payload['billingAddressDistrict'])) {
            $error_message = __(' Preencha o Bairro do endereço de cobrança.', PAGSEGURO_DOMAIN);
            wc_add_notice($notAuthorised.$error_message, 'error');
        }
        elseif(strlen($payload['billingAddressDistrict']) > 60) {
            $error_message = __(' Tamanho máximo do bairro do endereço de cobrança excedido, limite: 60 caracteres.', PAGSEGURO_DOMAIN);
            wc_add_notice($notAuthorised.$error_message, 'error');
        }

        if(strlen($payload['billingAddressComplement']) > 40) {
            $error_message = __(' Tamanho máximo do complemento do endereço de cobrança excedido, limite: 60 caracteres.', PAGSEGURO_DOMAIN);
            wc_add_notice($notAuthorised.$error_message, 'error');
        }

        if(empty($payload['billingAddressPostalCode'])) {
            $error_message = __(' Preencha o CEP do endereço de cobrança.', PAGSEGURO_DOMAIN);
            wc_add_notice($notAuthorised.$error_message, 'error');
        }
        elseif(strlen(preg_replace('/\D/', '', $payload['billingAddressPostalCode'])) != 8) {
            $error_message = __(' CEP do endereço de cobrança inválido.', PAGSEGURO_DOMAIN);
            wc_add_notice($notAuthorised.$error_message, 'error');
        }

        if(empty($payload['billingAddressCity'])) {
            $error_message = __(' Preencha a Cidade do endereço de cobrança.', PAGSEGURO_DOMAIN);
            wc_add_notice($notAuthorised.$error_message, 'error');
        }
        elseif(strlen($payload['billingAddressCity']) > 60) {
            $error_message = __(' Tamanho máximo da cidade do endereço de cobrança excedido, limite: 60 caracteres.', PAGSEGURO_DOMAIN);
            wc_add_notice($notAuthorised.$error_message, 'error');
        }

        if(empty($payload['billingAddressState'])) {
            $error_message = __(' Preencha o Estado do endereço de cobrança.', PAGSEGURO_DOMAIN);
            wc_add_notice($notAuthorised.$error_message, 'error');
        }
        elseif(strlen($payload['billingAddressState']) != 2) {
            $error_message = __(' Estado do endereço de cobrança inválido, limite: 2 caracteres.', PAGSEGURO_DOMAIN);
            wc_add_notice($notAuthorised.$error_message, 'error');
        }

        //shipping
        if($payload['shippingAddressRequired'] == 'true') {
            if(empty($payload['shippingAddressStreet'])) {
                $error_message = __(' Preencha o Endereço de entrega.', PAGSEGURO_DOMAIN);
                wc_add_notice($notAuthorised.$error_message, 'error');
            }
            elseif(strlen($payload['shippingAddressStreet']) > 80) {
                $error_message = __(' Tamanho máximo do endereço de entrega excedido, limite: 80 caracteres.', PAGSEGURO_DOMAIN);
                wc_add_notice($notAuthorised.$error_message, 'error');
            }

            if(strlen($payload['shippingAddressNumber']) < 1) {
                $error_message = __(' Preencha o Número do endereço de entrega.', PAGSEGURO_DOMAIN);
                wc_add_notice($notAuthorised.$error_message, 'error');
            }
            elseif(strlen($payload['shippingAddressNumber']) > 20) {
                $error_message = __(' Tamanho máximo do número do endereço de entrega excedido, limite: 20 caracteres.', PAGSEGURO_DOMAIN);
                wc_add_notice($notAuthorised.$error_message, 'error');
            }

            if(empty($payload['shippingAddressDistrict'])) {
                $error_message = __(' Preencha o Bairro do endereço de entrega.', PAGSEGURO_DOMAIN);
                wc_add_notice($notAuthorised.$error_message, 'error');
            }
            elseif(strlen($payload['shippingAddressDistrict']) > 60) {
                $error_message = __(' Tamanho máximo do bairro do endereço de entrega excedido, limite: 60 caracteres.', PAGSEGURO_DOMAIN);
                wc_add_notice($notAuthorised.$error_message, 'error');
            }

            if(strlen($payload['shippingAddressComplement']) > 40) {
                $error_message = __(' Tamanho máximo do complemento do endereço de entrega excedido, limite: 60 caracteres.', PAGSEGURO_DOMAIN);
                wc_add_notice($notAuthorised.$error_message, 'error');
            }

            if(empty($payload['shippingAddressPostalCode'])) {
                $error_message = __(' Preencha o CEP do endereço de entrega.', PAGSEGURO_DOMAIN);
                wc_add_notice($notAuthorised.$error_message, 'error');
            }
            elseif(strlen(preg_replace('/\D/', '', $payload['shippingAddressPostalCode'])) != 8) {
                $error_message = __(' CEP do endereço de entrega inválido.', PAGSEGURO_DOMAIN);
                wc_add_notice($notAuthorised.$error_message, 'error');
            }

            if(empty($payload['shippingAddressCity'])) {
                $error_message = __(' Preencha a Cidade do endereço de entrega.', PAGSEGURO_DOMAIN);
                wc_add_notice($notAuthorised.$error_message, 'error');
            }
            elseif(strlen($payload['shippingAddressCity']) > 60) {
                $error_message = __(' Tamanho máximo da cidade do endereço de entrega excedido, limite: 60 caracteres.', PAGSEGURO_DOMAIN);
                wc_add_notice($notAuthorised.$error_message, 'error');
            }

            if(empty($payload['shippingAddressState'])) {
                $error_message = __(' Preencha o Estado do endereço de entrega.', PAGSEGURO_DOMAIN);
                wc_add_notice($notAuthorised.$error_message, 'error');
            }
            elseif(strlen($payload['shippingAddressState']) != 2) {
                $error_message = __(' Estado do endereço de entrega inválido, limite: 2 caracteres.', PAGSEGURO_DOMAIN);
                wc_add_notice($notAuthorised.$error_message, 'error');
            }
        }

        //payment
        if(empty($payload['senderName'])) {
            $error_message = __(' Preencha o Nome do comprador.', PAGSEGURO_DOMAIN);
            wc_add_notice($notAuthorised.$error_message, 'error');
        }
        elseif(strlen($payload['senderName']) > 50) {
            $error_message = __(' Tamanho máximo do nome do comprador excedido, limite: 50 caracteres.', PAGSEGURO_DOMAIN);
            wc_add_notice($notAuthorised.$error_message, 'error');
        }

        if(!$this->validaCpf($payload['senderCPF'])) {
            $error_message = __(' CPF do comprador inválido.', PAGSEGURO_DOMAIN);
            wc_add_notice($notAuthorised.$error_message, 'error');
        }

        $phone = $payload['senderAreaCode'].$payload['senderPhone'];
        if(!preg_match('/^((1[1-9])|([2-9][0-9]))(([0-9]{4}[0-9]{4})|(9[0-9]{3}[0-9]{5}))$/', $phone)) {
            $error_message = __(' Telefone do comprador inválido.', PAGSEGURO_DOMAIN);
            wc_add_notice($notAuthorised.$error_message, 'error');
        }

        if(empty($payload['senderEmail'])) {
            $error_message = __(' Preencha o Email do comprador.', PAGSEGURO_DOMAIN);
            wc_add_notice($notAuthorised.$error_message, 'error');
        }
        elseif(!filter_var($payload['senderEmail'], FILTER_VALIDATE_EMAIL)) {
            $error_message = __(' Email do comprador inválido.', PAGSEGURO_DOMAIN);
            wc_add_notice($notAuthorised.$error_message, 'error');
        }
        elseif(strlen($payload['senderEmail']) > 60) {
            $error_message = __(' Tamanho máximo do email do comprador excedido, limite: 60 caracteres.', PAGSEGURO_DOMAIN);
            wc_add_notice($notAuthorised.$error_message, 'error');
        }

        if($payload['paymentMethod'] == 'creditCard') {
            if(empty($payload['creditCardHolderName'])) {
                $error_message = __(' Preencha o nome do cartão de crédito.', PAGSEGURO_DOMAIN);
                wc_add_notice($notAuthorised.$error_message, 'error');
            }
            elseif(strlen($payload['creditCardHolderName']) > 60) {
                $error_message = __(' Tamanho máximo do nome do cartão de crédito excedido, limite: 50 caracteres.', PAGSEGURO_DOMAIN);
                wc_add_notice($notAuthorised.$error_message, 'error');
            }

            $phone = $payload['creditCardHolderAreaCode'].$payload['creditCardHolderPhone'];
            if(!preg_match('/^((1[1-9])|([2-9][0-9]))(([0-9]{4}[0-9]{4})|(9[0-9]{3}[0-9]{5}))$/', $phone)) {
                $error_message = __(' Telefone do portador do cartão inválido.', PAGSEGURO_DOMAIN);
                wc_add_notice($notAuthorised.$error_message, 'error');
            }

            if(!$this->validaCpf($payload['creditCardHolderCPF'])) {
                $error_message = __(' CPF do portador do cartão inválido.', PAGSEGURO_DOMAIN);
                wc_add_notice($notAuthorised.$error_message, 'error');
            }

            $birthdate =  DateTime::createFromFormat('d/m/Y', $payload['creditCardHolderBirthDate']);
            $today = new DateTime('NOW');
            if(!preg_match('/^(0[1-9]|[12][0-9]|3[01])[\- \/.](?:(0[1-9]|1[012])[\- \/.](19|20)[0-9]{2})$/', $payload['creditCardHolderBirthDate']) || $birthdate > $today) {
                $error_message = __(' Data de nascimento do portador do cartão inválida.', PAGSEGURO_DOMAIN);
                wc_add_notice($notAuthorised.$error_message, 'error');
            }
        }

        if(!empty($error_message)) {
            $errocompleto = sprintf("Erro: %s", $error_message);
            $order->add_order_note($errocompleto);
            return false;
        }
        return true;
    }

    public function get_pagseguro_payload($order, $method)
    {
        $payload = array();
        $order_id = $order->get_id();
        $items = $this->getDescricaoPedido($order);
        $args = $this->getOrderData($order);
        $documento = !empty($args['documento']) ? $args['documento'] : '';
        $documento = preg_replace('/[\D]/', '', $documento);
        $total = (float) $order->get_total();

        $payload['paymentMode'] = 'default';
        $payload['paymentMethod'] = $method; //creditCard eft boleto
        $payload['receiverEmail'] = $this->get_email();
        $payload['currency'] = 'BRL';

        foreach ($items as $key => $item) {
            $payload['itemId'.$key] = $item['id'];
            $payload['itemDescription'.$key] = $item['descr'];
            $payload['itemAmount'.$key] = $item['valor'];
            $payload['itemQuantity'.$key] = $item['quant'];
        }

        $payload['reference'] = $order_id;
        $payload['senderName'] = $args['billingName'];
        $payload['senderCPF'] = $documento;
        $senderPhone = $args['billingPhone'];
        $ddd = substr($senderPhone, 0, 2);
        $phone = substr($senderPhone, 2);
        $payload['senderAreaCode'] = $ddd;
        $payload['senderPhone'] = $phone;
        $payload['senderEmail'] = $this->is_sandbox() ? substr($args['billingEmail'], 0, strpos($args['billingEmail'], '@')).'@sandbox.pagseguro.com.br' : $args['billingEmail'];
        $payload['senderHash'] = (isset($_POST['ps_transparent_sender_hash'])) ? $_POST['ps_transparent_sender_hash'] : '';

        if ($method == 'creditCard') {
            $payload['creditCardToken'] = (isset($_POST['ps_transparent_card_token'])) ? $_POST['ps_transparent_card_token'] : '';

            $payload['installmentQuantity'] = (isset($_POST['ps_transparent_installments'])) ? $_POST['ps_transparent_installments'] : 1;
            $payload['installmentValue'] = number_format($_POST['ps_transparent_installment_value'], 2, '.', '');
            $payload['noInterestInstallmentQuantity'] = $this->credit_interest_free;

            $doc_credit = (isset($_POST['ps_transparent_cpf'])) ? $_POST['ps_transparent_cpf'] : $documento;
            $doc_credit = preg_replace('/[\D]/', '', $doc_credit);

            $birth_credit = (isset($_POST['ps_transparent_birthdate'])) ? $_POST['ps_transparent_birthdate'] : '';
            $birth_credit = DateTime::createFromFormat('d/m/Y', $birth_credit)->format('d/m/Y');

            $payload['creditCardHolderName'] = (isset($_POST['ps_transparent_name'])) ? $_POST['ps_transparent_name'] : '';
            $payload['creditCardHolderCPF'] = $doc_credit;
            $payload['creditCardHolderBirthDate'] = $birth_credit;

            $phone = (isset($_POST['ps_transparent_phone'])) ? $_POST['ps_transparent_phone'] : $args['billingPhone'];
            $phone = preg_replace('/[\D]/', '', $phone);
            $ddd = substr($phone, 0, 2);
            $phone = substr($phone, 2);
            $payload['creditCardHolderAreaCode'] = $ddd;
            $payload['creditCardHolderPhone'] = $phone;
        } elseif ($method == 'eft') {
            $doc_debit = (isset($_POST['ps_transparent_debit_cpf'])) ? $_POST['ps_transparent_debit_cpf'] : $documento;
            $doc_debit = preg_replace('/[\D]/', '', $doc_debit);

            $phone_debit = (isset($_POST['ps_transparent_debit_phone'])) ? $_POST['ps_transparent_debit_phone'] : $args['billingPhone'];
            $phone_debit = preg_replace('/[\D]/', '', $phone_debit);
            $ddd = substr($phone_debit, 0, 2);
            $phone = substr($phone_debit, 2);

            $payload['bankName'] = (isset($_POST['ps_transparent_debit_type'])) ? $_POST['ps_transparent_debit_type'] : '';
            $payload['senderCPF'] = $doc_debit;
            $payload['senderAreaCode'] = $ddd;
            $payload['senderPhone'] = $phone;
        } else {
            //boleto
            $extra = 0;
            $discount = (float) str_replace(',', '.', $this->method->billet_discount_amount);
            if ($this->method->billet_discount != 'none' && $discount > 0) {
                if ($this->method->billet_discount == 'fixed') {
                    $extra = $discount * -1;
                } else {
                    $extra = $total / 100 * $discount * -1;
                }
            }

            $doc_billet = (isset($_POST['ps_transparent_billet_cpf'])) ? $_POST['ps_transparent_billet_cpf'] : $documento;
            $doc_billet = preg_replace('/[\D]/', '', $doc_billet);
            $phone_billet = (isset($_POST['ps_transparent_billet_phone'])) ? $_POST['ps_transparent_billet_phone'] : $args['billingPhone'];
            $phone_billet = preg_replace('/[\D]/', '', $phone_billet);
            $ddd = substr($phone_billet, 0, 2);
            $phone = substr($phone_billet, 2);

            $payload['extraAmount'] = number_format($extra, 2, '.', '');
            $payload['senderCPF'] = $doc_billet;
            $payload['senderAreaCode'] = $ddd;
            $payload['senderPhone'] = $phone;
        }

        if (!empty($args['shippingPostcode'])) {
            $payload['shippingAddressRequired'] = 'true';

            $payload['shippingAddressStreet'] = $args['shippingAddress'];
            $payload['shippingAddressNumber'] = $args['shippingNumber'];
            $payload['shippingAddressComplement'] = $args['shippingAddress2'];
            $payload['shippingAddressDistrict'] = $args['shippingNeighborhood'];
            $payload['shippingAddressPostalCode'] = $args['shippingPostcode'];
            $payload['shippingAddressCity'] = $args['shippingCity'];
            $payload['shippingAddressState'] = $args['shippingState'];
            $payload['shippingAddressCountry'] = 'BRA';
            $payload['shippingType'] = 3;

            if ($order->get_total_shipping() > 0) {
                $payload['shippingCost'] = number_format($order->get_total_shipping(), 2, '.', '');
            }
        } else {
            $payload['shippingAddressRequired'] = 'false';
        }

        $payload['billingAddressStreet'] = $args['billingAddress'];
        $payload['billingAddressNumber'] = $args['billingNumber'];
        $payload['billingAddressComplement'] = $args['billingAddress2'];
        $payload['billingAddressDistrict'] = $args['billingNeighborhood'];
        $payload['billingAddressPostalCode'] = $args['billingPostcode'];
        $payload['billingAddressCity'] = $args['billingCity'];
        $payload['billingAddressState'] = $args['billingState'];
        $payload['billingAddressCountry'] = 'BRA';

        $payload['notificationURL'] = home_url('/wc-api/wc_gateway_pagseguro_ipn');

        return $payload;
    }

    public function getOrderData($order)
    {
        $args = array();
        // WooCommerce 3.0 or later.
        if (method_exists($order, 'get_meta')) {
            $args['billingAddress'] = $order->get_billing_address_1();
            $args['billingNumber'] = $order->get_meta('_billing_number');
            if (empty($args['billingNumber'])) {
                $args['billingNumber'] = preg_replace('/\D/', '', $args['billingAddress']);
            }
            $cpf = $order->get_meta('_billing_cpf');
            $cnpj = $order->get_meta('_billing_cnpj');
            $documento = empty($cpf) ? $cnpj : $cpf;
            $args['userId'] = $order->get_user_id();
            $args['documento'] = $documento;
            $args['billingName'] = $order->get_billing_first_name().' '.$order->get_billing_last_name();
            $args['billingEmail'] = $order->get_billing_email();
            $args['billingPhone'] = $order->get_billing_phone();
            $args['billingCellphone'] = $order->get_meta('_billing_cellphone');
            $args['billingNeighborhood'] = $order->get_meta('_billing_neighborhood');
            $args['billingAddress2'] = $order->get_billing_address_2();
            $args['billingCity'] = $order->get_billing_city();
            $args['billingState'] = $order->get_billing_state();
            $args['billingPostcode'] = $order->get_billing_postcode();
            $args['billingBirthdate'] = $order->get_meta('_billing_birthdate');
            $args['billingSex'] = $order->get_meta('_billing_sex');

            // Shipping fields.
            $args['shippingAddress'] = $order->get_shipping_address_1();
            $args['shippingNumber'] = $order->get_meta('_shipping_number');
            if (empty($args['shippingNumber'])) {
                $args['shippingNumber'] = preg_replace('/\D/', '', $args['shippingAddress']);
            }
            $args['shippingNeighborhood'] = $order->get_meta('_shipping_neighborhood');
            $args['shippingAddress2'] = $order->get_shipping_address_2();
            $args['shippingPostcode'] = $order->get_shipping_postcode();
            $args['shippingCity'] = $order->get_shipping_city();
            $args['shippingState'] = $order->get_shipping_state();
        } else {
            $args['billingAddress'] = $order->billing_address_1;
            if (!empty($order->billing_number)) {
                $args['billingNumber'] = $order->billing_number;
            } else {
                $args['billingNumber'] = preg_replace('/\D/', '', $order->billing_address_1);
            }
            $cpf = $order->billing_cpf;
            $cnpj = $order->billing_cnpj;
            $documento = empty($cpf) ? $cnpj : $cpf;
            $args['userId'] = $order->user_id;
            $args['documento'] = $documento;
            $args['billingName'] = $order->billing_first_name.' '.$order->billing_last_name;
            $args['billingEmail'] = $order->billing_email;
            $args['billingPhone'] = $order->billing_phone;
            $args['billingCellphone'] = $order->billing_cellphone;
            $args['billingNeighborhood'] = $order->billing_neighborhood;
            $args['billingAddress2'] = $order->billing_address_2;
            $args['billingCity'] = $order->billing_city;
            $args['billingState'] = $order->billing_state;
            $args['billingPostcode'] = $order->billing_postcode;
            $args['billingBirthdate'] = $order->billing_birthdate;
            $args['billingSex'] = $order->billing_sex;

            $args['shippingAddress'] = $order->shipping_address_1;
            if (!empty($order->shipping_number)) {
                $args['shippingNumber'] = $order->shipping_number;
            } else {
                $args['shippingNumber'] = preg_replace('/\D/', '', $order->shipping_address_1);
            }
            $args['shippingNeighborhood'] = $order->shipping_neighborhood;
            $args['shippingAddress2'] = $order->shipping_address_2;
            $args['shippingPostcode'] = $order->shipping_postcode;
            $args['shippingCity'] = $order->shipping_city;
            $args['shippingState'] = $order->shipping_state;
        }
        $args['billingNumber'] = preg_replace('/[\D]/', '', $args['billingNumber']);
        $args['billingPhone'] = preg_replace('/[\D]/', '', $args['billingPhone']);
        if (strlen($args['billingNumber']) > 5) {
            $args['billingNumber'] = substr($args['billingNumber'], 0, 5);
        }
        if (empty($args['billingNumber'])) {
            $args['billingNumber'] = '00';
        }
        return $args;
    }

    public static function ipn_pagseguro()
    {
        @ob_clean();
        $self = new WC_Pagseguro_Payment_Gateway();

        $ipn = $self->process_ipn_request($_POST);

        if ($ipn) {
            header('HTTP/1.1 200 OK');
            $self->update_order_status($ipn, 'ipn');
            exit();
        } else {
            wp_die(esc_html__('PagSeguro Request Unauthorized', PAGSEGURO_DOMAIN), esc_html__('PagSeguro Request Unauthorized', 'woocommerce-pagseguro'), array('response' => 401));
        }
    }

    public function process_ipn_request($data)
    {
        $this->writeLog('----- CHECANDO IPN -----', true, 'info');

        if (!isset($data['notificationCode']) && !isset($data['notificationType'])) {
            $this->writeLog('IPN INVÁLIDO', true, 'error');
            $this->writeLog(wc_print_r($data, true), true, 'error');
            return false;
        }

        // Checks the notificationType.
        if ('transaction' != $data['notificationType']) {
            $this->writeLog('IPN INVÁLIDO, notificationType não é transaction', true, 'error');
            $this->writeLog(wc_print_r($data, true), true, 'error');

            return false;
        }

        $methods = array(
            'WC_Pagseguro_Payment_Billet',
            'WC_Pagseguro_Payment_Credit',
            'WC_Pagseguro_Payment_Debit',
            'WC_Pagseguro_Payment_Redirect',
        );

        foreach($methods as $method) {
            $instance = new $method();
            $email = $instance->get_email();
            $token = $instance->get_token();
            if(!empty($email) && !empty($token)) {
                break;
            }
        }
        $url = add_query_arg(array('email' => $instance->get_email(), 'token' => $instance->get_token()), $instance->notification_url(esc_attr($data['notificationCode'])));
        $result = wp_remote_get($url);

        if (is_wp_error($result)) {
            $this->writeLog('Erro WP_Error: '.$result->get_error_message(), true, 'error');
        } else {
            try {
                $rawXml = $result['body'];
                $xml = simplexml_load_string($rawXml, 'SimpleXMLElement');
            } catch (Exception $e) {
                $xml = '';

                $this->writeLog('Erro ao processar IPN:', true, 'error');
                $this->writeLog($e->getMessage(), true, 'error');
            }

            if (isset($xml->code)) {
                $this->writeLog('IPN válido!', true, 'info');
                $this->writeLog(wc_print_r($xml, true), true, 'info');
                return $xml;
            }
        }

        $this->writeLog('RequestURL: '.$url, true, 'info');
        if(is_array($result)) {
            $this->writeLog(wc_print_r($result['response'], true), true, 'info');
            $this->writeLog(wc_print_r($result['body'], true), true, 'info');
        }

        return false;
    }

    public function update_order_status($payload, $type = '')
    {
        if (isset($payload->reference)) {
            $id = (string) $payload->reference;
            $status = (int) $payload->status;
            $order = wc_get_order($id);

            // Check if order exists.
            if (!$order) {
                return;
            }

            $order_id = method_exists($order, 'get_id') ? $order->get_id() : $order->id;

            // Checks whether the invoice number matches the order.
            // If true processes the payment.
            if ($order_id == $id) {
                $this->writeLog('Atualizando status do pedido '.$order->get_order_number().', novo status: '.$status, false, 'info');
                $this->updateOrderStatus($order, $status, $type);
                update_post_meta($order_id, '_ps_status', (string) $status);

                $tid = get_post_meta($order_id, '_ps_tid', true);
                if (empty($tid) && !empty($payload->code)) {
                    delete_post_meta($order_id, '_ps_tid');
                    update_post_meta($order_id, '_ps_tid', (string) $payload->code);
                }
            } else {
                $this->writeLog('ReferenceID PagSeguro ('.$id.') diferente do número do pedido ('.$order->get_order_number().')', false, 'error');
            }
        }
    }

    public function getDescricaoPedido($order)
    {
        $cartItems = $order->get_items();
        $itemsData = array();
        $json = array();
        $i = 0;
        foreach ($cartItems as $item) {
            $itemsData["quant"] = $item['qty'];
            $itemsData["descr"] = preg_replace('/[<>\-&%\/]/', '', $item['name']);
            $itemsData["valor"] = number_format($item['line_subtotal'] / $item['qty'], 2, '.', '');
            $itemsData["id"] = $item['product_id'];
            $json[++$i] = $itemsData;
        }
        return $json;
    }

    /**
     * Can the order be refunded via PagSeguro?
     *
     * @param  WC_Order $order Order object.
     * @return bool
     */
    public function can_refund_order($order)
    {
        $order_id = $order->get_id();
        $tid = get_post_meta($order_id, '_ps_tid', true);
        $status = get_post_meta($order_id, '_ps_status', true);
        $method = get_post_meta($order_id, '_ps_method', true);

        // cancel: (1) Aguardando pagamento / (2) Em análise
        // refund: (3) Paga / (4) Disponível / (5) Em disputa
        $can_refund_statuses = array('1', '2', '3', '4', '5');
        $can_refund_methods = array('creditCard', 'boleto', 'eft');

        return $order && !empty($tid) && in_array($status, $can_refund_statuses) && in_array($method, $can_refund_methods);
    }

    /**
     * Process a refund if supported.
     *
     * @param  int    $order_id Order ID.
     * @param  float  $amount Refund amount.
     * @param  string $reason Refund reason.
     * @return bool|WP_Error
     */
    public function process_refund($order_id, $amount = null, $reason = '')
    {
        $this->writeLog('----- SOLICITAÇÃO REFUND -----', false, 'info');
        $this->writeLog('OrderID: '.$order_id, false, 'info');
        $this->writeLog('Amount: '.$amount, false, 'info');
        $order = wc_get_order($order_id);
        $order_id = $order->get_id();
        $transid = get_post_meta($order_id, '_ps_tid', true);
        $status = get_post_meta($order_id, '_ps_status', true);
        $cancelStatuses = array('1', '2');
        $refundStatuses = array('3', '4', '5');
        $params = array('transactionCode' => $transid);

        if (is_null($amount)) {
            $amount = $order->get_total();
        }

        //orderdate + 90 > today
        $orderDate = $order->order_date;
        $newDate = date('Y-m-d', strtotime($orderDate.' +90 days'));
        if ($newDate < date('Y-m-d')) {
            $message = __('O prazo máximo para solicitar um estorno é de até 90 dias após a data de compra.', 'woocommerce');
            $this->writeLog($message, false, 'error');
            return new WP_Error('error', $message);
        }

        //empty transactionCode
        if (empty($transid)) {
            $message = __('Transação não possui transactionCode. Por favor, consulte a transação através do botão "Consulta" e tente novamente.', 'woocommerce');
            $this->writeLog($message, false, 'error');
            return new WP_Error('error', $message);
        }

        $operation = '';
        if (in_array($status, $cancelStatuses)) {
            if ($amount < $order->get_total()) {
                $message = __('Não é possível realizar cancelamento parcial. Caso deseje realizar um estorno parcial, aguarde a mudança do status do pedido no PagSeguro.', 'woocommerce');
                $this->writeLog($message, false, 'error');
                return new WP_Error('error', $message);
            }
            $operation = 'cancels';
        }
        if (in_array($status, $refundStatuses)) {
            if ($amount >= $order->get_total()) {
                //não enviar amount caso seja igual ao total
                $amount = 0;
            }
            $operation = 'refunds';
        }

        if (!empty($operation)) {
            $url = $this->ws_path()."/v2/transactions/".$operation."?email={$this->get_email()}&token={$this->get_token()}";
            $headers = array(
                'Content-Type' => 'application/x-www-form-urlencoded',
            );
            if ($operation == 'refunds' && $amount > 0) {
                $params['refundValue'] = $amount;
            }
            $args = array(
                'body'    => $params,
                'timeout' => 60,
                'headers' => $headers,
                'cookies' => array(),
            );
            $this->writeLog(wc_print_r($params, true), false, 'info');
            $result = wp_remote_post($url, $args);
            $rawXml = $result['body'];
            $responseCode = $result['response']['code'];

            $this->writeLog('Response Code: '.$responseCode, false, 'info');
            $this->writeLog($rawXml, false, 'info');
            $xml = simplexml_load_string($rawXml, 'SimpleXMLElement', LIBXML_NOWARNING);

            $operation = substr($operation, 0, -1);
            if ($responseCode == 200) {
                $response = json_decode(json_encode($xml), true);
                $response = (string) array_shift($response);

                $message = sprintf(__('Reembolso - Operação: %1$s (%2$s)', 'woocommerce'), $operation, $response);
                $order->add_order_note('Resposta do Reembolso: '.$message);
                $this->writeLog($message, false, 'info');
                return true;
            } else {
                $code = $xml->error->code;
                $message = $xml->error->message;
                $error = sprintf(__('Ocorreu um erro ao efetuar o reembolso. Operação: %1$s (%2$s) %3$s', 'woocommerce'), $operation, $code, $message);
                $order->add_order_note('Resposta do Reembolso: '.$error);

                if ($code == 56002) {
                    $error = 'Não é possível cancelar uma transação com o status atual. Por favor, tente consultar manualmente a transação e em seguida tente novamente.';
                    $order->add_order_note($error);
                }

                $this->writeLog($error, false, 'error');
                return new WP_Error('error', $error);
            }
        } else {
            $message = sprintf(__('Status (%1$s) não permite refund ou cancelamento.', 'woocommerce'), $this->getPagSeguroMessage($status));
            $this->writeLog($message, false, 'error');
            return new WP_Error('error', $message);
        }
    }

    public static function consultTransaction()
    {
        $order_id = $_REQUEST['order'];
        $transid = $_REQUEST['transid'];

        $order = new WC_Order($order_id);
        $method = is_callable(array($order, 'get_payment_method')) ? $order->get_payment_method() : $order->payment_method;
        switch ($method) {
            case 'pagseguro-payment-billet':
                $instance = new WC_Pagseguro_Payment_Billet();
                break;
            case 'pagseguro-payment-credit':
                $instance = new WC_Pagseguro_Payment_Credit();
                break;
            case 'pagseguro-payment-debit':
                $instance = new WC_Pagseguro_Payment_Debit();
                break;
            case 'pagseguro-payment-redirect':
                $instance = new WC_Pagseguro_Payment_Redirect();
                break;
            default:
                $instance = new WC_Pagseguro_Payment_Gateway();
                break;
        }

        $instance->writeLog('----- CONSULTA-----', false, 'info');
        $instance->writeLog('OrderID: '.$order_id, false, 'info');
        $instance->writeLog('TransactionCode: '.$transid, false, 'info');

        if (empty($transid)) {
            $url = add_query_arg(array('email' => $instance->get_email(), 'token' => $instance->get_token(), 'reference' => $order_id), $instance->consult_transaction_url(''));
            $result = wp_remote_get($url);
            try {
                $rawXml = $result['body'];
                $instance->writeLog($rawXml, false, 'info');
                $xml = simplexml_load_string($rawXml, 'SimpleXMLElement', LIBXML_NOWARNING);
                $transid = (string) $xml->transactions->transaction->code;
                delete_post_meta($order_id, '_ps_tid');
                update_post_meta($order_id, '_ps_tid', (string) $transid);
                $instance->writeLog('TransactionCode atualizado: '.$transid, false, 'info');
            } catch (Exception $e) {
                $xml = '';
            }
        }

        if (!empty($transid)) {
            // Consult via transactionCode
            $url = add_query_arg(array('email' => $instance->get_email(), 'token' => $instance->get_token()), $instance->consult_transaction_url(esc_attr($transid)));
            $result = wp_remote_get($url);
        } else {
            $result = array();
        }

        // Check to see if the request was valid.
        if (is_wp_error($result)) {
            if ('yes' == $instance->debug) {
                $instance->writeLog('Erro WP_Error: '.$response->get_error_message(), false, 'error');
            }
        } else {
            try {
                $rawXml = $result['body'];
                $instance->writeLog($rawXml, false, 'info');
                $xml = simplexml_load_string($rawXml, 'SimpleXMLElement', LIBXML_NOWARNING);
            } catch (Exception $e) {
                $xml = '';
            }
        }

        if (!empty($xml)) {
            $instance->update_order_status($xml, 'consulta');
        }
        $status = (string) $xml->status;
        $mensagem = (string) $instance->getPagSeguroMessage($xml->status);
        $retorno = array('status' => $status, 'mensagem' => $mensagem);

        $instance->writeLog(wc_print_r($retorno, true), false, 'info');
        $instance->writeLog('----- FIM DA CONSULTA -----', false, 'info');
        echo json_encode($retorno);
        wp_die();
    }

    public function writeLog($msg, $force = false, $level = 'info')
    {
        // debug
        // info
        // notice
        // warning
        // error
        // critical
        // alert
        // emergency
        if ($force || ($this->method && 'yes' == $this->method->debug)) {
            $this->log->$level($msg, $this->context);
        }
    }

    public function link_log()
    {
        if (defined('WC_VERSION') && version_compare(WC_VERSION, '2.2', '>=')) {
            return '<a href="'.esc_url(admin_url('admin.php?page=wc-status&tab=logs&log_file='.esc_attr($this->id).'-'.sanitize_file_name(wp_hash($this->id)).'.log')).'">'.__('Logs', PAGSEGURO_DOMAIN).'</a>';
        }

        return '<code>woocommerce/logs/'.esc_attr($this->id).'-'.sanitize_file_name(wp_hash($this->id)).'.txt</code>';
    }

    public function venctoOK($mes, $ano)
    {
        $vencto = DateTime::createFromFormat('Ym', $ano.$mes);
        $now = new DateTime();
        return ($vencto >= $now);
    }

    public function cartaoValido($number)
    {
        settype($number, 'string');
        $sumTable = array(
            array(0, 1, 2, 3, 4, 5, 6, 7, 8, 9),
            array(0, 2, 4, 6, 8, 1, 3, 5, 7, 9));
        $sum = 0;
        $flip = 0;
        for ($i = strlen($number) - 1; $i >= 0; $i--) {
            $sum += $sumTable[$flip++ & 0x1][$number[$i]];
        }
        return $sum % 10 === 0;
    }

    public function retiracento($texto)
    {
        $trocarIsso = array('à', 'á', 'â', 'ã', 'ä', 'å', 'ç', 'è', 'é', 'ê', 'ë', 'ì', 'í', 'î', 'ï', 'ñ', 'ò', 'ó', 'ô', 'õ', 'ö', 'ù', 'ü', 'ú', 'ÿ', 'À', 'Á', 'Â', 'Ã', 'Ä', 'Å', 'Ç', 'È', 'É', 'Ê', 'Ë', 'Ì', 'Í', 'Î', 'Ï', 'Ñ', 'Ò', 'Ó', 'Ô', 'Õ', 'Ö', 'O', 'Ù', 'Ü', 'Ú', 'Ÿ');
        $porIsso = array('a', 'a', 'a', 'a', 'a', 'a', 'c', 'e', 'e', 'e', 'e', 'i', 'i', 'i', 'i', 'n', 'o', 'o', 'o', 'o', 'o', 'u', 'u', 'u', 'y', 'A', 'A', 'A', 'A', 'A', 'A', 'C', 'E', 'E', 'E', 'E', 'I', 'I', 'I', 'I', 'N', 'O', 'O', 'O', 'O', 'O', 'O', 'U', 'U', 'U', 'Y');
        $titletext = str_replace($trocarIsso, $porIsso, $texto);
        return $titletext;
    }

    public function validaCpf($cpf)
    {
        // Extrai somente os números
        $cpf = preg_replace('/[^0-9]/is', '', $cpf);

        // Verifica se foi informado todos os digitos corretamente
        if (strlen($cpf) != 11) {
            return false;
        }
        // Verifica se foi informada uma sequência de digitos repetidos. Ex: 111.111.111-11
        if (preg_match('/(\d)\1{10}/', $cpf)) {
            return false;
        }
        // Faz o calculo para validar o CPF
        for ($t = 9; $t < 11; $t++) {
            for ($d = 0, $c = 0; $c < $t; $c++) {
                $d += $cpf{$c} * (($t + 1) - $c);
            }
            $d = ((10 * $d) % 11) % 10;
            if ($cpf{$c} != $d) {
                return false;
            }
        }

        return true;
    }
}
