<?php

if (!defined('ABSPATH')) {
    exit;
}

class WC_Pagseguro_Payment_Redirect extends WC_Payment_Gateway
{

    public function __construct()
    {
        $this->id = 'pagseguro-payment-redirect';
        //$this->icon               = apply_filters( 'woocommerce_pagseguro_icon', plugins_url( 'assets/images/pagseguro.png', plugin_dir_path( __FILE__ ) ) );
        $this->icon = apply_filters('woocommerce_pagseguro_payment_icon', plugins_url('img/logo_pagseguro.png', PAGSEGURO_BASE_DIR));
        $this->method_title = __('PagSeguro Redirect Payment', PAGSEGURO_DOMAIN);
        $this->method_description = __('Accept payments via PagSeguro.', PAGSEGURO_DOMAIN);
        $this->has_fields = true;
        //$this->order_button_text = __('Proceed to payment', PAGSEGURO_DOMAIN);

        $this->init_form_fields();
        $this->init_settings();

        // Define user set variables.
        $this->title = $this->get_option('title');
        $this->description = $this->get_option('description');

        $this->email = $this->get_option('email');
        $this->token = $this->get_option('token');
        $this->sandbox_email = $this->get_option('sandbox_email');
        $this->sandbox_token = $this->get_option('sandbox_token');

        $this->pagseguro_environment = $this->get_option('pagseguro_environment', 'sandbox');
        $this->mode = $this->get_option('pagseguro_mode', 'redirect');
        $this->redirect_message = $this->get_option('redirect_message');

        $this->credit = $this->get_option('credit', 'no');
        $this->debit = $this->get_option('debit', 'no');
        $this->billet = $this->get_option('billet', 'no');
        $this->credit_max_installment = $this->get_option('maximum_installment', 6);
        $this->credit_interest_free = $this->get_option('interest_free_installment', 6);
        $this->billet_discount = $this->get_option('billet_discount', 'none');
        $this->billet_discount_amount = $this->get_option('billet_discount_amount', 0);

        $this->debug = $this->get_option('debug');
        $this->analysisStatuses = array('1', '2');
        $this->approvedStatuses = array('3', '4');
        $this->reprovedStatuses = array('5', '6', '7', '8');
        $this->supports = array('products', 'refunds');

        if ($this->debug == 'yes') {
            $this->context = array('source' => $this->id);
            if (function_exists('wc_get_logger')) {
                $this->log = wc_get_logger();
            } else {
                $this->log = new WC_Logger();
            }
        }

        // Main actions.
        //add_action('woocommerce_api_wc_pagseguro_gateway', array($this, 'ipn_handler'));
        //add_action('valid_pagseguro_ipn_request', array($this, 'update_order_status'));
        add_action('woocommerce_update_options_payment_gateways_'.$this->id, array($this, 'process_admin_options'));
        add_action('woocommerce_admin_order_data_after_shipping_address', array($this, 'order_info'));
        //add_action('woocommerce_receipt_'.$this->id, array($this, 'receipt_page'));

        add_action('woocommerce_order_details_after_order_table', array($this, 'pending_payment_message'), 5);
    }

    public function init_form_fields()
    {
        $statuses = array('' => '-- Selecione um status --');
        $statuses = array_merge($statuses, wc_get_order_statuses());
        $url = get_site_url().'/wc-api/wc_gateway_callback/';
        $this->form_fields = array(
            'enabled'                   => array(
                'title'    => __('Enable / Disable', PAGSEGURO_DOMAIN),
                'type'     => 'checkbox',
                'label'    => __('Enable PagSeguro Redirect Payment', PAGSEGURO_DOMAIN),
                'desc_tip' => false,
                'default'  => 'yes',
            ),
            'title'                     => array(
                'title'       => __('Method Title', PAGSEGURO_DOMAIN),
                'type'        => 'text',
                'description' => __('This controls the title that users will see during checkout.', PAGSEGURO_DOMAIN),
                'default'     => __('PagSeguro', PAGSEGURO_DOMAIN),
                'desc_tip'    => true,
            ),

            'pagseguro_environment'     => array(
                'title'    => __('PagSeguro Environment', PAGSEGURO_DOMAIN),
                'type'     => 'select',
                'desc_tip' => true,
                'default'  => 'production',
                'label'    => __('Choose Environment for PagSeguro Integration', PAGSEGURO_DOMAIN),
                'options'  => array(
                    'sandbox'    => __('Sandbox', PAGSEGURO_DOMAIN),
                    'production' => __('Production', PAGSEGURO_DOMAIN),
                ),
            ),
            'email'                     => array(
                'title'       => __('PagSeguro Email', PAGSEGURO_DOMAIN),
                'type'        => 'text',
                'description' => __('PagSeguro Email Address', PAGSEGURO_DOMAIN),
                'default'     => '',
                'desc_tip'    => false,
            ),
            'token'                     => array(
                'title'       => __('PagSeguro Token', PAGSEGURO_DOMAIN),
                'type'        => 'text',
                'description' => __('PagSeguro Token', PAGSEGURO_DOMAIN),
                'default'     => '',
                'desc_tip'    => false,
            ),

            'sandbox_email'             => array(
                'title'       => __('PagSeguro Sandbox Email', PAGSEGURO_DOMAIN),
                'type'        => 'text',
                'description' => __('PagSeguro Sandbox Email Address', PAGSEGURO_DOMAIN),
                'default'     => '',
                'desc_tip'    => false,
            ),
            'sandbox_token'             => array(
                'title'       => __('PagSeguro Sandbox Token', PAGSEGURO_DOMAIN),
                'type'        => 'text',
                'description' => __('PagSeguro Sandbox Token', PAGSEGURO_DOMAIN),
                'default'     => '',
                'desc_tip'    => false,
            ),

            'redirect_message'          => array(
                'title'       => __('Redirect Message', PAGSEGURO_DOMAIN),
                'type'        => 'text',
                'description' => __('Message showed to client on checkout', PAGSEGURO_DOMAIN),
                'default'     => __('Confirm your order to be redirected to the payment page.'),
                'desc_tip'    => false,
            ),

            'credit'                    => array(
                'title'   => __('Credit Card', PAGSEGURO_DOMAIN),
                'type'    => 'checkbox',
                'label'   => __('Disable Creditcard for Redirect Checkout', PAGSEGURO_DOMAIN),
                'default' => 'no',
            ),
            'debit'                     => array(
                'title'   => __('Debit', PAGSEGURO_DOMAIN),
                'type'    => 'checkbox',
                'label'   => __('Disable Debit for Redirect Checkout', PAGSEGURO_DOMAIN),
                'default' => 'no',
            ),
            'billet'                    => array(
                'title'   => __('Billet', PAGSEGURO_DOMAIN),
                'type'    => 'checkbox',
                'label'   => __('Disable Billet for Redirect Checkout', PAGSEGURO_DOMAIN),
                'default' => 'no',
            ),

            'credit_card_block'         => array(
                'title'       => __('Credit Card Options', PAGSEGURO_DOMAIN),
                'type'        => 'title',
                'description' => '',
            ),
            'maximum_installment'       => array(
                'title'       => __('Installment Within', PAGSEGURO_DOMAIN),
                'type'        => 'select',
                'description' => __('Maximum number of installments for orders in your store.', PAGSEGURO_DOMAIN),
                'desc_tip'    => true,
                'class'       => 'wc-enhanced-select',
                'default'     => '6',
                'options'     => array(
                    '1'  => '1x',
                    '2'  => '2x',
                    '3'  => '3x',
                    '4'  => '4x',
                    '5'  => '5x',
                    '6'  => '6x',
                    '7'  => '7x',
                    '8'  => '8x',
                    '9'  => '9x',
                    '10' => '10x',
                    '11' => '11x',
                    '12' => '12x',
                ),
            ),
            'interest_free_installment' => array(
                'title'       => __('Interest-Free Installment', PAGSEGURO_DOMAIN),
                'type'        => 'select',
                'description' => __('Number of interest-free installments', PAGSEGURO_DOMAIN),
                'desc_tip'    => true,
                'class'       => 'wc-enhanced-select',
                'default'     => '6',
                'options'     => array(
                    '1'  => '1x',
                    '2'  => '2x',
                    '3'  => '3x',
                    '4'  => '4x',
                    '5'  => '5x',
                    '6'  => '6x',
                    '7'  => '7x',
                    '8'  => '8x',
                    '9'  => '9x',
                    '10' => '10x',
                    '11' => '11x',
                    '12' => '12x',
                ),
            ),

            'billet_block'              => array(
                'title'       => __('Billet Options', PAGSEGURO_DOMAIN),
                'type'        => 'title',
                'description' => '',
            ),
            'billet_discount'           => array(
                'title'    => __('Billet Discount Type', PAGSEGURO_DOMAIN),
                'type'     => 'select',
                'desc_tip' => true,
                'default'  => 'none',
                'label'    => __('Choose between no discount or percentage discount', PAGSEGURO_DOMAIN),
                'options'  => array(
                    'none'    => __('None', PAGSEGURO_DOMAIN),
                    'percent' => __('Percentage (%)', PAGSEGURO_DOMAIN),
                ),
            ),
            'billet_discount_amount'    => array(
                'title'    => __('Billet Discount Amount', PAGSEGURO_DOMAIN),
                'type'     => 'text',
                'desc_tip' => true,
                'default'  => 0,
                'label'    => __('Inform the desired amount of discount', PAGSEGURO_DOMAIN),
            ),

            'extra_options'             => array(
                'title'       => __('Extra Options', PAGSEGURO_DOMAIN),
                'type'        => 'title',
                'description' => '',
            ),
            'debug'                     => array(
                'title'       => __('Enable Module Logs', PAGSEGURO_DOMAIN),
                'label'       => __('Enable', PAGSEGURO_DOMAIN),
                'type'        => 'checkbox',
                'desc_tip'    => false,
                'default'     => 'no',
                'description' => sprintf(__('Acesso aos logs do módulo: %s', PAGSEGURO_DOMAIN), $this->link_log()),
            ),
            'status_iniciado'           => array(
                'title'       => __('Status Iniciado', PAGSEGURO_DOMAIN),
                'type'        => 'select',
                'desc_tip'    => true,
                'description' => __('O pedido mudará automaticamente para este status em caso de aprovação no PagSeguro', PAGSEGURO_DOMAIN),
                'default'     => '',
                'options'     => $statuses,
            ),
            'status_aprovado'           => array(
                'title'       => __('Status Aprovado', PAGSEGURO_DOMAIN),
                'type'        => 'select',
                'desc_tip'    => true,
                'description' => __('O pedido mudará automaticamente para este status em caso de aprovação no PagSeguro', PAGSEGURO_DOMAIN),
                'default'     => '',
                'options'     => $statuses,
            ),
            'status_cancelado'          => array(
                'title'       => __('Status Cancelado', PAGSEGURO_DOMAIN),
                'type'        => 'select',
                'desc_tip'    => true,
                'description' => __('O pedido mudará automaticamente para este status quando a transação for cancelada no PagSeguro', PAGSEGURO_DOMAIN),
                'default'     => '',
                'options'     => $statuses,
            ),
            'status_aguardando'         => array(
                'title'       => __('Status Aguardando', PAGSEGURO_DOMAIN),
                'type'        => 'select',
                'desc_tip'    => true,
                'description' => __('O pedido mudará automaticamente para este status quando a transação estiver no status aguardando no PagSeguro', PAGSEGURO_DOMAIN),
                'default'     => '',
                'options'     => $statuses,
            ),
        );
    }

    /**
     * Display pending payment message in order details.
     *
     * @param  int $order_id Order id.
     *
     * @return string        Message HTML.
     */
    public static function pending_payment_message($order_id)
    {
        $order = new WC_Order($order_id);
        $order_id = is_callable(array($order, 'get_id')) ? $order->get_id() : $order->id;
        $method = is_callable(array($order, 'get_payment_method')) ? $order->get_payment_method() : $order->payment_method;

        $textoBotao = __('Efetuar Pagamento', PAGSEGURO_DOMAIN);
        $mensagem = __('Clique no link ao lado para efetuar o pagamento.', PAGSEGURO_DOMAIN);
        $linkPagamento = get_post_meta($order_id, '_ps_redirect_url', true);
        if (!empty($linkPagamento) && $method == 'pagseguro-payment-redirect') {
            $html = '<div class="woocommerce-info">';
            $html .= sprintf('<a class="button" href="%s" target="_blank" style="display: block !important; visibility: visible !important;">%s</a>', esc_url($linkPagamento), $textoBotao.' &rarr;');
            $html .= $mensagem.'<br />';
            $html .= '</div>';
            echo $html;
        }
    }

    public function is_available()
    {
        $available = $this->get_option('enabled') == 'yes';

        return $available;
    }

    public function admin_options()
    {
        wp_enqueue_script('pagseguro-config', plugins_url('js/config.js', plugin_dir_path(__FILE__)), array('jquery'), PAGSEGURO_VERSION, true);

        parent::admin_options();
    }

    public function get_email()
    {
        return $this->is_sandbox() ? $this->sandbox_email : $this->email;
    }

    public function get_token()
    {
        return $this->is_sandbox() ? $this->sandbox_token : $this->token;
    }

    public function is_sandbox()
    {
        return $this->pagseguro_environment == 'sandbox';
    }

    public function is_production()
    {
        return $this->pagseguro_environment == 'production';
    }

    public function domain()
    {
        return 'pagseguro.uol.com.br';
    }

    public function static_path()
    {
        return 'https://stc.'.($this->is_sandbox() ? 'sandbox.' : '').$this->domain();
    }

    public function ws_path()
    {
        return 'https://ws.'.($this->is_sandbox() ? 'sandbox.' : '').$this->domain();
    }

    public function consult_transaction_url($transaction_code)
    {
        if (!empty($transaction_code)) {
            return $this->ws_path().'/v3/transactions/'.$transaction_code;
        } else {
            return $this->ws_path().'/v2/transactions';
        }
    }

    public function notification_url($notification_code)
    {
        return $this->ws_path().'/v3/transactions/notifications/'.$notification_code;
    }

    public function payment_fields()
    {
        echo $this->redirect_message;
    }

    public function order_info()
    {
        if (!empty($_REQUEST['post'])) {
            $order_id = $_REQUEST['post'];
            $order = new WC_Order($order_id);
            $method = is_callable(array($order, 'get_payment_method')) ? $order->get_payment_method() : $order->payment_method;
            if($method == 'pagseguro-payment-redirect') {
                $status = get_post_meta($order_id, '_ps_status', true);
                $params = array(
                    't_id'       => get_post_meta($order_id, '_ps_tid', true),
                    't_msg'      => $this->getPagSeguroMessage($status),
                    'order_id'   => $order_id,
                    'parcelas'   => get_post_meta($order_id, '_ps_installment', true),
                    'bandeira'   => get_post_meta($order_id, '_ps_card_type', true),
                    'status'     => $status,
                    'billet_url' => get_post_meta($_REQUEST['post'], '_ps_billet_url', true),
                    'metodo'     => get_post_meta($order_id, '_ps_method', true),
                );
                wc_get_template(
                    'pagseguro-payment-admin.php', $params, '', WC_Pagseguro_Payment::get_template_dir()
                );
            }
        }
    }

    public function format_woo_version($version)
    {
        $aux = explode('.',$version);
        $formatted = $aux[0].'.'.(array_key_exists(1, $aux) ? $aux[1] : 0);
        return $formatted;
    }

    public function getPagSeguroMessage($status)
    {
        switch ($status) {
            case '1':
                $message = 'Aguardando Pagamento';
                break;
            case '2':
                $message = 'Em Análise';
                break;
            case '3':
                $message = 'Paga';
                break;
            case '4':
                $message = 'Disponível';
                break;
            case '5':
                $message = 'Em Disputa';
                break;
            case '6':
                $message = 'Devolvida';
                break;
            case '7':
                $message = 'Cancelada';
                break;
            case '8':
                $message = 'Chargeback Debitado';
                break;
            case '9':
                $message = 'Em Contestação';
                break;
            default:
                $message = 'Erro ao obter o status';
                break;
        }
        return $message;
    }

    public function updateOrderStatus($order, $status, $type = '')
    {
        $order_id = method_exists($order, 'get_id') ? $order->get_id() : $order->id;
        $mensagem = '';
        $status_iniciado = $this->get_option('status_iniciado');
        $status_aprovado = $this->get_option('status_aprovado');
        $status_cancelado = $this->get_option('status_cancelado');
        $status_aguardando = $this->get_option('status_aguardando');
        $this->writeLog("updateOrderStatus()", false, 'info');
        $this->writeLog("OrderID: ".$order_id, false, 'info');
        $this->writeLog("Status PagSeguro: ".$status, false, 'info');

        switch ($status) {
            case '1':
                //Aguardando Pagamento
                $mensagem = 'Aguardando pagamento: o comprador iniciou a transação, mas até o momento o PagSeguro não recebeu nenhuma informação sobre o pagamento.';
                $this->mudaStatus($order, $status_iniciado, __('PagSeguro: The buyer initiated the transaction, but so far the PagSeguro not received any payment information.', PAGSEGURO_DOMAIN));
                break;
            case '2':
                //Em Análise
                $mensagem = 'Em análise: o comprador optou por pagar com um cartão de crédito e o PagSeguro está analisando o risco da transação.';
                $this->mudaStatus($order, $status_aguardando, __('PagSeguro: Payment under review.', PAGSEGURO_DOMAIN));
                break;
            case '3':
                //Paga
                $mensagem = 'Paga: a transação foi paga pelo comprador e o PagSeguro já recebeu uma confirmação da instituição financeira responsável pelo processamento.';
                $this->mudaStatus($order, $status_aprovado, __('PagSeguro: Payment approved.', PAGSEGURO_DOMAIN));
                break;
            case '4':
                //Disponível
                $mensagem = 'Disponível: a transação foi paga e chegou ao final de seu prazo de liberação sem ter sido retornada e sem que haja nenhuma disputa aberta.';
                $this->mudaStatus($order, $status_aprovado, __('PagSeguro: Payment completed and credited to your account.', PAGSEGURO_DOMAIN));
                break;
            case '5':
                //Em Disputa
                $mensagem = 'Em disputa: o comprador, dentro do prazo de liberação da transação, abriu uma disputa.';
                $this->mudaStatus($order, $status_cancelado, __('PagSeguro: Payment came into dispute.', PAGSEGURO_DOMAIN));
                break;
            case '6':
                //Devolvida
                $mensagem = 'Devolvida: o valor da transação foi devolvido para o comprador.';
                $this->mudaStatus($order, $status_cancelado, __('PagSeguro: Payment refunded.', PAGSEGURO_DOMAIN));
                break;
            case '7':
                //Cancelada
                $mensagem = 'Retentativa: a transação ia ser cancelada (status 7), mas a opção de retentativa estava ativada. O pedido será cancelado posteriormente caso o cliente não use o link de retentativa no prazo estabelecido.';
                $this->mudaStatus($order, $status_cancelado, __('PagSeguro: Payment canceled.', PAGSEGURO_DOMAIN));
                break;
            case '8':
                //Chargeback Debitado
                $mensagem = 'Debitado: o valor do chargeback foi debitado da sua conta.';
                $this->mudaStatus($order, $status_cancelado, __('PagSeguro: Payment refunded.', PAGSEGURO_DOMAIN));
                break;
            case '9':
                //Em Contestação
                $mensagem = 'Em contestação: o titular do cartão contestou a transação.';
                $this->mudaStatus($order, $status_cancelado, __('PagSeguro: Payment refunded.', PAGSEGURO_DOMAIN));
                break;
            default:
                break;
        }
        if (!empty($mensagem)) {
            $mensagem = !empty($type) ? '['.strtoupper($type).'] '.$mensagem : $mensagem;
            $this->writeLog("Mensagem: ".$mensagem, false, 'info');
            $order->add_order_note($mensagem);
        }
    }

    public function reduceStock($order_id)
    {
        if (function_exists('wc_reduce_stock_levels')) {
            wc_reduce_stock_levels($order_id);
        }
    }

    public function increaseStock($order_id)
    {
        if (function_exists('wc_increase_stock_levels')) {
            wc_increase_stock_levels($order_id);
        }
    }

    public static function mudaStatus($order, $status, $mensagem)
    {
        if (!empty($status)) {
            $order->update_status($status, $mensagem.' - ');
        }
    }

    public function validate_fields()
    {
        return true;
    }

    public function validate_payload($payload, $order)
    {
        $notAuthorised = __('Pagamento não autorizado:', PAGSEGURO_DOMAIN);

        //billing
        if(empty($payload['billingAddressStreet'])) {
            $error_message = __(' Preencha o Endereço de cobrança.', PAGSEGURO_DOMAIN);
            wc_add_notice($notAuthorised.$error_message, 'error');
        }
        elseif(strlen($payload['billingAddressStreet']) > 80) {
            $error_message = __(' Tamanho máximo do endereço de cobrança excedido, limite: 80 caracteres.', PAGSEGURO_DOMAIN);
            wc_add_notice($notAuthorised.$error_message, 'error');
        }

        if(strlen($payload['billingAddressNumber']) < 1) {
            $error_message = __(' Preencha o Número do endereço de cobrança.', PAGSEGURO_DOMAIN);
            wc_add_notice($notAuthorised.$error_message, 'error');
        }
        elseif(strlen($payload['billingAddressNumber']) > 20) {
            $error_message = __(' Tamanho máximo do número do endereço de cobrança excedido, limite: 20 caracteres.', PAGSEGURO_DOMAIN);
            wc_add_notice($notAuthorised.$error_message, 'error');
        }

        if(empty($payload['billingAddressDistrict'])) {
            $error_message = __(' Preencha o Bairro do endereço de cobrança.', PAGSEGURO_DOMAIN);
            wc_add_notice($notAuthorised.$error_message, 'error');
        }
        elseif(strlen($payload['billingAddressDistrict']) > 60) {
            $error_message = __(' Tamanho máximo do bairro do endereço de cobrança excedido, limite: 60 caracteres.', PAGSEGURO_DOMAIN);
            wc_add_notice($notAuthorised.$error_message, 'error');
        }

        if(strlen($payload['billingAddressComplement']) > 40) {
            $error_message = __(' Tamanho máximo do complemento do endereço de cobrança excedido, limite: 60 caracteres.', PAGSEGURO_DOMAIN);
            wc_add_notice($notAuthorised.$error_message, 'error');
        }

        if(empty($payload['billingAddressPostalCode'])) {
            $error_message = __(' Preencha o CEP do endereço de cobrança.', PAGSEGURO_DOMAIN);
            wc_add_notice($notAuthorised.$error_message, 'error');
        }
        elseif(strlen(preg_replace('/\D/', '', $payload['billingAddressPostalCode'])) != 8) {
            $error_message = __(' CEP do endereço de cobrança inválido.', PAGSEGURO_DOMAIN);
            wc_add_notice($notAuthorised.$error_message, 'error');
        }

        if(empty($payload['billingAddressCity'])) {
            $error_message = __(' Preencha a Cidade do endereço de cobrança.', PAGSEGURO_DOMAIN);
            wc_add_notice($notAuthorised.$error_message, 'error');
        }
        elseif(strlen($payload['billingAddressCity']) > 60) {
            $error_message = __(' Tamanho máximo da cidade do endereço de cobrança excedido, limite: 60 caracteres.', PAGSEGURO_DOMAIN);
            wc_add_notice($notAuthorised.$error_message, 'error');
        }

        if(empty($payload['billingAddressState'])) {
            $error_message = __(' Preencha o Estado do endereço de cobrança.', PAGSEGURO_DOMAIN);
            wc_add_notice($notAuthorised.$error_message, 'error');
        }
        elseif(strlen($payload['billingAddressState']) != 2) {
            $error_message = __(' Estado do endereço de cobrança inválido, limite: 2 caracteres.', PAGSEGURO_DOMAIN);
            wc_add_notice($notAuthorised.$error_message, 'error');
        }

        //shipping
        if($payload['shippingAddressRequired'] == 'true') {
            if(empty($payload['shippingAddressStreet'])) {
                $error_message = __(' Preencha o Endereço de entrega.', PAGSEGURO_DOMAIN);
                wc_add_notice($notAuthorised.$error_message, 'error');
            }
            elseif(strlen($payload['shippingAddressStreet']) > 80) {
                $error_message = __(' Tamanho máximo do endereço de entrega excedido, limite: 80 caracteres.', PAGSEGURO_DOMAIN);
                wc_add_notice($notAuthorised.$error_message, 'error');
            }

            if(strlen($payload['shippingAddressNumber']) < 1) {
                $error_message = __(' Preencha o Número do endereço de entrega.', PAGSEGURO_DOMAIN);
                wc_add_notice($notAuthorised.$error_message, 'error');
            }
            elseif(strlen($payload['shippingAddressNumber']) > 20) {
                $error_message = __(' Tamanho máximo do número do endereço de entrega excedido, limite: 20 caracteres.', PAGSEGURO_DOMAIN);
                wc_add_notice($notAuthorised.$error_message, 'error');
            }

            if(empty($payload['shippingAddressDistrict'])) {
                $error_message = __(' Preencha o Bairro do endereço de entrega.', PAGSEGURO_DOMAIN);
                wc_add_notice($notAuthorised.$error_message, 'error');
            }
            elseif(strlen($payload['shippingAddressDistrict']) > 60) {
                $error_message = __(' Tamanho máximo do bairro do endereço de entrega excedido, limite: 60 caracteres.', PAGSEGURO_DOMAIN);
                wc_add_notice($notAuthorised.$error_message, 'error');
            }

            if(strlen($payload['shippingAddressComplement']) > 40) {
                $error_message = __(' Tamanho máximo do complemento do endereço de entrega excedido, limite: 60 caracteres.', PAGSEGURO_DOMAIN);
                wc_add_notice($notAuthorised.$error_message, 'error');
            }

            if(empty($payload['shippingAddressPostalCode'])) {
                $error_message = __(' Preencha o CEP do endereço de entrega.', PAGSEGURO_DOMAIN);
                wc_add_notice($notAuthorised.$error_message, 'error');
            }
            elseif(strlen(preg_replace('/\D/', '', $payload['shippingAddressPostalCode'])) != 8) {
                $error_message = __(' CEP do endereço de entrega inválido.', PAGSEGURO_DOMAIN);
                wc_add_notice($notAuthorised.$error_message, 'error');
            }

            if(empty($payload['shippingAddressCity'])) {
                $error_message = __(' Preencha a Cidade do endereço de entrega.', PAGSEGURO_DOMAIN);
                wc_add_notice($notAuthorised.$error_message, 'error');
            }
            elseif(strlen($payload['shippingAddressCity']) > 60) {
                $error_message = __(' Tamanho máximo da cidade do endereço de entrega excedido, limite: 60 caracteres.', PAGSEGURO_DOMAIN);
                wc_add_notice($notAuthorised.$error_message, 'error');
            }

            if(empty($payload['shippingAddressState'])) {
                $error_message = __(' Preencha o Estado do endereço de entrega.', PAGSEGURO_DOMAIN);
                wc_add_notice($notAuthorised.$error_message, 'error');
            }
            elseif(strlen($payload['shippingAddressState']) != 2) {
                $error_message = __(' Estado do endereço de entrega inválido, limite: 2 caracteres.', PAGSEGURO_DOMAIN);
                wc_add_notice($notAuthorised.$error_message, 'error');
            }
        }

        //payment
        if(empty($payload['senderName'])) {
            $error_message = __(' Preencha o Nome do comprador.', PAGSEGURO_DOMAIN);
            wc_add_notice($notAuthorised.$error_message, 'error');
        }
        elseif(strlen($payload['senderName']) > 50) {
            $error_message = __(' Tamanho máximo do nome do comprador excedido, limite: 50 caracteres.', PAGSEGURO_DOMAIN);
            wc_add_notice($notAuthorised.$error_message, 'error');
        }

        if(!$this->validaCpf($payload['senderCPF'])) {
            $error_message = __(' CPF do comprador inválido.', PAGSEGURO_DOMAIN);
            wc_add_notice($notAuthorised.$error_message, 'error');
        }

        $phone = $payload['senderAreaCode'].$payload['senderPhone'];
        if(!preg_match('/^((1[1-9])|([2-9][0-9]))(([0-9]{4}[0-9]{4})|(9[0-9]{3}[0-9]{5}))$/', $phone)) {
            $error_message = __(' Telefone do comprador inválido.', PAGSEGURO_DOMAIN);
            wc_add_notice($notAuthorised.$error_message, 'error');
        }

        if(empty($payload['senderEmail'])) {
            $error_message = __(' Preencha o Email do comprador.', PAGSEGURO_DOMAIN);
            wc_add_notice($notAuthorised.$error_message, 'error');
        }
        elseif(!filter_var($payload['senderEmail'], FILTER_VALIDATE_EMAIL)) {
            $error_message = __(' Email do comprador inválido.', PAGSEGURO_DOMAIN);
            wc_add_notice($notAuthorised.$error_message, 'error');
        }
        elseif(strlen($payload['senderEmail']) > 60) {
            $error_message = __(' Tamanho máximo do email do comprador excedido, limite: 60 caracteres.', PAGSEGURO_DOMAIN);
            wc_add_notice($notAuthorised.$error_message, 'error');
        }

        if(!empty($error_message)) {
            $errocompleto = sprintf("Erro: %s", $error_message);
            $order->add_order_note($errocompleto);
            return false;
        }
        return true;
    }

    public function process_payment($order_id)
    {
        $this->writeLog('----- INÍCIO DO PAGAMENTO -----', false, 'info');
        global $woocommerce;
        global $wp_version;
        $order = new WC_Order($order_id);
        $erro = false;
        $total = (float) $order->get_total();
        $method = $_POST['ps-transparent-payment-radio'];

        $payload = $this->get_pagseguro_payload($order, $method);
        $erro = !$this->validate_payload($payload, $order);

        if(!$erro) {
            $url = $this->ws_path()."/v2/checkout?email={$this->get_email()}&token={$this->get_token()}";
            $headers = array(
                'Content-Type' => 'application/x-www-form-urlencoded',
            );

            $majorminor = $this->format_woo_version(WC_VERSION);
            $headers['cms-description'] = 'woocommerce-oficial-v.'.$majorminor;
            $headers['module-description'] = 'WordPress v.'.$wp_version.'-WooCommerce v.'.WC_VERSION.'(Redirect Checkout)';
            $headers['module-version'] = PAGSEGURO_VERSION;

            foreach ($payload as $key => $value) {
                $fixedPayload[$key] = $this->retiracento($value);
            }
            $args = array(
                'body'    => $fixedPayload,
                'timeout' => 60,
                'headers' => $headers,
                'cookies' => array(),
            );
            $this->writeLog(wc_print_r($fixedPayload, true), false, 'info');
            $result = wp_remote_post($url, $args);

            $rawXml = $result['body'];
            $responseCode = $result['response']['code'];

            $this->writeLog('Response Code: '.$responseCode, false, 'info');
            $this->writeLog($rawXml, false, 'info');

            $timeoutCodes = array(408, 504, 524, 598);
            $xml = simplexml_load_string($rawXml, 'SimpleXMLElement', LIBXML_NOWARNING);
            if ($responseCode == 200) {
                //OK
                //$status = $xml->status;
                $tid = $xml->code;
                //update_post_meta($order_id, '_ps_method', (string) $method);
                //update_post_meta($order_id, '_ps_status', (string) $status);
                //update_post_meta($order_id, '_ps_tid', (string) $tid);
                $transactionString = "Link de redirect gerado. CheckoutCode: ".$tid;
                 //recuperar link
                $link = 'https://'.($this->is_sandbox() ? 'sandbox.' : '').'pagseguro.uol.com.br/v2/checkout/payment.html?code='.$tid;
                update_post_meta($order_id, '_ps_redirect_url', (string) $link);
                update_post_meta($order_id, '_ps_method', 'redirect');
                $transactionString .= " - Link de pagamento: $link";

                $order->add_order_note($transactionString);
                //$this->updateOrderStatus($order, $status);
                $this->writeLog($transactionString, false, 'info');
            } elseif ($responseCode == 401) {
                //erro autenticação
                $erro = true;
                wc_add_notice(__('Erro no pagamento, entre em contato com o lojista.', 'error'));
                $error_message = "($responseCode) Erro de autenticação com o PagSeguro, confira suas credenciais.";
                $additional = 'Ambiente selecionado: '.strtoupper($this->pagseguro_environment);
                $errocompleto = sprintf("Erro: %s - Detalhes do erro: %s", $error_message, $additional);
                $order->add_order_note($errocompleto);
                $this->writeLog($errocompleto, false, 'error');
            } elseif (in_array($responseCode, $timeoutCodes)) {
                $status = 1;
                $transactionString = __('Ocorreu um timeout na transação. Aguardar retorno PagSeguro.', PAGSEGURO_DOMAIN);
                $link = (string) $this->get_return_url($order);

                $order->add_order_note($transactionString);
                $order->add_order_note($rawXml);
                $this->updateOrderStatus($order, $status);
                $this->writeLog($transactionString, false, 'error');
            } else {
                //erro nos dados
                $erro = true;
                $errorCode = $xml->error->code;
                $errorMessage = $xml->error->message;
                if (!empty($errorCode)) {
                    $errorString = __('Pagamento não autorizado: ', PAGSEGURO_DOMAIN)."($errorCode) ".$errorMessage;
                    wc_add_notice($errorString, 'error');
                } else {
                    $errorString = "Ocorreu um erro na comunicação com o PagSeguro: ($responseCode) $rawXml";
                }
                $order->add_order_note($errorString);
                $this->writeLog($errorString, false, 'error');
            }
        }
        if (!$erro) {
            $order->set_total($total);
            $woocommerce->cart->empty_cart();
            return array(
                'result'   => 'success',
                'redirect' => $link, //$this->get_return_url($order),
            );
        } else {
            return array(
                'result'   => 'fail',
                'redirect' => '',
            );
        }
        $this->writeLog('----- FIM DO PAGAMENTO -----', false, 'info');
    }

    public function get_pagseguro_payload($order, $method)
    {
        $payload = array();
        $order_id = $order->get_id();
        $items = $this->getDescricaoPedido($order);
        $args = $this->getOrderData($order);
        $documento = !empty($args['documento']) ? $args['documento'] : '';
        $documento = preg_replace('/[\D]/', '', $documento);
        $total = (float) $order->get_total();

        $payload['receiverEmail'] = $this->get_email();
        $payload['currency'] = 'BRL';

        foreach ($items as $key => $item) {
            $payload['itemId'.$key] = $item['id'];
            $payload['itemDescription'.$key] = $item['descr'];
            $payload['itemAmount'.$key] = $item['valor'];
            $payload['itemQuantity'.$key] = $item['quant'];
        }

        $payload['reference'] = $order_id;
        $payload['senderName'] = $args['billingName'];
        $payload['senderCPF'] = $documento;
        $senderPhone = $args['billingPhone'];
        $ddd = substr($senderPhone, 0, 2);
        $phone = substr($senderPhone, 2);
        $payload['senderAreaCode'] = $ddd;
        $payload['senderPhone'] = $phone;
        $payload['senderEmail'] = $this->is_sandbox() ? substr($args['billingEmail'], 0, strpos($args['billingEmail'], '@')).'@sandbox.pagseguro.com.br' : $args['billingEmail'];
        $payload['senderHash'] = (isset($_POST['ps_transparent_sender_hash'])) ? $_POST['ps_transparent_sender_hash'] : '';

        //TODO: HABILITAR/DESABILITAR MÉTODOS CHECKOUT
        //TODO: INFORMAR CONFIGURAÇÕES DE PARCELAMENTO PARA O CHECKOUT PS

        //paymentMethodConfigs.paymentMethodConfig.paymentMethod.group
        //paymentMethodConfigs.paymentMethodConfig.configs.config.key
        //paymentMethodConfigs.paymentMethodConfig.paymentMethod.value

        if (!empty($args['shippingPostcode'])) {
            $payload['shippingAddressRequired'] = 'true';

            $payload['shippingAddressStreet'] = $args['shippingAddress'];
            $payload['shippingAddressNumber'] = $args['shippingNumber'];
            $payload['shippingAddressComplement'] = $args['shippingAddress2'];
            $payload['shippingAddressDistrict'] = $args['shippingNeighborhood'];
            $payload['shippingAddressPostalCode'] = $args['shippingPostcode'];
            $payload['shippingAddressCity'] = $args['shippingCity'];
            $payload['shippingAddressState'] = $args['shippingState'];
            $payload['shippingAddressCountry'] = 'BRA';
            $payload['shippingType'] = 3;

            if ($order->get_total_shipping() > 0) {
                $payload['shippingCost'] = number_format($order->get_total_shipping(), 2, '.', '');
            }
        } else {
            $payload['shippingAddressRequired'] = 'false';
        }

        $payload['billingAddressStreet'] = $args['billingAddress'];
        $payload['billingAddressNumber'] = $args['billingNumber'];
        $payload['billingAddressComplement'] = $args['billingAddress2'];
        $payload['billingAddressDistrict'] = $args['billingNeighborhood'];
        $payload['billingAddressPostalCode'] = $args['billingPostcode'];
        $payload['billingAddressCity'] = $args['billingCity'];
        $payload['billingAddressState'] = $args['billingState'];
        $payload['billingAddressCountry'] = 'BRA';

        $payload['enableRecover'] = 'FALSE';
        $payload['timeout'] = '30';

        $payload['notificationURL'] = home_url('/wc-api/wc_gateway_pagseguro_ipn');
        $payload['redirectURL'] = $this->get_return_url($order);
        $payload['maxUses'] = 1;
        //TODO: REDIRECT URL

        $exclude = '';
        if($this->credit == 'yes') {
            $exclude .= 'CREDIT_CARD,';
        }
        if($this->debit == 'yes') {
            $exclude .= 'EFT,';
        }
        if($this->billet == 'yes') {
            $exclude .= 'BOLETO,';
        }
        $exclude = rtrim($exclude, ',');

        if(!empty($exclude)) {
            $payload['excludePaymentMethodGroup'] = $exclude;
        }

        $grupo = 0;
        if($this->credit != 'yes') {
            $grupo++;
            $payload['paymentMethodGroup'.$grupo] = 'CREDIT_CARD';
            $payload['paymentMethodConfigKey'.$grupo.'_1'] = 'MAX_INSTALLMENTS_NO_INTEREST';
            $payload['paymentMethodConfigValue'.$grupo.'_1'] = $this->credit_interest_free;
            $payload['paymentMethodConfigKey'.$grupo.'_2'] = 'MAX_INSTALLMENTS_LIMIT';
            $payload['paymentMethodConfigValue'.$grupo.'_2'] = $this->credit_max_installment;
        }
        if($this->billet != 'yes' && $this->billet_discount != 'none' && $this->billet_discount_amount > 0) {
            $grupo++;
            $discount = number_format($this->billet_discount_amount, 2, '.', '');
            $payload['paymentMethodGroup'.$grupo] = 'BOLETO';
            $payload['paymentMethodConfigKey'.$grupo.'_1'] = 'DISCOUNT_PERCENT';
            $payload['paymentMethodConfigValue'.$grupo.'_1'] = $discount;
        }

        return $payload;
    }

    public function getOrderData($order)
    {
        $args = array();
        // WooCommerce 3.0 or later.
        if (method_exists($order, 'get_meta')) {
            $args['billingAddress'] = $order->get_billing_address_1();
            $args['billingNumber'] = $order->get_meta('_billing_number');
            if (empty($args['billingNumber'])) {
                $args['billingNumber'] = preg_replace('/\D/', '', $args['billingAddress']);
            }
            $cpf = $order->get_meta('_billing_cpf');
            $cnpj = $order->get_meta('_billing_cnpj');
            $documento = empty($cpf) ? $cnpj : $cpf;
            $args['userId'] = $order->get_user_id();
            $args['documento'] = $documento;
            $args['billingName'] = $order->get_billing_first_name().' '.$order->get_billing_last_name();
            $args['billingEmail'] = $order->get_billing_email();
            $args['billingPhone'] = $order->get_billing_phone();
            $args['billingCellphone'] = $order->get_meta('_billing_cellphone');
            $args['billingNeighborhood'] = $order->get_meta('_billing_neighborhood');
            $args['billingAddress2'] = $order->get_billing_address_2();
            $args['billingCity'] = $order->get_billing_city();
            $args['billingState'] = $order->get_billing_state();
            $args['billingPostcode'] = $order->get_billing_postcode();
            $args['billingBirthdate'] = $order->get_meta('_billing_birthdate');
            $args['billingSex'] = $order->get_meta('_billing_sex');

            // Shipping fields.
            $args['shippingAddress'] = $order->get_shipping_address_1();
            $args['shippingNumber'] = $order->get_meta('_shipping_number');
            if (empty($args['shippingNumber'])) {
                $args['shippingNumber'] = preg_replace('/\D/', '', $args['shippingAddress']);
            }
            $args['shippingNeighborhood'] = $order->get_meta('_shipping_neighborhood');
            $args['shippingAddress2'] = $order->get_shipping_address_2();
            $args['shippingPostcode'] = $order->get_shipping_postcode();
            $args['shippingCity'] = $order->get_shipping_city();
            $args['shippingState'] = $order->get_shipping_state();
        } else {
            $args['billingAddress'] = $order->billing_address_1;
            if (!empty($order->billing_number)) {
                $args['billingNumber'] = $order->billing_number;
            } else {
                $args['billingNumber'] = preg_replace('/\D/', '', $order->billing_address_1);
            }
            $cpf = $order->billing_cpf;
            $cnpj = $order->billing_cnpj;
            $documento = empty($cpf) ? $cnpj : $cpf;
            $args['userId'] = $order->user_id;
            $args['documento'] = $documento;
            $args['billingName'] = $order->billing_first_name.' '.$order->billing_last_name;
            $args['billingEmail'] = $order->billing_email;
            $args['billingPhone'] = $order->billing_phone;
            $args['billingCellphone'] = $order->billing_cellphone;
            $args['billingNeighborhood'] = $order->billing_neighborhood;
            $args['billingAddress2'] = $order->billing_address_2;
            $args['billingCity'] = $order->billing_city;
            $args['billingState'] = $order->billing_state;
            $args['billingPostcode'] = $order->billing_postcode;
            $args['billingBirthdate'] = $order->billing_birthdate;
            $args['billingSex'] = $order->billing_sex;

            $args['shippingAddress'] = $order->shipping_address_1;
            if (!empty($order->shipping_number)) {
                $args['shippingNumber'] = $order->shipping_number;
            } else {
                $args['shippingNumber'] = preg_replace('/\D/', '', $order->shipping_address_1);
            }
            $args['shippingNeighborhood'] = $order->shipping_neighborhood;
            $args['shippingAddress2'] = $order->shipping_address_2;
            $args['shippingPostcode'] = $order->shipping_postcode;
            $args['shippingCity'] = $order->shipping_city;
            $args['shippingState'] = $order->shipping_state;
        }
        $args['billingNumber'] = preg_replace('/[\D]/', '', $args['billingNumber']);
        $args['billingPhone'] = preg_replace('/[\D]/', '', $args['billingPhone']);
        if (strlen($args['billingNumber']) > 5) {
            $args['billingNumber'] = substr($args['billingNumber'], 0, 5);
        }
        if (empty($args['billingNumber'])) {
            $args['billingNumber'] = '00';
        }
        return $args;
    }

    public function update_order_status($payload, $type = '')
    {
        if (isset($payload->reference)) {
            $id = (string) $payload->reference;
            $status = (int) $payload->status;
            $order = wc_get_order($id);

            // Check if order exists.
            if (!$order) {
                return;
            }

            $order_id = method_exists($order, 'get_id') ? $order->get_id() : $order->id;

            // Checks whether the invoice number matches the order.
            // If true processes the payment.
            if ($order_id == $id) {
                $this->writeLog('Atualizando status do pedido '.$order->get_order_number().', novo status: '.$status, false, 'info');
                $this->updateOrderStatus($order, $status, $type);
                update_post_meta($order_id, '_ps_status', (string) $status);
            } else {
                $this->writeLog('ReferenceID PagSeguro ('.$id.') diferente do número do pedido ('.$order->get_order_number().')', false, 'error');
            }
        }
    }

    public function getDescricaoPedido($order)
    {
        $cartItems = $order->get_items();
        $itemsData = array();
        $json = array();
        $i = 0;
        foreach ($cartItems as $item) {
            $itemsData["quant"] = $item['qty'];
            $itemsData["descr"] = preg_replace('/[<>\-&%\/]/', '', $item['name']);
            $itemsData["valor"] = number_format($item['line_subtotal'] / $item['qty'], 2, '.', '');
            $itemsData["id"] = $item['product_id'];
            $json[++$i] = $itemsData;
        }
        return $json;
    }

    /**
     * Can the order be refunded via PagSeguro?
     *
     * @param  WC_Order $order Order object.
     * @return bool
     */
    public function can_refund_order($order)
    {
        $order_id = $order->get_id();
        $tid = get_post_meta($order_id, '_ps_tid', true);
        $status = get_post_meta($order_id, '_ps_status', true);
        $method = get_post_meta($order_id, '_ps_method', true);

        // cancel: (1) Aguardando pagamento / (2) Em análise
        // refund: (3) Paga / (4) Disponível / (5) Em disputa
        $can_refund_statuses = array('1', '2', '3', '4', '5');
        $can_refund_methods = array('creditCard', 'boleto', 'eft', 'redirect');

        return $order && !empty($tid) && in_array($status, $can_refund_statuses) && in_array($method, $can_refund_methods);
    }

    /**
     * Process a refund if supported.
     *
     * @param  int    $order_id Order ID.
     * @param  float  $amount Refund amount.
     * @param  string $reason Refund reason.
     * @return bool|WP_Error
     */
    public function process_refund($order_id, $amount = null, $reason = '')
    {
        $this->writeLog('----- SOLICITAÇÃO REFUND -----', false, 'info');
        $this->writeLog('OrderID: '.$order_id, false, 'info');
        $this->writeLog('Amount: '.$amount, false, 'info');
        $order = wc_get_order($order_id);
        $order_id = $order->get_id();
        $transid = get_post_meta($order_id, '_ps_tid', true);
        $status = get_post_meta($order_id, '_ps_status', true);
        $cancelStatuses = array('1', '2');
        $refundStatuses = array('3', '4', '5');
        $params = array('transactionCode' => $transid);

        if (is_null($amount)) {
            $amount = $order->get_total();
        }

        //orderdate + 90 > today
        $orderDate = $order->order_date;
        $newDate = date('Y-m-d', strtotime($orderDate.' +90 days'));
        if ($newDate < date('Y-m-d')) {
            $message = __('O prazo máximo para solicitar um estorno é de até 90 dias após a data de compra.', 'woocommerce');
            $this->writeLog($message, false, 'error');
            return new WP_Error('error', $message);
        }

        //empty transactionCode
        if (empty($transid)) {
            $message = __('Transação não possui transactionCode. Por favor, consulte a transação através do botão "Consulta" e tente novamente.', 'woocommerce');
            $this->writeLog($message, false, 'error');
            return new WP_Error('error', $message);
        }

        $operation = '';
        if (in_array($status, $cancelStatuses)) {
            if ($amount < $order->get_total()) {
                $message = __('Não é possível realizar cancelamento parcial. Caso deseje realizar um estorno parcial, aguarde a mudança do status do pedido no PagSeguro.', 'woocommerce');
                $this->writeLog($message, false, 'error');
                return new WP_Error('error', $message);
            }
            $operation = 'cancels';
        }
        if (in_array($status, $refundStatuses)) {
            if ($amount >= $order->get_total()) {
                //não enviar amount caso seja igual ao total
                $amount = 0;
            }
            $operation = 'refunds';
        }

        if (!empty($operation)) {
            $url = $this->ws_path()."/v2/transactions/".$operation."?email={$this->get_email()}&token={$this->get_token()}";
            $headers = array(
                'Content-Type' => 'application/x-www-form-urlencoded',
            );
            if ($operation == 'refunds' && $amount > 0) {
                $params['refundValue'] = $amount;
            }
            $args = array(
                'body'    => $params,
                'timeout' => 60,
                'headers' => $headers,
                'cookies' => array(),
            );
            $this->writeLog(wc_print_r($params, true), false, 'info');
            $result = wp_remote_post($url, $args);
            $rawXml = $result['body'];
            $responseCode = $result['response']['code'];

            $this->writeLog('Response Code: '.$responseCode, false, 'info');
            $this->writeLog($rawXml, false, 'info');
            $xml = simplexml_load_string($rawXml, 'SimpleXMLElement', LIBXML_NOWARNING);

            $operation = substr($operation, 0, -1);
            if ($responseCode == 200) {
                $response = json_decode(json_encode($xml), true);
                $response = (string) array_shift($response);

                $message = sprintf(__('Reembolso - Operação: %1$s (%2$s)', 'woocommerce'), $operation, $response);
                $order->add_order_note('Resposta do Reembolso: '.$message);
                $this->writeLog($message, false, 'info');
                return true;
            } else {
                $code = $xml->error->code;
                $message = $xml->error->message;
                $error = sprintf(__('Ocorreu um erro ao efetuar o reembolso. Operação: %1$s (%2$s) %3$s', 'woocommerce'), $operation, $code, $message);
                $order->add_order_note('Resposta do Reembolso: '.$error);

                if ($code == 56002) {
                    $error = 'Não é possível cancelar uma transação com o status atual. Por favor, tente consultar manualmente a transação e em seguida tente novamente.';
                    $order->add_order_note($error);
                }

                $this->writeLog($error, false, 'error');
                return new WP_Error('error', $error);
            }
        } else {
            $message = sprintf(__('Status (%1$s) não permite refund ou cancelamento.', 'woocommerce'), $this->getPagSeguroMessage($status));
            $this->writeLog($message, false, 'error');
            return new WP_Error('error', $message);
        }
    }

    public static function consultTransaction()
    {
        $order_id = $_REQUEST['order'];
        $transid = $_REQUEST['transid'];

        $instance = new WC_Pagseguro_Payment_Gateway();
        $instance->writeLog('----- CONSULTA-----', false, 'info');
        $instance->writeLog('OrderID: '.$order_id, false, 'info');
        $instance->writeLog('TransactionCode: '.$transid, false, 'info');

        $order = new WC_Order($order_id);

        if (empty($transid)) {
            $url = add_query_arg(array('email' => $instance->get_email(), 'token' => $instance->get_token(), 'reference' => $order_id), $instance->consult_transaction_url(''));
            $result = wp_remote_get($url);
            try {
                $rawXml = $result['body'];
                $instance->writeLog($rawXml, false, 'info');
                $xml = simplexml_load_string($rawXml, 'SimpleXMLElement', LIBXML_NOWARNING);
                $transid = (string) $xml->transactions->transaction->code;
                delete_post_meta($order_id, '_ps_tid');
                update_post_meta($order_id, '_ps_tid', (string) $transid);
                $instance->writeLog('TransactionCode atualizado: '.$transid, false, 'info');
            } catch (Exception $e) {
                $xml = '';
            }
        }

        if (!empty($transid)) {
            // Consult via transactionCode
            $url = add_query_arg(array('email' => $instance->get_email(), 'token' => $instance->get_token()), $instance->consult_transaction_url(esc_attr($transid)));
            $result = wp_remote_get($url);
        } else {
            $result = array();
        }

        // Check to see if the request was valid.
        if (is_wp_error($result)) {
            if ('yes' == $instance->debug) {
                $instance->writeLog('Erro WP_Error: '.$response->get_error_message(), false, 'error');
            }
        } else {
            try {
                $rawXml = $result['body'];
                $instance->writeLog($rawXml, false, 'info');
                $xml = simplexml_load_string($rawXml, 'SimpleXMLElement', LIBXML_NOWARNING);
            } catch (Exception $e) {
                $xml = '';
            }
        }

        if (!empty($xml)) {
            $instance->update_order_status($xml, 'consulta');
        }
        $status = (string) $xml->status;
        $mensagem = (string) $instance->getPagSeguroMessage($xml->status);
        $retorno = array('status' => $status, 'mensagem' => $mensagem);

        $instance->writeLog(wc_print_r($retorno, true), false, 'info');
        $instance->writeLog('----- FIM DA CONSULTA -----', false, 'info');
        echo json_encode($retorno);
        wp_die();
    }

    public function writeLog($msg, $force = false, $level = 'info')
    {
        // debug
        // info
        // notice
        // warning
        // error
        // critical
        // alert
        // emergency
        if ('yes' == $this->debug || $force) {
            $this->log->$level($msg, $this->context);
        }
    }

    public function link_log()
    {
        if (defined('WC_VERSION') && version_compare(WC_VERSION, '2.2', '>=')) {
            return '<a href="'.esc_url(admin_url('admin.php?page=wc-status&tab=logs&log_file='.esc_attr($this->id).'-'.sanitize_file_name(wp_hash($this->id)).'.log')).'">'.__('Logs', PAGSEGURO_DOMAIN).'</a>';
        }

        return '<code>woocommerce/logs/'.esc_attr($this->id).'-'.sanitize_file_name(wp_hash($this->id)).'.txt</code>';
    }

    public function retiracento($texto)
    {
        $trocarIsso = array('à', 'á', 'â', 'ã', 'ä', 'å', 'ç', 'è', 'é', 'ê', 'ë', 'ì', 'í', 'î', 'ï', 'ñ', 'ò', 'ó', 'ô', 'õ', 'ö', 'ù', 'ü', 'ú', 'ÿ', 'À', 'Á', 'Â', 'Ã', 'Ä', 'Å', 'Ç', 'È', 'É', 'Ê', 'Ë', 'Ì', 'Í', 'Î', 'Ï', 'Ñ', 'Ò', 'Ó', 'Ô', 'Õ', 'Ö', 'O', 'Ù', 'Ü', 'Ú', 'Ÿ');
        $porIsso = array('a', 'a', 'a', 'a', 'a', 'a', 'c', 'e', 'e', 'e', 'e', 'i', 'i', 'i', 'i', 'n', 'o', 'o', 'o', 'o', 'o', 'u', 'u', 'u', 'y', 'A', 'A', 'A', 'A', 'A', 'A', 'C', 'E', 'E', 'E', 'E', 'I', 'I', 'I', 'I', 'N', 'O', 'O', 'O', 'O', 'O', 'O', 'U', 'U', 'U', 'Y');
        $titletext = str_replace($trocarIsso, $porIsso, $texto);
        return $titletext;
    }

    public function validaCpf($cpf)
    {
        // Extrai somente os números
        $cpf = preg_replace('/[^0-9]/is', '', $cpf);

        // Verifica se foi informado todos os digitos corretamente
        if (strlen($cpf) != 11) {
            return false;
        }
        // Verifica se foi informada uma sequência de digitos repetidos. Ex: 111.111.111-11
        if (preg_match('/(\d)\1{10}/', $cpf)) {
            return false;
        }
        // Faz o calculo para validar o CPF
        for ($t = 9; $t < 11; $t++) {
            for ($d = 0, $c = 0; $c < $t; $c++) {
                $d += $cpf{$c} * (($t + 1) - $c);
            }
            $d = ((10 * $d) % 11) % 10;
            if ($cpf{$c} != $d) {
                return false;
            }
        }

        return true;
    }
}
