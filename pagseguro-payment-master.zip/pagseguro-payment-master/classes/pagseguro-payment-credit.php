<?php

if (!defined('ABSPATH')) {
    exit;
}

class WC_Pagseguro_Payment_Credit extends WC_Pagseguro_Payment_Gateway
{

    public function __construct()
    {
        $this->id = 'pagseguro-payment-credit';
        //$this->icon               = apply_filters( 'woocommerce_pagseguro_icon', plugins_url( 'assets/images/pagseguro.png', plugin_dir_path( __FILE__ ) ) );
        //$this->icon = apply_filters('woocommerce_pagseguro_payment_icon', plugins_url('img/logo_pagseguro.png', PAGSEGURO_BASE_DIR));
        $this->method_title = __('PagSeguro Credit Payment', PAGSEGURO_DOMAIN);
        $this->method_description = __('Accept payments via Credit Card (PagSeguro).', PAGSEGURO_DOMAIN);
        $this->has_fields = true;
        //$this->order_button_text = __('Proceed to payment', PAGSEGURO_DOMAIN);

        $this->init_form_fields();
        $this->init_settings();

        // Define user set variables.
        $this->title = $this->get_option('title');
        $this->description = $this->get_option('description');

        $this->email = $this->get_option('email');
        $this->token = $this->get_option('token');
        $this->sandbox_email = $this->get_option('sandbox_email');
        $this->sandbox_token = $this->get_option('sandbox_token');

        $this->pagseguro_environment = $this->get_option('pagseguro_environment', 'sandbox');
        $this->mode = $this->get_option('pagseguro_mode', 'transparent');
        $this->redirect_message = $this->get_option('redirect_message');

        $this->credit_max_installment = $this->get_option('maximum_installment', 6);
        $this->credit_interest_free = $this->get_option('interest_free_installment', 6);

        $this->debug = $this->get_option('debug');
        $this->debug_js = $this->get_option('debug_js');
        $this->analysisStatuses = array('1', '2');
        $this->approvedStatuses = array('3', '4');
        $this->reprovedStatuses = array('5', '6', '7', '8');
        $this->supports = array('products', 'refunds');

        if ($this->debug == 'yes') {
            $this->context = array('source' => $this->id);
            if (function_exists('wc_get_logger')) {
                $this->log = wc_get_logger();
            } else {
                $this->log = new WC_Logger();
            }
        }

        $this->method = $this;

        add_action('woocommerce_update_options_payment_gateways_'.$this->id, array($this, 'process_admin_options'));
        add_action('woocommerce_admin_order_data_after_shipping_address', array($this, 'order_info'));

        add_action('woocommerce_thankyou_'.$this->id, array($this, 'order_received'));
        add_action('woocommerce_order_details_after_order_table', array($this, 'pending_payment_message'), 5);
        add_action('wp_enqueue_scripts', array($this, 'checkout_scripts'));
    }

    public function init_form_fields()
    {
        $statuses = array('' => '-- Selecione um status --');
        $statuses = array_merge($statuses, wc_get_order_statuses());
        $url = get_site_url().'/wc-api/wc_gateway_callback/';
        $this->form_fields = array(
            'enabled'                   => array(
                'title'    => __('Enable / Disable', PAGSEGURO_DOMAIN),
                'type'     => 'checkbox',
                'label'    => __('Enable Creditcard PagSeguro Payment', PAGSEGURO_DOMAIN),
                'desc_tip' => false,
                'default'  => 'yes',
            ),
            'title'                     => array(
                'title'       => __('Method Title', PAGSEGURO_DOMAIN),
                'type'        => 'text',
                'description' => __('This controls the title that users will see during checkout.', PAGSEGURO_DOMAIN),
                'default'     => __('Cartão de Crédito', PAGSEGURO_DOMAIN),
                'desc_tip'    => true,
            ),

            'pagseguro_environment'     => array(
                'title'    => __('PagSeguro Environment', PAGSEGURO_DOMAIN),
                'type'     => 'select',
                'desc_tip' => true,
                'default'  => 'production',
                'label'    => __('Choose Environment for PagSeguro Integration', PAGSEGURO_DOMAIN),
                'options'  => array(
                    'sandbox'    => __('Sandbox', PAGSEGURO_DOMAIN),
                    'production' => __('Production', PAGSEGURO_DOMAIN),
                ),
            ),
            'email'                     => array(
                'title'       => __('PagSeguro Email', PAGSEGURO_DOMAIN),
                'type'        => 'text',
                'description' => __('PagSeguro Email Address', PAGSEGURO_DOMAIN),
                'default'     => '',
                'desc_tip'    => false,
            ),
            'token'                     => array(
                'title'       => __('PagSeguro Token', PAGSEGURO_DOMAIN),
                'type'        => 'text',
                'description' => __('PagSeguro Token', PAGSEGURO_DOMAIN),
                'default'     => '',
                'desc_tip'    => false,
            ),

            'sandbox_email'             => array(
                'title'       => __('PagSeguro Sandbox Email', PAGSEGURO_DOMAIN),
                'type'        => 'text',
                'description' => __('PagSeguro Sandbox Email Address', PAGSEGURO_DOMAIN),
                'default'     => '',
                'desc_tip'    => false,
            ),
            'sandbox_token'             => array(
                'title'       => __('PagSeguro Sandbox Token', PAGSEGURO_DOMAIN),
                'type'        => 'text',
                'description' => __('PagSeguro Sandbox Token', PAGSEGURO_DOMAIN),
                'default'     => '',
                'desc_tip'    => false,
            ),

            'credit_card_block'         => array(
                'title'       => __('Credit Card Options', PAGSEGURO_DOMAIN),
                'type'        => 'title',
                'description' => '',
            ),
            'maximum_installment'       => array(
                'title'       => __('Installment Within', PAGSEGURO_DOMAIN),
                'type'        => 'select',
                'description' => __('Maximum number of installments for orders in your store.', PAGSEGURO_DOMAIN),
                'desc_tip'    => true,
                'class'       => 'wc-enhanced-select',
                'default'     => '6',
                'options'     => array(
                    '1'  => '1x',
                    '2'  => '2x',
                    '3'  => '3x',
                    '4'  => '4x',
                    '5'  => '5x',
                    '6'  => '6x',
                    '7'  => '7x',
                    '8'  => '8x',
                    '9'  => '9x',
                    '10' => '10x',
                    '11' => '11x',
                    '12' => '12x',
                ),
            ),
            'interest_free_installment' => array(
                'title'       => __('Interest-Free Installment', PAGSEGURO_DOMAIN),
                'type'        => 'select',
                'description' => __('Number of interest-free installments', PAGSEGURO_DOMAIN),
                'desc_tip'    => true,
                'class'       => 'wc-enhanced-select',
                'default'     => '6',
                'options'     => array(
                    '1'  => '1x',
                    '2'  => '2x',
                    '3'  => '3x',
                    '4'  => '4x',
                    '5'  => '5x',
                    '6'  => '6x',
                    '7'  => '7x',
                    '8'  => '8x',
                    '9'  => '9x',
                    '10' => '10x',
                    '11' => '11x',
                    '12' => '12x',
                ),
            ),

            'extra_options'             => array(
                'title'       => __('Extra Options', PAGSEGURO_DOMAIN),
                'type'        => 'title',
                'description' => '',
            ),
            'debug'                     => array(
                'title'       => __('Enable Module Logs', PAGSEGURO_DOMAIN),
                'label'       => __('Enable', PAGSEGURO_DOMAIN),
                'type'        => 'checkbox',
                'desc_tip'    => false,
                'default'     => 'no',
                'description' => sprintf(__('Acesso aos logs do módulo: %s', PAGSEGURO_DOMAIN), $this->link_log()),
            ),
            'debug_js'                  => array(
                'title'    => __('Enable JavaScript Debug', PAGSEGURO_DOMAIN),
                'label'    => __('Enable only if PagSeguro support asks for', PAGSEGURO_DOMAIN),
                'type'     => 'checkbox',
                'desc_tip' => false,
                'default'  => 'no',
            ),
            'status_iniciado'           => array(
                'title'       => __('Status Iniciado', PAGSEGURO_DOMAIN),
                'type'        => 'select',
                'desc_tip'    => true,
                'description' => __('O pedido mudará automaticamente para este status em caso de aprovação no PagSeguro', PAGSEGURO_DOMAIN),
                'default'     => 'wc-pending',
                'options'     => $statuses,
            ),
            'status_aprovado'           => array(
                'title'       => __('Status Aprovado', PAGSEGURO_DOMAIN),
                'type'        => 'select',
                'desc_tip'    => true,
                'description' => __('O pedido mudará automaticamente para este status em caso de aprovação no PagSeguro', PAGSEGURO_DOMAIN),
                'default'     => 'wc-processing',
                'options'     => $statuses,
            ),
            'status_cancelado'          => array(
                'title'       => __('Status Cancelado', PAGSEGURO_DOMAIN),
                'type'        => 'select',
                'desc_tip'    => true,
                'description' => __('O pedido mudará automaticamente para este status quando a transação for cancelada no PagSeguro', PAGSEGURO_DOMAIN),
                'default'     => 'wc-cancelled',
                'options'     => $statuses,
            ),
            'status_aguardando'         => array(
                'title'       => __('Status Aguardando', PAGSEGURO_DOMAIN),
                'type'        => 'select',
                'desc_tip'    => true,
                'description' => __('O pedido mudará automaticamente para este status quando a transação estiver no status aguardando no PagSeguro', PAGSEGURO_DOMAIN),
                'default'     => 'wc-on-hold',
                'options'     => $statuses,
            ),
        );
    }

    public function is_available()
    {
        $available = $this->get_option('enabled') == 'yes';

        $session_id = $this->getSessionId();
        if(!empty($session_id) && $available) {
            $available = false;
            $headers = array(
                'Accept' => 'application/vnd.pagseguro.com.br.v1+json;charset=ISO-8859-1',
            );
            $args = array(
                'timeout' => 60,
                'headers' => $headers,
                'cookies' => array(),
            );
            $url = add_query_arg(array('amount' => number_format($this->get_order_total(), 2, '.', ''), 'sessionId' => $session_id), $this->ws_path() . '/payment-methods');
            $result = wp_remote_get($url, $args);
            $rawJson = utf8_encode($result['body']);
            $responseCode = $result['response']['code'];

            if($responseCode == 200) {
                $json = json_decode($rawJson, true);
                if(!$json['error']) {
                    if(array_key_exists('CREDIT_CARD', $json['paymentMethods'])) {
                        return true;
                    }
                }
            }
        }

        return $available;
    }

    public function admin_options()
    {
        wp_enqueue_script('pagseguro-config', plugins_url('js/config.js', plugin_dir_path(__FILE__)), array('jquery'), PAGSEGURO_VERSION, true);

        parent::admin_options();
    }

    public function payment_fields()
    {
        $total = $this->get_order_total();

        $params = array(
            'credit_max_installment'  => $this->credit_max_installment,
            'credit_interest_free'    => $this->credit_interest_free,
            'session_id'              => $this->getSessionId(),
            'static_path'             => 'https://stc.pagseguro.uol.com.br',
            'total'                   => $total,
            'ano'                     => date('Y'),
            'debug_js'                => $this->debug_js == 'yes',
            'errors'                  => array(
                'invalid_card'        => __('Invalid credit card number.', PAGSEGURO_DOMAIN),
                'invalid_cvv'         => __('Invalid CVV.', PAGSEGURO_DOMAIN),
                'invalid_name'        => __('Invalid name.', PAGSEGURO_DOMAIN),
                'invalid_expiry'      => __('Invalid expiry date.', PAGSEGURO_DOMAIN),
                'expired_card'        => __('Expired card.', PAGSEGURO_DOMAIN),
                'invalid_cpf'         => __('Invalid CPF.', PAGSEGURO_DOMAIN),
                'invalid_birthdate'   => __('Invalid birthdate.', PAGSEGURO_DOMAIN),
                'invalid_phone'       => __('Invalid phone.', PAGSEGURO_DOMAIN),
                'invalid_installment' => __('Please choose an installment option.', PAGSEGURO_DOMAIN),
            ),
        );
        wc_get_template(
            'pagseguro-payment-credit.php', $params, '', WC_Pagseguro_Payment::get_template_dir()
        );
    }

    public function checkout_scripts()
    {
        if (is_checkout() && $this->is_available()) {
            $functionsjs = $this->debug_js == 'yes' ? '/js/pagseguro-functions-debug.js' : '/js/pagseguro-functions.js';

            wp_enqueue_script('pagseguro-directpayment-js', $this->direct_script(), array(), null, true);
            wp_enqueue_script('pagseguro-cpfcnpj-js', plugins_url('js/cpf_cnpj.js', plugin_dir_path(__FILE__)), array(), null, true);
            wp_enqueue_script('pagseguro-functions', plugins_url( $functionsjs, plugin_dir_path( __FILE__ ) ), array( 'jquery', 'pagseguro-directpayment-js' ), PAGSEGURO_VERSION, true );

            $total = $this->get_order_total();
            wp_localize_script(
                'pagseguro-functions',
                'pagseguro_payment_card_params',
                array(
                    'credit_max_installment' => $this->credit_max_installment,
                    'credit_interest_free' => $this->credit_interest_free,
                    'total' => $total,
                    'invalid_card'        => __('Invalid credit card number.', PAGSEGURO_DOMAIN),
                    'invalid_cvv'         => __('Invalid CVV.', PAGSEGURO_DOMAIN),
                    'invalid_name'        => __('Invalid name.', PAGSEGURO_DOMAIN),
                    'invalid_expiry'      => __('Invalid expiry date.', PAGSEGURO_DOMAIN),
                    'expired_card'        => __('Expired card.', PAGSEGURO_DOMAIN),
                    'invalid_cpf'         => __('Invalid CPF.', PAGSEGURO_DOMAIN),
                    'invalid_birthdate'   => __('Invalid birthdate.', PAGSEGURO_DOMAIN),
                    'invalid_phone'       => __('Invalid phone.', PAGSEGURO_DOMAIN),
                    'invalid_installment' => __('Please choose an installment option.', PAGSEGURO_DOMAIN),
                )
            );
        }
    }

    public function order_info()
    {
        if (!empty($_REQUEST['post'])) {
            $order_id = $_REQUEST['post'];
            $order = new WC_Order($order_id);
            $method = is_callable(array($order, 'get_payment_method')) ? $order->get_payment_method() : $order->payment_method;
            if($method == 'pagseguro-payment-credit') {
                $status = get_post_meta($order_id, '_ps_status', true);
                $params = array(
                    't_id'       => get_post_meta($order_id, '_ps_tid', true),
                    't_msg'      => $this->getPagSeguroMessage($status),
                    'order_id'   => $order_id,
                    'parcelas'   => get_post_meta($order_id, '_ps_installment', true),
                    'bandeira'   => get_post_meta($order_id, '_ps_card_type', true),
                    'status'     => $status,
                    'billet_url' => get_post_meta($_REQUEST['post'], '_ps_billet_url', true),
                    'metodo'     => get_post_meta($order_id, '_ps_method', true),
                );
                wc_get_template(
                    'pagseguro-payment-admin.php', $params, '', WC_Pagseguro_Payment::get_template_dir()
                );
            }
        }
    }

    public function validate_fields()
    {
        return true;
    }

    public function process_payment($order_id)
    {
        $this->writeLog('----- INÍCIO DO PAGAMENTO -----', false, 'info');
        global $woocommerce;
        global $wp_version;
        $order = new WC_Order($order_id);
        $erro = false;
        $total = (float) $order->get_total();
        $method = 'creditCard';

        $cc_token = (isset($_POST['ps_transparent_card_token'])) ? $_POST['ps_transparent_card_token'] : '';
        $cc_numero = (isset($_POST['ps_transparent_card_num'])) ? $_POST['ps_transparent_card_num'] : '';
        $cc_numero = preg_replace('/\s+/', '', $cc_numero);
        $cc_nome = (isset($_POST['ps_transparent_name'])) ? $_POST['ps_transparent_name'] : '';
        $cc_cvv = (isset($_POST['ps_transparent_card_cvv'])) ? $_POST['ps_transparent_card_cvv'] : '';
        $cc_vencto = (isset($_POST['ps_transparent_card_expiry'])) ? $_POST['ps_transparent_card_expiry'] : '';
        $cc_val_mes = substr($cc_vencto, 0, 2);
        $cc_val_ano = substr($cc_vencto, -4, 4);
        $cc_bandeira = (isset($_POST['ps_transparent_card_type'])) ? $_POST['ps_transparent_card_type'] : '';
        $cc_parcelas = (isset($_POST['ps_transparent_installments'])) ? $_POST['ps_transparent_installments'] : 0;
        $cc_cpf = (isset($_POST['ps_transparent_cpf'])) ? $_POST['ps_transparent_cpf'] : '';
        $cc_cpf = preg_replace('/\D/', '', $cc_cpf);
        $maxparcelas = $this->credit_max_installment;
        $bin = substr($cc_numero, 0, 6);
        $last4 = substr($cc_numero, -4, 4);

        if ($this->cartaoValido($cc_numero) && !empty($cc_nome) && strlen($cc_cvv) > 2 && strlen($cc_numero) > 12 && $this->venctoOK($cc_val_mes, $cc_val_ano)) {
            $erro = false;
        } else {
            $erro = true;
            $additional = '';
            $extra = '';
            if (empty($cc_numero)) {
                $error_message = __(' Preencha o número do cartão.', PAGSEGURO_DOMAIN);
                $additional = 'O cliente não digitou o número do cartão';
                wc_add_notice(__('Pagamento não autorizado:', PAGSEGURO_DOMAIN).$error_message, 'error');
            } elseif (strlen($cc_numero) < 13 || !$this->cartaoValido($cc_numero)) {
                $error_message = __(' Invalid credit card. Please verify and try again.', PAGSEGURO_DOMAIN);
                $additional = 'Número do cartão inválido (Luhn) ou menor que o permitido (13 dígitos)';
                $extra = sprintf("(%d-****-%d)", $bin, $last4);
                wc_add_notice(__('Pagamento não autorizado:', PAGSEGURO_DOMAIN).$error_message, 'error');
            } elseif (empty($cc_nome)) {
                $error_message = __(' Preencha o nome do cartão!', PAGSEGURO_DOMAIN);
                $additional = 'O nome do cartão não foi preenchido';
                wc_add_notice(__('Pagamento não autorizado:', PAGSEGURO_DOMAIN).$error_message, 'error');
            } elseif (strlen($cc_cvv) < 3) {
                $error_message = __(' Preencha o CVV do cartão corretamente!', PAGSEGURO_DOMAIN);
                $additional = 'CVV inválido ou não preenchido';
                wc_add_notice(__('Pagamento não autorizado:', PAGSEGURO_DOMAIN).$error_message, 'error');
            } elseif (!$this->venctoOK($cc_val_mes, $cc_val_ano)) {
                $error_message = __(' Cartão expirado! Verifique a data de vencimento informada', PAGSEGURO_DOMAIN);
                $additional = 'Cartão expirado';
                $extra = sprintf("(%d/%d)", $cc_val_mes, $cc_val_ano);
                wc_add_notice(__('Pagamento não autorizado:', PAGSEGURO_DOMAIN).$error_message, 'error');
            } else {
                $error_message = __(' This card isn\'t accepted. Please choose another one!', PAGSEGURO_DOMAIN);
                $additional = "Cartão de crédito não aceito ($cc_metodo)";
                $extra = sprintf("(%d-****-%d)", $bin, $last4);
                wc_add_notice(__('Pagamento não autorizado:', PAGSEGURO_DOMAIN).$error_message, 'error');
            }
            update_post_meta($order_id, '_transaction_message', "Cartão inválido. Pagamento não enviado ao gateway.");
            $errocompleto = sprintf("Erro: %s - Detalhes do erro: %s %s", $error_message, $additional, $extra);
            $order->add_order_note("Cartão inválido. Pagamento não enviado ao gateway.");
            $order->add_order_note($errocompleto);
            $this->writeLog('Cartão inválido. Pagamento não enviado ao gateway.', false, 'error');
            $this->writeLog($errocompleto, false, 'error');
        }

        if(!$erro) {
            $payload = $this->get_pagseguro_payload($order, $method);
            $erro = !$this->validate_payload($payload, $order);
        }
        if (!$erro) {
            $url = $this->ws_path()."/v2/transactions?email={$this->get_email()}&token={$this->get_token()}";
            $headers = array(
                'Content-Type' => 'application/x-www-form-urlencoded',
            );

            $majorminor = $this->format_woo_version(WC_VERSION);
            $headers['cms-description'] = 'woocommerce-oficial-v.'.$majorminor;
            $headers['module-description'] = 'WordPress v.'.$wp_version.'-WooCommerce v.'.WC_VERSION.'(Transparent CreditCard)';
            $headers['module-version'] = PAGSEGURO_VERSION;

            foreach ($payload as $key => $value) {
                $fixedPayload[$key] = $this->retiracento($value);
            }
            $args = array(
                'body'    => $fixedPayload,
                'timeout' => 60,
                'headers' => $headers,
                'cookies' => array(),
            );
            $this->writeLog(wc_print_r($fixedPayload, true), false, 'info');
            $result = wp_remote_post($url, $args);

            $rawXml = $result['body'];
            $responseCode = $result['response']['code'];

            $this->writeLog('Response Code: '.$responseCode, false, 'info');
            $this->writeLog($rawXml, false, 'info');

            $timeoutCodes = array(408, 504, 524, 598);
            $xml = simplexml_load_string($rawXml, 'SimpleXMLElement', LIBXML_NOWARNING);
            if ($responseCode == 200) {
                //OK
                $status = $xml->status;
                $tid = $xml->code;
                update_post_meta($order_id, '_ps_method', (string) $method);
                update_post_meta($order_id, '_ps_status', (string) $status);
                update_post_meta($order_id, '_ps_tid', (string) $tid);
                $transactionString = "Pagamento enviado ao PagSeguro: ($status) ".$this->getPagSeguroMessage($status)." - TID: $tid";

                $qty = $payload['installmentQuantity'];
                $value = $payload['installmentValue'];
                $installmentInfo = $qty.'x de R$ '.$value.' = R$ '.$value * $qty;
                update_post_meta($order_id, '_ps_card_type', (string) $cc_bandeira);
                update_post_meta($order_id, '_ps_card_bin', (string) $bin);
                update_post_meta($order_id, '_ps_card_end', (string) $last4);
                update_post_meta($order_id, '_ps_card_masked', (string) $bin.'******'.$last4);
                update_post_meta($order_id, '_ps_card_exp_month', (string) $cc_val_mes);
                update_post_meta($order_id, '_ps_card_exp_year', (string) $cc_val_ano);
                update_post_meta($order_id, '_ps_card_name', (string) $cc_nome);
                update_post_meta($order_id, '_ps_card_cpf', (string) $cc_cpf);
                update_post_meta($order_id, '_ps_installment', (string) $installmentInfo);

                $order->add_order_note($transactionString);
                $this->updateOrderStatus($order, $status);
                $this->writeLog($transactionString, false, 'error');
                //iniciado (1)
                //em análise (4)
                //capturado (8)
                //cancelado (3)
                if (in_array($status, $this->reprovedStatuses)) {
                    $error_message = 'Favor entrar em contato com o Banco emissor do seu cartão de crédito';
                    wc_add_notice(__('Pagamento não autorizado: ', PAGSEGURO_DOMAIN).$error_message, 'error');
                    $order->update_status('failed', $error_message);
                    $this->writeLog('Pagamento não autorizado: '.$error_message, false, 'error');
                }
            } elseif ($responseCode == 401) {
                //erro autenticação
                $erro = true;
                wc_add_notice(__('Erro no pagamento, entre em contato com o lojista.', 'error'));
                $error_message = "($responseCode) Erro de autenticação com o PagSeguro, confira suas credenciais.";
                $additional = 'Ambiente selecionado: '.strtoupper($this->pagseguro_environment);
                $errocompleto = sprintf("Erro: %s - Detalhes do erro: %s", $error_message, $additional);
                $order->add_order_note($errocompleto);
                $this->writeLog($errocompleto, false, 'error');
            } elseif (in_array($responseCode, $timeoutCodes)) {
                $status = 1;
                $transactionString = __('Ocorreu um timeout na transação. Aguardar retorno PagSeguro.', PAGSEGURO_DOMAIN);

                $order->add_order_note($transactionString);
                $order->add_order_note($rawXml);
                $this->updateOrderStatus($order, $status);
                $this->writeLog($transactionString, false, 'error');
            } else {
                //erro nos dados
                $erro = true;
                $errorCode = $xml->error->code;
                $errorMessage = $xml->error->message;
                if (!empty($errorCode)) {
                    $errorString = __('Pagamento não autorizado: ', PAGSEGURO_DOMAIN)."($errorCode) ".$errorMessage;
                    wc_add_notice($errorString, 'error');
                } else {
                    $errorString = "Ocorreu um erro na comunicação com o PagSeguro: ($responseCode) $rawXml";
                }
                $order->add_order_note($errorString);
                $this->writeLog($errorString, false, 'error');
            }
        }
        if (!$erro) {
            $order->set_total($total);
            $woocommerce->cart->empty_cart();
            return array(
                'result'   => 'success',
                'redirect' => $this->get_return_url($order),
            );
        } else {
            return array(
                'result'   => 'fail',
                'redirect' => '',
            );
        }
        $this->writeLog('----- FIM DO PAGAMENTO -----', false, 'info');
    }

    /**
     * Can the order be refunded via PagSeguro?
     *
     * @param  WC_Order $order Order object.
     * @return bool
     */
    public function can_refund_order($order)
    {
        $order_id = $order->get_id();
        $tid = get_post_meta($order_id, '_ps_tid', true);
        $status = get_post_meta($order_id, '_ps_status', true);
        $method = get_post_meta($order_id, '_ps_method', true);

        // cancel: (1) Aguardando pagamento / (2) Em análise
        // refund: (3) Paga / (4) Disponível / (5) Em disputa
        $can_refund_statuses = array('1', '2', '3', '4', '5');
        $can_refund_methods = array('creditCard', 'boleto', 'eft');

        return $order && !empty($tid) && in_array($status, $can_refund_statuses) && in_array($method, $can_refund_methods);
    }
}
