jQuery( 'body' ).on( 'focusout', '#ps_transparent_card_num', function() {
    var bin = jQuery( this ).val().replace( /[^\d]/g, '' ).substr( 0, 6 ),
        installments = jQuery( 'body #ps_transparent_installments' );

    if ( 6 === bin.length ) {
        PagSeguroDirectPayment.getBrand({
            cardBin: bin,
            success: function( data ) {
                if(data.brand.name != jQuery( 'body #ps_transparent_card_type' ).val() || !installments.val()) {
                    // Reset the installments.
                    installments.empty();
                    installments.attr( 'disabled', 'disabled' );

                    updateInstallments(data.brand.name);
                    jQuery( '#ps_transparent_cc_type_icon' ).attr('src',jQuery('#ps_transparent_credit_brand_'+data.brand.name).attr('data-image-src'));
                    jQuery( 'body #ps_transparent_card_type' ).val(data.brand.name);
                    if(data.brand.name == 'amex') {
                        jQuery("#ps_transparent_card_cvv").attr('maxlength','4');
                    }
                    else {
                        jQuery("#ps_transparent_card_cvv").attr('maxlength','3');
                    }
                }
            },
            error: function(data) {
                //$( 'body' ).trigger( 'card_type', 'error' );
                //pagSeguroSetCreditCardBrand( 'error' );
            },
            complete: function(data) {
                // Reset the installments.
            }
        });
    }
});

function checkCVV(bandeira) {
    "use strict";
    var cvvField = jQuery("#ps_transparent_card_cvv");
    if (bandeira && bandeira != 'undefined') {
        var brand = bandeira.toLowerCase();
    }else{
        var brand = jQuery('#ps_transparent_card_type').val().toLowerCase();
    }
    if (cvvField.val()) {
        if (brand == 'amex' && cvvField.val().length != 4 || brand != 'amex' && cvvField.val().length != 3) {
            cvvField.parent().parent().addClass('form-error');
            console.log('CVV inválido. '+ brand +' com '+ cvvField.val().length +' caracteres.');
            return false;
        }else{
            cvvField.parent().parent().removeClass('form-error').addClass('form-ok');
            return true;
        }
    }
}

// Get the installments.
function updateInstallments(brand) {
    if ( 'error' !== brand ) {
        PagSeguroDirectPayment.getInstallments({
            amount: pagseguro_payment_card_params.total,
            brand: brand,
            maxInstallmentNoInterest:  pagseguro_payment_card_params.credit_interest_free,
            success: function( data ) {
                var installments = jQuery( '#ps_transparent_installments' );
                var maxInstallments = pagseguro_payment_card_params.credit_max_installment;

                if ( false === data.error ) {
                    installments.empty();
                    installments.removeAttr( 'disabled' );
                    var valorParcela;

                    jQuery.each( data.installments[brand], function( index, installment ) {
                        if(installment.quantity == 1) {
                            valorParcela = installment.installmentAmount;
                        }
                        if(!maxInstallments || installment.quantity <= maxInstallments) {
                            installments.append( pagSeguroGetInstallmentOption( installment ) );
                        }
                    });
                    jQuery( '#ps_transparent_installment_value' ).val(valorParcela);
                } else {
                    console.log(data.error);
                }
            },
            error: function() {
                //pagSeguroAddErrorMessage( errors.invalid_card );
            }
        });
    } else {
        //pagSeguroAddErrorMessage( errors.invalid_card );
    }
}

function pagSeguroGetInstallmentOption( installment ) {
    return '<option value="' + installment.quantity + '" data-installment-value="' + installment.installmentAmount + '">' + pagSeguroGetPriceText( installment ) + '</option>';
}

function pagSeguroGetPriceText( installment ) {
    var interest = 1;
    var installmentParsed = 'R$ ' + parseFloat( installment.installmentAmount, 10 ).toFixed( 2 ).replace( '.', ',' ).toString();
    var totalParsed = 'R$ ' + parseFloat( installment.totalAmount, 10 ).toFixed( 2 ).replace( '.', ',' ).toString();
    var interestFree = ( true === installment.interestFree ) ? ' = ' + totalParsed + ' sem juros': '';
    var interestText = interestFree ? interestFree : ' = ' + totalParsed;

    return installment.quantity + 'x de ' + installmentParsed + interestText;
}

function PagSeguroValidateLuhn(s) {
    var w = s.replace(/\D/g, ""); //remove all non-digit characters

    j = w.length / 2;
    k = Math.floor(j);
    m = Math.ceil(j) - k;
    c = 0;
    for (i=0; i<k; i++) {
        a = w.charAt(i*2+m) * 2;
        c += a > 9 ? Math.floor(a/10 + a%10) : a;
    }
    for (i=0; i<k+m; i++) c += w.charAt(i*2+1-m) * 1;
    return (c%10 == 0);
}

function getCardToken(number, month, year, type, cvv, idToken, form, submit) {
    PagSeguroDirectPayment.createCardToken({
        cardNumber: number,
        brand: type,
        cvv: cvv,
        expirationMonth: month,
        expirationYear: year,
        success: function(callback) {
            idToken.val(callback.card.token);
            getSenderHash();
            if(submit) {
                form.submit();
            }
        },
        error: function(callback) {
            reload = false;
            if(undefined != callback.errors["30400"]) {
                error = 'Dados do cartão inválidos.';
            } else if (undefined != callback.errors["10001"]) {
                error = 'Tamanho do cartão inválido.';
            } else if (undefined != callback.errors["10006"]) {
                error = 'Tamanho do CVV inválido.';
            } else if (undefined != callback.errors["30405"]) {
                error = 'Data de validade incorreta.';
            } else if (undefined != callback.errors["30403"]) {
                error = 'Sessão inválida, a página será atualizada.';
                reload = true;
            } else if (undefined != callback.errors["30404"]) {
                error = 'Sessão inválida, a página será atualizada.';
                reload = true;
            } else {
                error = 'Verifique os dados do cartão digitado.';
            }
            console.error('Falha ao obter o token do cartao.');
            console.warn(error);
            console.log(callback.errors);
            if(reload) {
                location.reload();
            }
        },
        complete: function(callback) {

        },
    });
}

function callPagSeguro() {
    var cid = jQuery('#ps_transparent_card_cvv').val();
    var number = jQuery('#ps_transparent_card_num').val().replace(/\D/g, '');
    var month = jQuery( '#ps_transparent_card_expiry').val().replace( /[^\d]/g, '' ).substr( 0, 2 );
    var year  = jQuery( '#ps_transparent_card_expiry').val().replace( /[^\d]/g, '' ).substr( 2 );
    var type = jQuery('#ps_transparent_card_type').val();
    var idToken = jQuery('#ps_transparent_card_token');
    getCardToken(number,month,year,type,cid,idToken,null,false);
}

function checkLength(obj, size) {
    return (obj && obj.length > size);
}

function validaPagSeguro() {
    var cid = jQuery('#ps_transparent_card_cvv').val();
    var number = jQuery('#ps_transparent_card_num').val().replace(/\D/g, '');
    var month = jQuery( '#ps_transparent_card_expiry').val().replace( /[^\d]/g, '' ).substr( 0, 2 );
    var year  = jQuery( '#ps_transparent_card_expiry').val().replace( /[^\d]/g, '' ).substr( 2 );
    var type = jQuery('#ps_transparent_card_type').val();
    if(checkLength(cid,2) && checkLength(number,10) && checkLength(month,0) && checkLength(year,0) && checkLength(cid,2)){
        callPagSeguro();
    }
}

function renderMethod(type, option) {
    var path = 'https://stc.pagseguro.uol.com.br';
    var name = option.displayName;
    var code = option.name.toLowerCase();
    var image = path + option.images.MEDIUM.path;

    if(type == 'billet') {
        jQuery('#ps_transparent_billet_ico').attr('src', image);
        jQuery('#ps_transparent_billet_ico').show();
        jQuery('.ps-transparent-payment-li-billet').show();
    } else if(type == 'debit') {
        if(!jQuery('#ps_transparent_debit_type_'+code).length) {
            li = document.createElement("li");
            img = document.createElement("img");
            span = document.createElement("span");
            radio = document.createElement("input");
            li.className = 'ps_transparent_debit_li bank-option-box';
            radio.type = 'radio';
            radio.id = 'ps_transparent_debit_type_'+code;
            radio.name = 'ps_transparent_debit_type';
            radio.className = 'ps_transparent_debit_type';
            radio.value = code;
            img.src = image;
            img.alt = name;
            img.title = name;
            span.innerText = name;
            li.append(radio);
            li.append(img);
            li.append(span);


            jQuery('#ps_transparent_debit_flags').append(li);
            jQuery('.ps-transparent-payment-li-debit').show();
        }
    }
    else {
        if(!jQuery('#ps_transparent_credit_brand_'+code).length) {
            li = document.createElement("li");
            li.id = 'ps_transparent_credit_brand_'+code;
            li.setAttribute('data-image-src', image);
            jQuery('#ps_transparent_card_flags').append(li);
            jQuery('.ps-transparent-payment-li-card').show();
        }
    }
}

function toggleVerso(action) {
    "use strict";
    if (action === 'add') {
        jQuery('#card_container').addClass('verso');
    }else{
        jQuery('#card_container').removeClass('verso');
    }
}

function sendToCard(str, classe) {
    "use strict";
    if(classe === 'card-expiry-month' && str.length == 1) {
        str = '0'+str;
    }
    if (str.length > 1) {
        jQuery('#card_container .' + classe).html(str);
        if(classe === 'card-number') {
            var txt = jQuery('#number_card').html();
            txt = txt.replace(/\D/g, '');
            jQuery('#number_card').html(txt.replace(/(.{4})/g, '$1 '));
        }
    }
}

jQuery(document).on('change', '#ps_transparent_installments', function(event) {
    jQuery( '#ps_transparent_installment_value' ).val(jQuery(this).find(':selected').attr('data-installment-value'));
});

function PagSeguroError( error, wrapper ) {
    jQuery( '.woocommerce-error', wrapper ).remove();
    wrapper.prepend( '<div class="woocommerce-error" style="margin-bottom: 0.5em !important;">' + error + '</div>' );
}

function getSenderHash() {
    PagSeguroDirectPayment.onSenderHashReady(function(response){
        jQuery( 'input[name="ps_transparent_sender_hash"]' ).val(response.senderHash);
    });
}

function pagSeguroFormValidator(type) {
    if ( window.pagseguro_submit ) {
        window.pagseguro_submit = false;

        return true;
    }

    if(typeof type === "undefined") {
        var method = jQuery('input[name=payment_method]:checked', '#order_review').val();
        if(method == 'pagseguro-payment-credit') {
            type = 'creditCard';
        }
        else if(method == 'pagseguro-payment-debit') {
            type = 'eft';
        }
        else if(method == 'pagseguro-payment-billet') {
            type = 'boleto';
        }
        else {
            return true;
        }
    }

    var form = jQuery( 'form.checkout, form#order_review' ),
        error           = false,
        wrapper         = '',
        errorHtml       = '',
        today           = new Date();

    if(type == 'creditCard') {
        var brand           = jQuery( '#ps_transparent_card_type', form).val(),
            name            = jQuery( '#ps_transparent_name', form).val(),
            cpf             = jQuery( '#ps_transparent_cpf', form).val().replace( /[^\d]/g, '' ),
            birthdate       = jQuery( '#ps_transparent_birthdate', form).val(),
            phone           = jQuery( '#ps_transparent_phone', form).val().replace( /[^\d]/g, '' ),
            cardNumber      = jQuery( '#ps_transparent_card_num', form ).val().replace( /[^\d]/g, '' ),
            cvv             = jQuery( '#ps_transparent_card_cvv', form ).val(),
            expirationMonth = jQuery( '#ps_transparent_card_expiry', form ).val().replace( /[^\d]/g, '' ).substr( 0, 2 ),
            expirationYear  = jQuery( '#ps_transparent_card_expiry', form ).val().replace( /[^\d]/g, '' ).substr( 2 ),
            installments    = jQuery( '#ps_transparent_installments', form );
    }

    if(type == 'boleto') {
        var billet_cpf      = jQuery( '#ps_transparent_billet_cpf', form).val().replace( /[^\d]/g, '' ),
            billet_phone    = jQuery( '#ps_transparent_billet_phone', form).val().replace( /[^\d]/g, '' );
    }

    if(type == 'eft') {
        var debit_cpf       = jQuery( '#ps_transparent_debit_cpf', form).val().replace( /[^\d]/g, '' ),
            debit_phone     = jQuery( '#ps_transparent_debit_phone', form).val().replace( /[^\d]/g, '' );
    }


    errorHtml += '<ul>';

    if(type === 'creditCard') {
        wrapper = jQuery( '#ps-transparent-payment-form-card' );
        if ( typeof brand === 'undefined' || 'error' === brand ) {
            errorHtml += '<li>' + pagseguro_payment_card_params.invalid_card + '</li>';
            error = true;
        }

        if ( name.trim().indexOf(' ') == -1 || name.trim().length < 1  ) {
            errorHtml += '<li>' + pagseguro_payment_card_params.invalid_name + '</li>';
            error = true;
        }

        if (!isCpf(cpf)) {
            errorHtml += '<li>' + pagseguro_payment_card_params.invalid_cpf + '</li>';
            error = true;
        }

        parts = birthdate.split("/");
        date = new Date(Number(parts[2]), Number(parts[1]) - 1, Number(parts[0]));
        if ( !birthdate.match(/^(0[1-9]|[12][0-9]|3[01])[\- \/.](?:(0[1-9]|1[012])[\- \/.](19|20)[0-9]{2})$/) || today <= date) {
            errorHtml += '<li>' + pagseguro_payment_card_params.invalid_birthdate + '</li>';
            error = true;
        }

        if ( !phone.match(/^((1[1-9])|([2-9][0-9]))(([0-9]{4}[0-9]{4})|(9[0-9]{3}[0-9]{5}))$/) ) {
            errorHtml += '<li>' + pagseguro_payment_card_params.invalid_phone + '</li>';
            error = true;
        }

        if( !PagSeguroValidateLuhn(cardNumber) || cardNumber.length < 13 ) {
            errorHtml += '<li>' + pagseguro_payment_card_params.invalid_card + '</li>';
            error = true;
        }

        if ( 2 !== expirationMonth.length || 4 !== expirationYear.length ) {
            errorHtml += '<li>' + pagseguro_payment_card_params.invalid_expiry + '</li>';
            error = true;
        }

        if ( ( 2 === expirationMonth.length && 4 === expirationYear.length ) && ( expirationMonth > 12 || expirationYear <= ( today.getFullYear() - 1 ) || expirationYear >= ( today.getFullYear() + 20 ) || ( expirationMonth < ( today.getMonth() + 2 ) && expirationYear.toString() === today.getFullYear().toString() ) ) ) {
            errorHtml += '<li>' + pagseguro_payment_card_params.expired_card + '</li>';
            error = true;
        }

        if ( ( cvv.length != jQuery( '#ps_transparent_card_cvv', form ).attr('maxlength') ) ) {
            errorHtml += '<li>' + pagseguro_payment_card_params.invalid_cvv + '</li>';
            error = true;
        }

        if ( '' == installments.val() ) {
            errorHtml += '<li>' + pagseguro_payment_card_params.invalid_installment + '</li>';
            error = true;
        }
    }
    else if(type === 'boleto') {
        wrapper = jQuery( '#ps-transparent-payment-form-billet' );
        if (!isCpf(billet_cpf)) {
            errorHtml += '<li>' + pagseguro_payment_billet_params.invalid_cpf + '</li>';
            error = true;
        }
        if ( !billet_phone.match(/^((1[1-9])|([2-9][0-9]))(([0-9]{4}[0-9]{4})|(9[0-9]{3}[0-9]{5}))$/) ) {
            errorHtml += '<li>' + pagseguro_payment_billet_params.invalid_phone + '</li>';
            error = true;
        }
    }
    else {
        wrapper = jQuery( '#ps-transparent-payment-form-debit' );
        if (!isCpf(debit_cpf)) {
            errorHtml += '<li>' + pagseguro_payment_debit_params.invalid_cpf + '</li>';
            error = true;
        }
        if ( !debit_phone.match(/^((1[1-9])|([2-9][0-9]))(([0-9]{4}[0-9]{4})|(9[0-9]{3}[0-9]{5}))$/) ) {
            errorHtml += '<li>' + pagseguro_payment_debit_params.invalid_phone + '</li>';
            error = true;
        }
    }

    errorHtml += '</ul>';

    if ( ! error ) {
        //corrigir loop
        window.pagseguro_submit = true;
        //form.submit();
        if(type == 'creditCard') {
            var idToken = jQuery('#ps_transparent_card_token');
            getCardToken(cardNumber,expirationMonth,expirationYear,brand,cvv,idToken,form,true);
        }
        else {
            return true;
        }
        return false;
    // Display the error messages.
    } else {
        PagSeguroError( errorHtml, wrapper );
    }

    return false;
}