(function ( $ ) {
    'use strict';

    $( function () {

        /**
         * Switch transparent checkout options display basead in payment type.
         *
         * @param {String} method
         */
        function PagSeguroChangeIntegration( method ) {
            var fields  = $( '#woocommerce_pagseguro-payment_credit' ).closest( '.form-table' ),
                heading = fields.prev( 'h3' ),
                redirect_message = $( '#woocommerce_pagseguro-payment_redirect_message' ).closest( 'tr' );

            fields.show();
            heading.show();
            redirect_message.hide();
            PagSeguroShowHideBilletOptions( $( '#woocommerce_pagseguro-payment_billet' ).is( ':checked' ) );
            PagSeguroShowHideCreditcardOptions( $( '#woocommerce_pagseguro-payment_credit' ).is( ':checked' ) );
        }

        /**
         * Switch banking ticket message display.
         *
         * @param {String} checked
         */
        function PagSeguroShowHideBilletOptions( checked, suffix = '' ) {
            var fields  = $( '#woocommerce_pagseguro-payment'+suffix+'_billet_extrafee_message' ).closest( '.form-table' ),
                heading = fields.prev( 'h3' );

            if ( checked ) {
                fields.show();
                heading.show();
            } else {
                fields.hide();
                heading.hide();
            }
        }


        /**
         * Switch banking ticket message display.
         *
         * @param {String} checked
         */
        function PagSeguroShowHideCreditcardOptions( checked, suffix = '' ) {
            var fields  = $( '#woocommerce_pagseguro-payment'+suffix+'_maximum_installment' ).closest( '.form-table' ),
                heading = fields.prev( 'h3' );

            if ( checked ) {
                fields.show();
                heading.show();
            } else {
                fields.hide();
                heading.hide();
            }
        }

        /**
         * Awitch user data for sandbox and production.
         *
         * @param {String} checked
         */
        function PagSeguroShowHideCredentials( value, suffix = '' ) {
            var email = $( '#woocommerce_pagseguro-payment'+suffix+'_email' ).closest( 'tr' ),
                token = $( '#woocommerce_pagseguro-payment'+suffix+'_token' ).closest( 'tr' ),
                sandboxEmail = $( '#woocommerce_pagseguro-payment'+suffix+'_sandbox_email' ).closest( 'tr' ),
                sandboxToken = $( '#woocommerce_pagseguro-payment'+suffix+'_sandbox_token' ).closest( 'tr' );

            if ( value == 'sandbox' ) {
                email.hide();
                token.hide();
                sandboxEmail.show();
                sandboxToken.show();
            } else {
                email.show();
                token.show();
                sandboxEmail.hide();
                sandboxToken.hide();
            }
        }

        PagSeguroChangeIntegration( $( '#woocommerce_pagseguro-payment_pagseguro_mode' ).val() );
        $( 'body' ).on( 'change', '#woocommerce_pagseguro-payment_pagseguro_mode', function () {
            PagSeguroChangeIntegration( $( this ).val() );
        }).change();

        PagSeguroShowHideBilletOptions( $( '#woocommerce_pagseguro-payment_billet' ).is( ':checked' ) );
        $( 'body' ).on( 'change', '#woocommerce_pagseguro-payment_billet', function () {
            PagSeguroShowHideBilletOptions( $( this ).is( ':checked' ) );
        });

        PagSeguroShowHideCreditcardOptions( $( '#woocommerce_pagseguro-payment_credit' ).is( ':checked' ) );
        $( 'body' ).on( 'change', '#woocommerce_pagseguro-payment_credit', function () {
            PagSeguroShowHideCreditcardOptions( $( this ).is( ':checked' ) );
        });

        PagSeguroShowHideCredentials( $('#woocommerce_pagseguro-payment_pagseguro_environment option:selected').val() );
        $( 'body' ).on( 'change', '#woocommerce_pagseguro-payment_pagseguro_environment', function () {
            PagSeguroShowHideCredentials( $( this ).val() );
        });

        /*PagSeguroShowHideBilletOptions( $( '#woocommerce_pagseguro-payment-redirect_billet' ).is( ':checked' ), '-redirect' );
        $( 'body' ).on( 'change', '#woocommerce_pagseguro-payment-redirect_billet', function () {
            PagSeguroShowHideBilletOptions( $( this ).is( ':checked' ), '-redirect' );
        });

        PagSeguroShowHideCreditcardOptions( $( '#woocommerce_pagseguro-payment-redirect_credit' ).is( ':checked' ), '-redirect' );
        $( 'body' ).on( 'change', '#woocommerce_pagseguro-payment-redirect_credit', function () {
            PagSeguroShowHideCreditcardOptions( $( this ).is( ':checked' ), '-redirect' );
        });*/

        PagSeguroShowHideCredentials( $('#woocommerce_pagseguro-payment-redirect_pagseguro_environment option:selected').val(), '-redirect' );
        $( 'body' ).on( 'change', '#woocommerce_pagseguro-payment-redirect_pagseguro_environment', function () {
            PagSeguroShowHideCredentials( $( this ).val(), '-redirect' );
        });

        PagSeguroShowHideCredentials( $('#woocommerce_pagseguro-payment-billet_pagseguro_environment option:selected').val(), '-billet' );
        $( 'body' ).on( 'change', '#woocommerce_pagseguro-payment-billet_pagseguro_environment', function () {
            PagSeguroShowHideCredentials( $( this ).val(), '-billet' );
        });

        PagSeguroShowHideCredentials( $('#woocommerce_pagseguro-payment-credit_pagseguro_environment option:selected').val(), '-credit' );
        $( 'body' ).on( 'change', '#woocommerce_pagseguro-payment-credit_pagseguro_environment', function () {
            PagSeguroShowHideCredentials( $( this ).val(), '-credit' );
        });

        PagSeguroShowHideCredentials( $('#woocommerce_pagseguro-payment-debit_pagseguro_environment option:selected').val(), '-debit' );
        $( 'body' ).on( 'change', '#woocommerce_pagseguro-payment-debit_pagseguro_environment', function () {
            PagSeguroShowHideCredentials( $( this ).val(), '-debit' );
        });
    });

}( jQuery ));
